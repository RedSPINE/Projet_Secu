def calculateur() :
    f_source = open("ground_truth.csv", "r")
    l1 = True
    tab = [[] for i in range(4073)]
    for line in f_source :
        if l1 == True :
            l1 = False
        else :
            curseur = 0
            while line[curseur] != "," :
                curseur += 1
            curseur += 1
            while line[curseur] != "," :
                curseur += 1
            curseur += 1
            while line[curseur] != "," :
                curseur += 1
            curseur += 1
            while line[curseur] != "," :
                curseur += 1
            curseur += 1
            prix = 0
            while line[curseur] != "." :
                prix = prix * 10 + int(line[curseur])
                curseur += 1
            curseur += 1
            dec = 0.1
            while line[curseur] != "," :
                prix = prix + int(line[curseur])*dec
                curseur += 1
                dec /= 10
            if prix < 2 :
                tab[0].append(prix)
            elif prix < 4 :
                tab[1].append(prix)
            elif prix < 6 :
                tab[2].append(prix)
            elif prix < 8 :
                tab[3].append(prix)
            elif prix < 10 :
                tab[4].append(prix)
            elif prix < 12 :
                tab[5].append(prix)
            elif prix < 14 :
                tab[6].append(prix)
            elif prix < 16 :
                tab[7].append(prix)
            elif prix < 18 :
                tab[8].append(prix)
            elif prix < 20 :
                tab[9].append(prix)
            elif prix < 22 :
                tab[10].append(prix)
            elif prix < 24 :
                tab[11].append(prix)
            elif prix < 26 :
                tab[12].append(prix)
            elif prix < 28 :
                tab[13].append(prix)
            elif prix < 30 :
                tab[14].append(prix)
            elif prix < 32 :
                tab[15].append(prix)
            elif prix < 34 :
                tab[16].append(prix)
            elif prix < 36 :
                tab[17].append(prix)
            elif prix < 38 :
                tab[18].append(prix)
            elif prix < 40 :
                tab[19].append(prix)
            elif prix < 42 :
                tab[20].append(prix)
            elif prix < 44 :
                tab[21].append(prix)
            elif prix < 46 :
                tab[22].append(prix)
            elif prix < 48 :
                tab[23].append(prix)
            elif prix < 50 :
                tab[24].append(prix)
            elif prix < 52 :
                tab[25].append(prix)
            elif prix < 54 :
                tab[26].append(prix)
            elif prix < 56 :
                tab[27].append(prix)
            elif prix < 58 :
                tab[28].append(prix)
            elif prix < 60 :
                tab[29].append(prix)
            elif prix < 62 :
                tab[30].append(prix)
            elif prix < 64 :
                tab[31].append(prix)
            elif prix < 66 :
                tab[32].append(prix)
            elif prix < 68 :
                tab[33].append(prix)
            elif prix < 70 :
                tab[34].append(prix)
            elif prix < 72 :
                tab[35].append(prix)
            elif prix < 74 :
                tab[36].append(prix)
            elif prix < 76 :
                tab[37].append(prix)
            elif prix < 78 :
                tab[38].append(prix)
            elif prix < 80 :
                tab[39].append(prix)
            elif prix < 82 :
                tab[40].append(prix)
            elif prix < 84 :
                tab[41].append(prix)
            elif prix < 86 :
                tab[42].append(prix)
            elif prix < 88 :
                tab[43].append(prix)
            elif prix < 90 :
                tab[44].append(prix)
            elif prix < 92 :
                tab[45].append(prix)
            elif prix < 94 :
                tab[46].append(prix)
            elif prix < 96 :
                tab[47].append(prix)
            elif prix < 98 :
                tab[48].append(prix)
            elif prix < 100 :
                tab[49].append(prix)
            elif prix < 102 :
                tab[50].append(prix)
            elif prix < 104 :
                tab[51].append(prix)
            elif prix < 106 :
                tab[52].append(prix)
            elif prix < 108 :
                tab[53].append(prix)
            elif prix < 110 :
                tab[54].append(prix)
            elif prix < 112 :
                tab[55].append(prix)
            elif prix < 114 :
                tab[56].append(prix)
            elif prix < 116 :
                tab[57].append(prix)
            elif prix < 118 :
                tab[58].append(prix)
            elif prix < 120 :
                tab[59].append(prix)
            elif prix < 122 :
                tab[60].append(prix)
            elif prix < 124 :
                tab[61].append(prix)
            elif prix < 126 :
                tab[62].append(prix)
            elif prix < 128 :
                tab[63].append(prix)
            elif prix < 130 :
                tab[64].append(prix)
            elif prix < 132 :
                tab[65].append(prix)
            elif prix < 134 :
                tab[66].append(prix)
            elif prix < 136 :
                tab[67].append(prix)
            elif prix < 138 :
                tab[68].append(prix)
            elif prix < 140 :
                tab[69].append(prix)
            elif prix < 142 :
                tab[70].append(prix)
            elif prix < 144 :
                tab[71].append(prix)
            elif prix < 146 :
                tab[72].append(prix)
            elif prix < 148 :
                tab[73].append(prix)
            elif prix < 150 :
                tab[74].append(prix)
            elif prix < 152 :
                tab[75].append(prix)
            elif prix < 154 :
                tab[76].append(prix)
            elif prix < 156 :
                tab[77].append(prix)
            elif prix < 158 :
                tab[78].append(prix)
            elif prix < 160 :
                tab[79].append(prix)
            elif prix < 162 :
                tab[80].append(prix)
            elif prix < 164 :
                tab[81].append(prix)
            elif prix < 166 :
                tab[82].append(prix)
            elif prix < 168 :
                tab[83].append(prix)
            elif prix < 170 :
                tab[84].append(prix)
            elif prix < 172 :
                tab[85].append(prix)
            elif prix < 174 :
                tab[86].append(prix)
            elif prix < 176 :
                tab[87].append(prix)
            elif prix < 178 :
                tab[88].append(prix)
            elif prix < 180 :
                tab[89].append(prix)
            elif prix < 182 :
                tab[90].append(prix)
            elif prix < 184 :
                tab[91].append(prix)
            elif prix < 186 :
                tab[92].append(prix)
            elif prix < 188 :
                tab[93].append(prix)
            elif prix < 190 :
                tab[94].append(prix)
            elif prix < 192 :
                tab[95].append(prix)
            elif prix < 194 :
                tab[96].append(prix)
            elif prix < 196 :
                tab[97].append(prix)
            elif prix < 198 :
                tab[98].append(prix)
            elif prix < 200 :
                tab[99].append(prix)
            elif prix < 202 :
                tab[100].append(prix)
            elif prix < 204 :
                tab[101].append(prix)
            elif prix < 206 :
                tab[102].append(prix)
            elif prix < 208 :
                tab[103].append(prix)
            elif prix < 210 :
                tab[104].append(prix)
            elif prix < 212 :
                tab[105].append(prix)
            elif prix < 214 :
                tab[106].append(prix)
            elif prix < 216 :
                tab[107].append(prix)
            elif prix < 218 :
                tab[108].append(prix)
            elif prix < 220 :
                tab[109].append(prix)
            elif prix < 222 :
                tab[110].append(prix)
            elif prix < 224 :
                tab[111].append(prix)
            elif prix < 226 :
                tab[112].append(prix)
            elif prix < 228 :
                tab[113].append(prix)
            elif prix < 230 :
                tab[114].append(prix)
            elif prix < 232 :
                tab[115].append(prix)
            elif prix < 234 :
                tab[116].append(prix)
            elif prix < 236 :
                tab[117].append(prix)
            elif prix < 238 :
                tab[118].append(prix)
            elif prix < 240 :
                tab[119].append(prix)
            elif prix < 242 :
                tab[120].append(prix)
            elif prix < 244 :
                tab[121].append(prix)
            elif prix < 246 :
                tab[122].append(prix)
            elif prix < 248 :
                tab[123].append(prix)
            elif prix < 250 :
                tab[124].append(prix)
            elif prix < 252 :
                tab[125].append(prix)
            elif prix < 254 :
                tab[126].append(prix)
            elif prix < 256 :
                tab[127].append(prix)
            elif prix < 258 :
                tab[128].append(prix)
            elif prix < 260 :
                tab[129].append(prix)
            elif prix < 262 :
                tab[130].append(prix)
            elif prix < 264 :
                tab[131].append(prix)
            elif prix < 266 :
                tab[132].append(prix)
            elif prix < 268 :
                tab[133].append(prix)
            elif prix < 270 :
                tab[134].append(prix)
            elif prix < 272 :
                tab[135].append(prix)
            elif prix < 274 :
                tab[136].append(prix)
            elif prix < 276 :
                tab[137].append(prix)
            elif prix < 278 :
                tab[138].append(prix)
            elif prix < 280 :
                tab[139].append(prix)
            elif prix < 282 :
                tab[140].append(prix)
            elif prix < 284 :
                tab[141].append(prix)
            elif prix < 286 :
                tab[142].append(prix)
            elif prix < 288 :
                tab[143].append(prix)
            elif prix < 290 :
                tab[144].append(prix)
            elif prix < 292 :
                tab[145].append(prix)
            elif prix < 294 :
                tab[146].append(prix)
            elif prix < 296 :
                tab[147].append(prix)
            elif prix < 298 :
                tab[148].append(prix)
            elif prix < 300 :
                tab[149].append(prix)
            elif prix < 302 :
                tab[150].append(prix)
            elif prix < 304 :
                tab[151].append(prix)
            elif prix < 306 :
                tab[152].append(prix)
            elif prix < 308 :
                tab[153].append(prix)
            elif prix < 310 :
                tab[154].append(prix)
            elif prix < 312 :
                tab[155].append(prix)
            elif prix < 314 :
                tab[156].append(prix)
            elif prix < 316 :
                tab[157].append(prix)
            elif prix < 318 :
                tab[158].append(prix)
            elif prix < 320 :
                tab[159].append(prix)
            elif prix < 322 :
                tab[160].append(prix)
            elif prix < 324 :
                tab[161].append(prix)
            elif prix < 326 :
                tab[162].append(prix)
            elif prix < 328 :
                tab[163].append(prix)
            elif prix < 330 :
                tab[164].append(prix)
            elif prix < 332 :
                tab[165].append(prix)
            elif prix < 334 :
                tab[166].append(prix)
            elif prix < 336 :
                tab[167].append(prix)
            elif prix < 338 :
                tab[168].append(prix)
            elif prix < 340 :
                tab[169].append(prix)
            elif prix < 342 :
                tab[170].append(prix)
            elif prix < 344 :
                tab[171].append(prix)
            elif prix < 346 :
                tab[172].append(prix)
            elif prix < 348 :
                tab[173].append(prix)
            elif prix < 350 :
                tab[174].append(prix)
            elif prix < 352 :
                tab[175].append(prix)
            elif prix < 354 :
                tab[176].append(prix)
            elif prix < 356 :
                tab[177].append(prix)
            elif prix < 358 :
                tab[178].append(prix)
            elif prix < 360 :
                tab[179].append(prix)
            elif prix < 362 :
                tab[180].append(prix)
            elif prix < 364 :
                tab[181].append(prix)
            elif prix < 366 :
                tab[182].append(prix)
            elif prix < 368 :
                tab[183].append(prix)
            elif prix < 370 :
                tab[184].append(prix)
            elif prix < 372 :
                tab[185].append(prix)
            elif prix < 374 :
                tab[186].append(prix)
            elif prix < 376 :
                tab[187].append(prix)
            elif prix < 378 :
                tab[188].append(prix)
            elif prix < 380 :
                tab[189].append(prix)
            elif prix < 382 :
                tab[190].append(prix)
            elif prix < 384 :
                tab[191].append(prix)
            elif prix < 386 :
                tab[192].append(prix)
            elif prix < 388 :
                tab[193].append(prix)
            elif prix < 390 :
                tab[194].append(prix)
            elif prix < 392 :
                tab[195].append(prix)
            elif prix < 394 :
                tab[196].append(prix)
            elif prix < 396 :
                tab[197].append(prix)
            elif prix < 398 :
                tab[198].append(prix)
            elif prix < 400 :
                tab[199].append(prix)
            elif prix < 402 :
                tab[200].append(prix)
            elif prix < 404 :
                tab[201].append(prix)
            elif prix < 406 :
                tab[202].append(prix)
            elif prix < 408 :
                tab[203].append(prix)
            elif prix < 410 :
                tab[204].append(prix)
            elif prix < 412 :
                tab[205].append(prix)
            elif prix < 414 :
                tab[206].append(prix)
            elif prix < 416 :
                tab[207].append(prix)
            elif prix < 418 :
                tab[208].append(prix)
            elif prix < 420 :
                tab[209].append(prix)
            elif prix < 422 :
                tab[210].append(prix)
            elif prix < 424 :
                tab[211].append(prix)
            elif prix < 426 :
                tab[212].append(prix)
            elif prix < 428 :
                tab[213].append(prix)
            elif prix < 430 :
                tab[214].append(prix)
            elif prix < 432 :
                tab[215].append(prix)
            elif prix < 434 :
                tab[216].append(prix)
            elif prix < 436 :
                tab[217].append(prix)
            elif prix < 438 :
                tab[218].append(prix)
            elif prix < 440 :
                tab[219].append(prix)
            elif prix < 442 :
                tab[220].append(prix)
            elif prix < 444 :
                tab[221].append(prix)
            elif prix < 446 :
                tab[222].append(prix)
            elif prix < 448 :
                tab[223].append(prix)
            elif prix < 450 :
                tab[224].append(prix)
            elif prix < 452 :
                tab[225].append(prix)
            elif prix < 454 :
                tab[226].append(prix)
            elif prix < 456 :
                tab[227].append(prix)
            elif prix < 458 :
                tab[228].append(prix)
            elif prix < 460 :
                tab[229].append(prix)
            elif prix < 462 :
                tab[230].append(prix)
            elif prix < 464 :
                tab[231].append(prix)
            elif prix < 466 :
                tab[232].append(prix)
            elif prix < 468 :
                tab[233].append(prix)
            elif prix < 470 :
                tab[234].append(prix)
            elif prix < 472 :
                tab[235].append(prix)
            elif prix < 474 :
                tab[236].append(prix)
            elif prix < 476 :
                tab[237].append(prix)
            elif prix < 478 :
                tab[238].append(prix)
            elif prix < 480 :
                tab[239].append(prix)
            elif prix < 482 :
                tab[240].append(prix)
            elif prix < 484 :
                tab[241].append(prix)
            elif prix < 486 :
                tab[242].append(prix)
            elif prix < 488 :
                tab[243].append(prix)
            elif prix < 490 :
                tab[244].append(prix)
            elif prix < 492 :
                tab[245].append(prix)
            elif prix < 494 :
                tab[246].append(prix)
            elif prix < 496 :
                tab[247].append(prix)
            elif prix < 498 :
                tab[248].append(prix)
            elif prix < 500 :
                tab[249].append(prix)
            elif prix < 502 :
                tab[250].append(prix)
            elif prix < 504 :
                tab[251].append(prix)
            elif prix < 506 :
                tab[252].append(prix)
            elif prix < 508 :
                tab[253].append(prix)
            elif prix < 510 :
                tab[254].append(prix)
            elif prix < 512 :
                tab[255].append(prix)
            elif prix < 514 :
                tab[256].append(prix)
            elif prix < 516 :
                tab[257].append(prix)
            elif prix < 518 :
                tab[258].append(prix)
            elif prix < 520 :
                tab[259].append(prix)
            elif prix < 522 :
                tab[260].append(prix)
            elif prix < 524 :
                tab[261].append(prix)
            elif prix < 526 :
                tab[262].append(prix)
            elif prix < 528 :
                tab[263].append(prix)
            elif prix < 530 :
                tab[264].append(prix)
            elif prix < 532 :
                tab[265].append(prix)
            elif prix < 534 :
                tab[266].append(prix)
            elif prix < 536 :
                tab[267].append(prix)
            elif prix < 538 :
                tab[268].append(prix)
            elif prix < 540 :
                tab[269].append(prix)
            elif prix < 542 :
                tab[270].append(prix)
            elif prix < 544 :
                tab[271].append(prix)
            elif prix < 546 :
                tab[272].append(prix)
            elif prix < 548 :
                tab[273].append(prix)
            elif prix < 550 :
                tab[274].append(prix)
            elif prix < 552 :
                tab[275].append(prix)
            elif prix < 554 :
                tab[276].append(prix)
            elif prix < 556 :
                tab[277].append(prix)
            elif prix < 558 :
                tab[278].append(prix)
            elif prix < 560 :
                tab[279].append(prix)
            elif prix < 562 :
                tab[280].append(prix)
            elif prix < 564 :
                tab[281].append(prix)
            elif prix < 566 :
                tab[282].append(prix)
            elif prix < 568 :
                tab[283].append(prix)
            elif prix < 570 :
                tab[284].append(prix)
            elif prix < 572 :
                tab[285].append(prix)
            elif prix < 574 :
                tab[286].append(prix)
            elif prix < 576 :
                tab[287].append(prix)
            elif prix < 578 :
                tab[288].append(prix)
            elif prix < 580 :
                tab[289].append(prix)
            elif prix < 582 :
                tab[290].append(prix)
            elif prix < 584 :
                tab[291].append(prix)
            elif prix < 586 :
                tab[292].append(prix)
            elif prix < 588 :
                tab[293].append(prix)
            elif prix < 590 :
                tab[294].append(prix)
            elif prix < 592 :
                tab[295].append(prix)
            elif prix < 594 :
                tab[296].append(prix)
            elif prix < 596 :
                tab[297].append(prix)
            elif prix < 598 :
                tab[298].append(prix)
            elif prix < 600 :
                tab[299].append(prix)
            elif prix < 602 :
                tab[300].append(prix)
            elif prix < 604 :
                tab[301].append(prix)
            elif prix < 606 :
                tab[302].append(prix)
            elif prix < 608 :
                tab[303].append(prix)
            elif prix < 610 :
                tab[304].append(prix)
            elif prix < 612 :
                tab[305].append(prix)
            elif prix < 614 :
                tab[306].append(prix)
            elif prix < 616 :
                tab[307].append(prix)
            elif prix < 618 :
                tab[308].append(prix)
            elif prix < 620 :
                tab[309].append(prix)
            elif prix < 622 :
                tab[310].append(prix)
            elif prix < 624 :
                tab[311].append(prix)
            elif prix < 626 :
                tab[312].append(prix)
            elif prix < 628 :
                tab[313].append(prix)
            elif prix < 630 :
                tab[314].append(prix)
            elif prix < 632 :
                tab[315].append(prix)
            elif prix < 634 :
                tab[316].append(prix)
            elif prix < 636 :
                tab[317].append(prix)
            elif prix < 638 :
                tab[318].append(prix)
            elif prix < 640 :
                tab[319].append(prix)
            elif prix < 642 :
                tab[320].append(prix)
            elif prix < 644 :
                tab[321].append(prix)
            elif prix < 646 :
                tab[322].append(prix)
            elif prix < 648 :
                tab[323].append(prix)
            elif prix < 650 :
                tab[324].append(prix)
            elif prix < 652 :
                tab[325].append(prix)
            elif prix < 654 :
                tab[326].append(prix)
            elif prix < 656 :
                tab[327].append(prix)
            elif prix < 658 :
                tab[328].append(prix)
            elif prix < 660 :
                tab[329].append(prix)
            elif prix < 662 :
                tab[330].append(prix)
            elif prix < 664 :
                tab[331].append(prix)
            elif prix < 666 :
                tab[332].append(prix)
            elif prix < 668 :
                tab[333].append(prix)
            elif prix < 670 :
                tab[334].append(prix)
            elif prix < 672 :
                tab[335].append(prix)
            elif prix < 674 :
                tab[336].append(prix)
            elif prix < 676 :
                tab[337].append(prix)
            elif prix < 678 :
                tab[338].append(prix)
            elif prix < 680 :
                tab[339].append(prix)
            elif prix < 682 :
                tab[340].append(prix)
            elif prix < 684 :
                tab[341].append(prix)
            elif prix < 686 :
                tab[342].append(prix)
            elif prix < 688 :
                tab[343].append(prix)
            elif prix < 690 :
                tab[344].append(prix)
            elif prix < 692 :
                tab[345].append(prix)
            elif prix < 694 :
                tab[346].append(prix)
            elif prix < 696 :
                tab[347].append(prix)
            elif prix < 698 :
                tab[348].append(prix)
            elif prix < 700 :
                tab[349].append(prix)
            elif prix < 702 :
                tab[350].append(prix)
            elif prix < 704 :
                tab[351].append(prix)
            elif prix < 706 :
                tab[352].append(prix)
            elif prix < 708 :
                tab[353].append(prix)
            elif prix < 710 :
                tab[354].append(prix)
            elif prix < 712 :
                tab[355].append(prix)
            elif prix < 714 :
                tab[356].append(prix)
            elif prix < 716 :
                tab[357].append(prix)
            elif prix < 718 :
                tab[358].append(prix)
            elif prix < 720 :
                tab[359].append(prix)
            elif prix < 722 :
                tab[360].append(prix)
            elif prix < 724 :
                tab[361].append(prix)
            elif prix < 726 :
                tab[362].append(prix)
            elif prix < 728 :
                tab[363].append(prix)
            elif prix < 730 :
                tab[364].append(prix)
            elif prix < 732 :
                tab[365].append(prix)
            elif prix < 734 :
                tab[366].append(prix)
            elif prix < 736 :
                tab[367].append(prix)
            elif prix < 738 :
                tab[368].append(prix)
            elif prix < 740 :
                tab[369].append(prix)
            elif prix < 742 :
                tab[370].append(prix)
            elif prix < 744 :
                tab[371].append(prix)
            elif prix < 746 :
                tab[372].append(prix)
            elif prix < 748 :
                tab[373].append(prix)
            elif prix < 750 :
                tab[374].append(prix)
            elif prix < 752 :
                tab[375].append(prix)
            elif prix < 754 :
                tab[376].append(prix)
            elif prix < 756 :
                tab[377].append(prix)
            elif prix < 758 :
                tab[378].append(prix)
            elif prix < 760 :
                tab[379].append(prix)
            elif prix < 762 :
                tab[380].append(prix)
            elif prix < 764 :
                tab[381].append(prix)
            elif prix < 766 :
                tab[382].append(prix)
            elif prix < 768 :
                tab[383].append(prix)
            elif prix < 770 :
                tab[384].append(prix)
            elif prix < 772 :
                tab[385].append(prix)
            elif prix < 774 :
                tab[386].append(prix)
            elif prix < 776 :
                tab[387].append(prix)
            elif prix < 778 :
                tab[388].append(prix)
            elif prix < 780 :
                tab[389].append(prix)
            elif prix < 782 :
                tab[390].append(prix)
            elif prix < 784 :
                tab[391].append(prix)
            elif prix < 786 :
                tab[392].append(prix)
            elif prix < 788 :
                tab[393].append(prix)
            elif prix < 790 :
                tab[394].append(prix)
            elif prix < 792 :
                tab[395].append(prix)
            elif prix < 794 :
                tab[396].append(prix)
            elif prix < 796 :
                tab[397].append(prix)
            elif prix < 798 :
                tab[398].append(prix)
            elif prix < 800 :
                tab[399].append(prix)
            elif prix < 802 :
                tab[400].append(prix)
            elif prix < 804 :
                tab[401].append(prix)
            elif prix < 806 :
                tab[402].append(prix)
            elif prix < 808 :
                tab[403].append(prix)
            elif prix < 810 :
                tab[404].append(prix)
            elif prix < 812 :
                tab[405].append(prix)
            elif prix < 814 :
                tab[406].append(prix)
            elif prix < 816 :
                tab[407].append(prix)
            elif prix < 818 :
                tab[408].append(prix)
            elif prix < 820 :
                tab[409].append(prix)
            elif prix < 822 :
                tab[410].append(prix)
            elif prix < 824 :
                tab[411].append(prix)
            elif prix < 826 :
                tab[412].append(prix)
            elif prix < 828 :
                tab[413].append(prix)
            elif prix < 830 :
                tab[414].append(prix)
            elif prix < 832 :
                tab[415].append(prix)
            elif prix < 834 :
                tab[416].append(prix)
            elif prix < 836 :
                tab[417].append(prix)
            elif prix < 838 :
                tab[418].append(prix)
            elif prix < 840 :
                tab[419].append(prix)
            elif prix < 842 :
                tab[420].append(prix)
            elif prix < 844 :
                tab[421].append(prix)
            elif prix < 846 :
                tab[422].append(prix)
            elif prix < 848 :
                tab[423].append(prix)
            elif prix < 850 :
                tab[424].append(prix)
            elif prix < 852 :
                tab[425].append(prix)
            elif prix < 854 :
                tab[426].append(prix)
            elif prix < 856 :
                tab[427].append(prix)
            elif prix < 858 :
                tab[428].append(prix)
            elif prix < 860 :
                tab[429].append(prix)
            elif prix < 862 :
                tab[430].append(prix)
            elif prix < 864 :
                tab[431].append(prix)
            elif prix < 866 :
                tab[432].append(prix)
            elif prix < 868 :
                tab[433].append(prix)
            elif prix < 870 :
                tab[434].append(prix)
            elif prix < 872 :
                tab[435].append(prix)
            elif prix < 874 :
                tab[436].append(prix)
            elif prix < 876 :
                tab[437].append(prix)
            elif prix < 878 :
                tab[438].append(prix)
            elif prix < 880 :
                tab[439].append(prix)
            elif prix < 882 :
                tab[440].append(prix)
            elif prix < 884 :
                tab[441].append(prix)
            elif prix < 886 :
                tab[442].append(prix)
            elif prix < 888 :
                tab[443].append(prix)
            elif prix < 890 :
                tab[444].append(prix)
            elif prix < 892 :
                tab[445].append(prix)
            elif prix < 894 :
                tab[446].append(prix)
            elif prix < 896 :
                tab[447].append(prix)
            elif prix < 898 :
                tab[448].append(prix)
            elif prix < 900 :
                tab[449].append(prix)
            elif prix < 902 :
                tab[450].append(prix)
            elif prix < 904 :
                tab[451].append(prix)
            elif prix < 906 :
                tab[452].append(prix)
            elif prix < 908 :
                tab[453].append(prix)
            elif prix < 910 :
                tab[454].append(prix)
            elif prix < 912 :
                tab[455].append(prix)
            elif prix < 914 :
                tab[456].append(prix)
            elif prix < 916 :
                tab[457].append(prix)
            elif prix < 918 :
                tab[458].append(prix)
            elif prix < 920 :
                tab[459].append(prix)
            elif prix < 922 :
                tab[460].append(prix)
            elif prix < 924 :
                tab[461].append(prix)
            elif prix < 926 :
                tab[462].append(prix)
            elif prix < 928 :
                tab[463].append(prix)
            elif prix < 930 :
                tab[464].append(prix)
            elif prix < 932 :
                tab[465].append(prix)
            elif prix < 934 :
                tab[466].append(prix)
            elif prix < 936 :
                tab[467].append(prix)
            elif prix < 938 :
                tab[468].append(prix)
            elif prix < 940 :
                tab[469].append(prix)
            elif prix < 942 :
                tab[470].append(prix)
            elif prix < 944 :
                tab[471].append(prix)
            elif prix < 946 :
                tab[472].append(prix)
            elif prix < 948 :
                tab[473].append(prix)
            elif prix < 950 :
                tab[474].append(prix)
            elif prix < 952 :
                tab[475].append(prix)
            elif prix < 954 :
                tab[476].append(prix)
            elif prix < 956 :
                tab[477].append(prix)
            elif prix < 958 :
                tab[478].append(prix)
            elif prix < 960 :
                tab[479].append(prix)
            elif prix < 962 :
                tab[480].append(prix)
            elif prix < 964 :
                tab[481].append(prix)
            elif prix < 966 :
                tab[482].append(prix)
            elif prix < 968 :
                tab[483].append(prix)
            elif prix < 970 :
                tab[484].append(prix)
            elif prix < 972 :
                tab[485].append(prix)
            elif prix < 974 :
                tab[486].append(prix)
            elif prix < 976 :
                tab[487].append(prix)
            elif prix < 978 :
                tab[488].append(prix)
            elif prix < 980 :
                tab[489].append(prix)
            elif prix < 982 :
                tab[490].append(prix)
            elif prix < 984 :
                tab[491].append(prix)
            elif prix < 986 :
                tab[492].append(prix)
            elif prix < 988 :
                tab[493].append(prix)
            elif prix < 990 :
                tab[494].append(prix)
            elif prix < 992 :
                tab[495].append(prix)
            elif prix < 994 :
                tab[496].append(prix)
            elif prix < 996 :
                tab[497].append(prix)
            elif prix < 998 :
                tab[498].append(prix)
            elif prix < 1000 :
                tab[499].append(prix)
            elif prix < 1002 :
                tab[500].append(prix)
            elif prix < 1004 :
                tab[501].append(prix)
            elif prix < 1006 :
                tab[502].append(prix)
            elif prix < 1008 :
                tab[503].append(prix)
            elif prix < 1010 :
                tab[504].append(prix)
            elif prix < 1012 :
                tab[505].append(prix)
            elif prix < 1014 :
                tab[506].append(prix)
            elif prix < 1016 :
                tab[507].append(prix)
            elif prix < 1018 :
                tab[508].append(prix)
            elif prix < 1020 :
                tab[509].append(prix)
            elif prix < 1022 :
                tab[510].append(prix)
            elif prix < 1024 :
                tab[511].append(prix)
            elif prix < 1026 :
                tab[512].append(prix)
            elif prix < 1028 :
                tab[513].append(prix)
            elif prix < 1030 :
                tab[514].append(prix)
            elif prix < 1032 :
                tab[515].append(prix)
            elif prix < 1034 :
                tab[516].append(prix)
            elif prix < 1036 :
                tab[517].append(prix)
            elif prix < 1038 :
                tab[518].append(prix)
            elif prix < 1040 :
                tab[519].append(prix)
            elif prix < 1042 :
                tab[520].append(prix)
            elif prix < 1044 :
                tab[521].append(prix)
            elif prix < 1046 :
                tab[522].append(prix)
            elif prix < 1048 :
                tab[523].append(prix)
            elif prix < 1050 :
                tab[524].append(prix)
            elif prix < 1052 :
                tab[525].append(prix)
            elif prix < 1054 :
                tab[526].append(prix)
            elif prix < 1056 :
                tab[527].append(prix)
            elif prix < 1058 :
                tab[528].append(prix)
            elif prix < 1060 :
                tab[529].append(prix)
            elif prix < 1062 :
                tab[530].append(prix)
            elif prix < 1064 :
                tab[531].append(prix)
            elif prix < 1066 :
                tab[532].append(prix)
            elif prix < 1068 :
                tab[533].append(prix)
            elif prix < 1070 :
                tab[534].append(prix)
            elif prix < 1072 :
                tab[535].append(prix)
            elif prix < 1074 :
                tab[536].append(prix)
            elif prix < 1076 :
                tab[537].append(prix)
            elif prix < 1078 :
                tab[538].append(prix)
            elif prix < 1080 :
                tab[539].append(prix)
            elif prix < 1082 :
                tab[540].append(prix)
            elif prix < 1084 :
                tab[541].append(prix)
            elif prix < 1086 :
                tab[542].append(prix)
            elif prix < 1088 :
                tab[543].append(prix)
            elif prix < 1090 :
                tab[544].append(prix)
            elif prix < 1092 :
                tab[545].append(prix)
            elif prix < 1094 :
                tab[546].append(prix)
            elif prix < 1096 :
                tab[547].append(prix)
            elif prix < 1098 :
                tab[548].append(prix)
            elif prix < 1100 :
                tab[549].append(prix)
            elif prix < 1102 :
                tab[550].append(prix)
            elif prix < 1104 :
                tab[551].append(prix)
            elif prix < 1106 :
                tab[552].append(prix)
            elif prix < 1108 :
                tab[553].append(prix)
            elif prix < 1110 :
                tab[554].append(prix)
            elif prix < 1112 :
                tab[555].append(prix)
            elif prix < 1114 :
                tab[556].append(prix)
            elif prix < 1116 :
                tab[557].append(prix)
            elif prix < 1118 :
                tab[558].append(prix)
            elif prix < 1120 :
                tab[559].append(prix)
            elif prix < 1122 :
                tab[560].append(prix)
            elif prix < 1124 :
                tab[561].append(prix)
            elif prix < 1126 :
                tab[562].append(prix)
            elif prix < 1128 :
                tab[563].append(prix)
            elif prix < 1130 :
                tab[564].append(prix)
            elif prix < 1132 :
                tab[565].append(prix)
            elif prix < 1134 :
                tab[566].append(prix)
            elif prix < 1136 :
                tab[567].append(prix)
            elif prix < 1138 :
                tab[568].append(prix)
            elif prix < 1140 :
                tab[569].append(prix)
            elif prix < 1142 :
                tab[570].append(prix)
            elif prix < 1144 :
                tab[571].append(prix)
            elif prix < 1146 :
                tab[572].append(prix)
            elif prix < 1148 :
                tab[573].append(prix)
            elif prix < 1150 :
                tab[574].append(prix)
            elif prix < 1152 :
                tab[575].append(prix)
            elif prix < 1154 :
                tab[576].append(prix)
            elif prix < 1156 :
                tab[577].append(prix)
            elif prix < 1158 :
                tab[578].append(prix)
            elif prix < 1160 :
                tab[579].append(prix)
            elif prix < 1162 :
                tab[580].append(prix)
            elif prix < 1164 :
                tab[581].append(prix)
            elif prix < 1166 :
                tab[582].append(prix)
            elif prix < 1168 :
                tab[583].append(prix)
            elif prix < 1170 :
                tab[584].append(prix)
            elif prix < 1172 :
                tab[585].append(prix)
            elif prix < 1174 :
                tab[586].append(prix)
            elif prix < 1176 :
                tab[587].append(prix)
            elif prix < 1178 :
                tab[588].append(prix)
            elif prix < 1180 :
                tab[589].append(prix)
            elif prix < 1182 :
                tab[590].append(prix)
            elif prix < 1184 :
                tab[591].append(prix)
            elif prix < 1186 :
                tab[592].append(prix)
            elif prix < 1188 :
                tab[593].append(prix)
            elif prix < 1190 :
                tab[594].append(prix)
            elif prix < 1192 :
                tab[595].append(prix)
            elif prix < 1194 :
                tab[596].append(prix)
            elif prix < 1196 :
                tab[597].append(prix)
            elif prix < 1198 :
                tab[598].append(prix)
            elif prix < 1200 :
                tab[599].append(prix)
            elif prix < 1202 :
                tab[600].append(prix)
            elif prix < 1204 :
                tab[601].append(prix)
            elif prix < 1206 :
                tab[602].append(prix)
            elif prix < 1208 :
                tab[603].append(prix)
            elif prix < 1210 :
                tab[604].append(prix)
            elif prix < 1212 :
                tab[605].append(prix)
            elif prix < 1214 :
                tab[606].append(prix)
            elif prix < 1216 :
                tab[607].append(prix)
            elif prix < 1218 :
                tab[608].append(prix)
            elif prix < 1220 :
                tab[609].append(prix)
            elif prix < 1222 :
                tab[610].append(prix)
            elif prix < 1224 :
                tab[611].append(prix)
            elif prix < 1226 :
                tab[612].append(prix)
            elif prix < 1228 :
                tab[613].append(prix)
            elif prix < 1230 :
                tab[614].append(prix)
            elif prix < 1232 :
                tab[615].append(prix)
            elif prix < 1234 :
                tab[616].append(prix)
            elif prix < 1236 :
                tab[617].append(prix)
            elif prix < 1238 :
                tab[618].append(prix)
            elif prix < 1240 :
                tab[619].append(prix)
            elif prix < 1242 :
                tab[620].append(prix)
            elif prix < 1244 :
                tab[621].append(prix)
            elif prix < 1246 :
                tab[622].append(prix)
            elif prix < 1248 :
                tab[623].append(prix)
            elif prix < 1250 :
                tab[624].append(prix)
            elif prix < 1252 :
                tab[625].append(prix)
            elif prix < 1254 :
                tab[626].append(prix)
            elif prix < 1256 :
                tab[627].append(prix)
            elif prix < 1258 :
                tab[628].append(prix)
            elif prix < 1260 :
                tab[629].append(prix)
            elif prix < 1262 :
                tab[630].append(prix)
            elif prix < 1264 :
                tab[631].append(prix)
            elif prix < 1266 :
                tab[632].append(prix)
            elif prix < 1268 :
                tab[633].append(prix)
            elif prix < 1270 :
                tab[634].append(prix)
            elif prix < 1272 :
                tab[635].append(prix)
            elif prix < 1274 :
                tab[636].append(prix)
            elif prix < 1276 :
                tab[637].append(prix)
            elif prix < 1278 :
                tab[638].append(prix)
            elif prix < 1280 :
                tab[639].append(prix)
            elif prix < 1282 :
                tab[640].append(prix)
            elif prix < 1284 :
                tab[641].append(prix)
            elif prix < 1286 :
                tab[642].append(prix)
            elif prix < 1288 :
                tab[643].append(prix)
            elif prix < 1290 :
                tab[644].append(prix)
            elif prix < 1292 :
                tab[645].append(prix)
            elif prix < 1294 :
                tab[646].append(prix)
            elif prix < 1296 :
                tab[647].append(prix)
            elif prix < 1298 :
                tab[648].append(prix)
            elif prix < 1300 :
                tab[649].append(prix)
            elif prix < 1302 :
                tab[650].append(prix)
            elif prix < 1304 :
                tab[651].append(prix)
            elif prix < 1306 :
                tab[652].append(prix)
            elif prix < 1308 :
                tab[653].append(prix)
            elif prix < 1310 :
                tab[654].append(prix)
            elif prix < 1312 :
                tab[655].append(prix)
            elif prix < 1314 :
                tab[656].append(prix)
            elif prix < 1316 :
                tab[657].append(prix)
            elif prix < 1318 :
                tab[658].append(prix)
            elif prix < 1320 :
                tab[659].append(prix)
            elif prix < 1322 :
                tab[660].append(prix)
            elif prix < 1324 :
                tab[661].append(prix)
            elif prix < 1326 :
                tab[662].append(prix)
            elif prix < 1328 :
                tab[663].append(prix)
            elif prix < 1330 :
                tab[664].append(prix)
            elif prix < 1332 :
                tab[665].append(prix)
            elif prix < 1334 :
                tab[666].append(prix)
            elif prix < 1336 :
                tab[667].append(prix)
            elif prix < 1338 :
                tab[668].append(prix)
            elif prix < 1340 :
                tab[669].append(prix)
            elif prix < 1342 :
                tab[670].append(prix)
            elif prix < 1344 :
                tab[671].append(prix)
            elif prix < 1346 :
                tab[672].append(prix)
            elif prix < 1348 :
                tab[673].append(prix)
            elif prix < 1350 :
                tab[674].append(prix)
            elif prix < 1352 :
                tab[675].append(prix)
            elif prix < 1354 :
                tab[676].append(prix)
            elif prix < 1356 :
                tab[677].append(prix)
            elif prix < 1358 :
                tab[678].append(prix)
            elif prix < 1360 :
                tab[679].append(prix)
            elif prix < 1362 :
                tab[680].append(prix)
            elif prix < 1364 :
                tab[681].append(prix)
            elif prix < 1366 :
                tab[682].append(prix)
            elif prix < 1368 :
                tab[683].append(prix)
            elif prix < 1370 :
                tab[684].append(prix)
            elif prix < 1372 :
                tab[685].append(prix)
            elif prix < 1374 :
                tab[686].append(prix)
            elif prix < 1376 :
                tab[687].append(prix)
            elif prix < 1378 :
                tab[688].append(prix)
            elif prix < 1380 :
                tab[689].append(prix)
            elif prix < 1382 :
                tab[690].append(prix)
            elif prix < 1384 :
                tab[691].append(prix)
            elif prix < 1386 :
                tab[692].append(prix)
            elif prix < 1388 :
                tab[693].append(prix)
            elif prix < 1390 :
                tab[694].append(prix)
            elif prix < 1392 :
                tab[695].append(prix)
            elif prix < 1394 :
                tab[696].append(prix)
            elif prix < 1396 :
                tab[697].append(prix)
            elif prix < 1398 :
                tab[698].append(prix)
            elif prix < 1400 :
                tab[699].append(prix)
            elif prix < 1402 :
                tab[700].append(prix)
            elif prix < 1404 :
                tab[701].append(prix)
            elif prix < 1406 :
                tab[702].append(prix)
            elif prix < 1408 :
                tab[703].append(prix)
            elif prix < 1410 :
                tab[704].append(prix)
            elif prix < 1412 :
                tab[705].append(prix)
            elif prix < 1414 :
                tab[706].append(prix)
            elif prix < 1416 :
                tab[707].append(prix)
            elif prix < 1418 :
                tab[708].append(prix)
            elif prix < 1420 :
                tab[709].append(prix)
            elif prix < 1422 :
                tab[710].append(prix)
            elif prix < 1424 :
                tab[711].append(prix)
            elif prix < 1426 :
                tab[712].append(prix)
            elif prix < 1428 :
                tab[713].append(prix)
            elif prix < 1430 :
                tab[714].append(prix)
            elif prix < 1432 :
                tab[715].append(prix)
            elif prix < 1434 :
                tab[716].append(prix)
            elif prix < 1436 :
                tab[717].append(prix)
            elif prix < 1438 :
                tab[718].append(prix)
            elif prix < 1440 :
                tab[719].append(prix)
            elif prix < 1442 :
                tab[720].append(prix)
            elif prix < 1444 :
                tab[721].append(prix)
            elif prix < 1446 :
                tab[722].append(prix)
            elif prix < 1448 :
                tab[723].append(prix)
            elif prix < 1450 :
                tab[724].append(prix)
            elif prix < 1452 :
                tab[725].append(prix)
            elif prix < 1454 :
                tab[726].append(prix)
            elif prix < 1456 :
                tab[727].append(prix)
            elif prix < 1458 :
                tab[728].append(prix)
            elif prix < 1460 :
                tab[729].append(prix)
            elif prix < 1462 :
                tab[730].append(prix)
            elif prix < 1464 :
                tab[731].append(prix)
            elif prix < 1466 :
                tab[732].append(prix)
            elif prix < 1468 :
                tab[733].append(prix)
            elif prix < 1470 :
                tab[734].append(prix)
            elif prix < 1472 :
                tab[735].append(prix)
            elif prix < 1474 :
                tab[736].append(prix)
            elif prix < 1476 :
                tab[737].append(prix)
            elif prix < 1478 :
                tab[738].append(prix)
            elif prix < 1480 :
                tab[739].append(prix)
            elif prix < 1482 :
                tab[740].append(prix)
            elif prix < 1484 :
                tab[741].append(prix)
            elif prix < 1486 :
                tab[742].append(prix)
            elif prix < 1488 :
                tab[743].append(prix)
            elif prix < 1490 :
                tab[744].append(prix)
            elif prix < 1492 :
                tab[745].append(prix)
            elif prix < 1494 :
                tab[746].append(prix)
            elif prix < 1496 :
                tab[747].append(prix)
            elif prix < 1498 :
                tab[748].append(prix)
            elif prix < 1500 :
                tab[749].append(prix)
            elif prix < 1502 :
                tab[750].append(prix)
            elif prix < 1504 :
                tab[751].append(prix)
            elif prix < 1506 :
                tab[752].append(prix)
            elif prix < 1508 :
                tab[753].append(prix)
            elif prix < 1510 :
                tab[754].append(prix)
            elif prix < 1512 :
                tab[755].append(prix)
            elif prix < 1514 :
                tab[756].append(prix)
            elif prix < 1516 :
                tab[757].append(prix)
            elif prix < 1518 :
                tab[758].append(prix)
            elif prix < 1520 :
                tab[759].append(prix)
            elif prix < 1522 :
                tab[760].append(prix)
            elif prix < 1524 :
                tab[761].append(prix)
            elif prix < 1526 :
                tab[762].append(prix)
            elif prix < 1528 :
                tab[763].append(prix)
            elif prix < 1530 :
                tab[764].append(prix)
            elif prix < 1532 :
                tab[765].append(prix)
            elif prix < 1534 :
                tab[766].append(prix)
            elif prix < 1536 :
                tab[767].append(prix)
            elif prix < 1538 :
                tab[768].append(prix)
            elif prix < 1540 :
                tab[769].append(prix)
            elif prix < 1542 :
                tab[770].append(prix)
            elif prix < 1544 :
                tab[771].append(prix)
            elif prix < 1546 :
                tab[772].append(prix)
            elif prix < 1548 :
                tab[773].append(prix)
            elif prix < 1550 :
                tab[774].append(prix)
            elif prix < 1552 :
                tab[775].append(prix)
            elif prix < 1554 :
                tab[776].append(prix)
            elif prix < 1556 :
                tab[777].append(prix)
            elif prix < 1558 :
                tab[778].append(prix)
            elif prix < 1560 :
                tab[779].append(prix)
            elif prix < 1562 :
                tab[780].append(prix)
            elif prix < 1564 :
                tab[781].append(prix)
            elif prix < 1566 :
                tab[782].append(prix)
            elif prix < 1568 :
                tab[783].append(prix)
            elif prix < 1570 :
                tab[784].append(prix)
            elif prix < 1572 :
                tab[785].append(prix)
            elif prix < 1574 :
                tab[786].append(prix)
            elif prix < 1576 :
                tab[787].append(prix)
            elif prix < 1578 :
                tab[788].append(prix)
            elif prix < 1580 :
                tab[789].append(prix)
            elif prix < 1582 :
                tab[790].append(prix)
            elif prix < 1584 :
                tab[791].append(prix)
            elif prix < 1586 :
                tab[792].append(prix)
            elif prix < 1588 :
                tab[793].append(prix)
            elif prix < 1590 :
                tab[794].append(prix)
            elif prix < 1592 :
                tab[795].append(prix)
            elif prix < 1594 :
                tab[796].append(prix)
            elif prix < 1596 :
                tab[797].append(prix)
            elif prix < 1598 :
                tab[798].append(prix)
            elif prix < 1600 :
                tab[799].append(prix)
            elif prix < 1602 :
                tab[800].append(prix)
            elif prix < 1604 :
                tab[801].append(prix)
            elif prix < 1606 :
                tab[802].append(prix)
            elif prix < 1608 :
                tab[803].append(prix)
            elif prix < 1610 :
                tab[804].append(prix)
            elif prix < 1612 :
                tab[805].append(prix)
            elif prix < 1614 :
                tab[806].append(prix)
            elif prix < 1616 :
                tab[807].append(prix)
            elif prix < 1618 :
                tab[808].append(prix)
            elif prix < 1620 :
                tab[809].append(prix)
            elif prix < 1622 :
                tab[810].append(prix)
            elif prix < 1624 :
                tab[811].append(prix)
            elif prix < 1626 :
                tab[812].append(prix)
            elif prix < 1628 :
                tab[813].append(prix)
            elif prix < 1630 :
                tab[814].append(prix)
            elif prix < 1632 :
                tab[815].append(prix)
            elif prix < 1634 :
                tab[816].append(prix)
            elif prix < 1636 :
                tab[817].append(prix)
            elif prix < 1638 :
                tab[818].append(prix)
            elif prix < 1640 :
                tab[819].append(prix)
            elif prix < 1642 :
                tab[820].append(prix)
            elif prix < 1644 :
                tab[821].append(prix)
            elif prix < 1646 :
                tab[822].append(prix)
            elif prix < 1648 :
                tab[823].append(prix)
            elif prix < 1650 :
                tab[824].append(prix)
            elif prix < 1652 :
                tab[825].append(prix)
            elif prix < 1654 :
                tab[826].append(prix)
            elif prix < 1656 :
                tab[827].append(prix)
            elif prix < 1658 :
                tab[828].append(prix)
            elif prix < 1660 :
                tab[829].append(prix)
            elif prix < 1662 :
                tab[830].append(prix)
            elif prix < 1664 :
                tab[831].append(prix)
            elif prix < 1666 :
                tab[832].append(prix)
            elif prix < 1668 :
                tab[833].append(prix)
            elif prix < 1670 :
                tab[834].append(prix)
            elif prix < 1672 :
                tab[835].append(prix)
            elif prix < 1674 :
                tab[836].append(prix)
            elif prix < 1676 :
                tab[837].append(prix)
            elif prix < 1678 :
                tab[838].append(prix)
            elif prix < 1680 :
                tab[839].append(prix)
            elif prix < 1682 :
                tab[840].append(prix)
            elif prix < 1684 :
                tab[841].append(prix)
            elif prix < 1686 :
                tab[842].append(prix)
            elif prix < 1688 :
                tab[843].append(prix)
            elif prix < 1690 :
                tab[844].append(prix)
            elif prix < 1692 :
                tab[845].append(prix)
            elif prix < 1694 :
                tab[846].append(prix)
            elif prix < 1696 :
                tab[847].append(prix)
            elif prix < 1698 :
                tab[848].append(prix)
            elif prix < 1700 :
                tab[849].append(prix)
            elif prix < 1702 :
                tab[850].append(prix)
            elif prix < 1704 :
                tab[851].append(prix)
            elif prix < 1706 :
                tab[852].append(prix)
            elif prix < 1708 :
                tab[853].append(prix)
            elif prix < 1710 :
                tab[854].append(prix)
            elif prix < 1712 :
                tab[855].append(prix)
            elif prix < 1714 :
                tab[856].append(prix)
            elif prix < 1716 :
                tab[857].append(prix)
            elif prix < 1718 :
                tab[858].append(prix)
            elif prix < 1720 :
                tab[859].append(prix)
            elif prix < 1722 :
                tab[860].append(prix)
            elif prix < 1724 :
                tab[861].append(prix)
            elif prix < 1726 :
                tab[862].append(prix)
            elif prix < 1728 :
                tab[863].append(prix)
            elif prix < 1730 :
                tab[864].append(prix)
            elif prix < 1732 :
                tab[865].append(prix)
            elif prix < 1734 :
                tab[866].append(prix)
            elif prix < 1736 :
                tab[867].append(prix)
            elif prix < 1738 :
                tab[868].append(prix)
            elif prix < 1740 :
                tab[869].append(prix)
            elif prix < 1742 :
                tab[870].append(prix)
            elif prix < 1744 :
                tab[871].append(prix)
            elif prix < 1746 :
                tab[872].append(prix)
            elif prix < 1748 :
                tab[873].append(prix)
            elif prix < 1750 :
                tab[874].append(prix)
            elif prix < 1752 :
                tab[875].append(prix)
            elif prix < 1754 :
                tab[876].append(prix)
            elif prix < 1756 :
                tab[877].append(prix)
            elif prix < 1758 :
                tab[878].append(prix)
            elif prix < 1760 :
                tab[879].append(prix)
            elif prix < 1762 :
                tab[880].append(prix)
            elif prix < 1764 :
                tab[881].append(prix)
            elif prix < 1766 :
                tab[882].append(prix)
            elif prix < 1768 :
                tab[883].append(prix)
            elif prix < 1770 :
                tab[884].append(prix)
            elif prix < 1772 :
                tab[885].append(prix)
            elif prix < 1774 :
                tab[886].append(prix)
            elif prix < 1776 :
                tab[887].append(prix)
            elif prix < 1778 :
                tab[888].append(prix)
            elif prix < 1780 :
                tab[889].append(prix)
            elif prix < 1782 :
                tab[890].append(prix)
            elif prix < 1784 :
                tab[891].append(prix)
            elif prix < 1786 :
                tab[892].append(prix)
            elif prix < 1788 :
                tab[893].append(prix)
            elif prix < 1790 :
                tab[894].append(prix)
            elif prix < 1792 :
                tab[895].append(prix)
            elif prix < 1794 :
                tab[896].append(prix)
            elif prix < 1796 :
                tab[897].append(prix)
            elif prix < 1798 :
                tab[898].append(prix)
            elif prix < 1800 :
                tab[899].append(prix)
            elif prix < 1802 :
                tab[900].append(prix)
            elif prix < 1804 :
                tab[901].append(prix)
            elif prix < 1806 :
                tab[902].append(prix)
            elif prix < 1808 :
                tab[903].append(prix)
            elif prix < 1810 :
                tab[904].append(prix)
            elif prix < 1812 :
                tab[905].append(prix)
            elif prix < 1814 :
                tab[906].append(prix)
            elif prix < 1816 :
                tab[907].append(prix)
            elif prix < 1818 :
                tab[908].append(prix)
            elif prix < 1820 :
                tab[909].append(prix)
            elif prix < 1822 :
                tab[910].append(prix)
            elif prix < 1824 :
                tab[911].append(prix)
            elif prix < 1826 :
                tab[912].append(prix)
            elif prix < 1828 :
                tab[913].append(prix)
            elif prix < 1830 :
                tab[914].append(prix)
            elif prix < 1832 :
                tab[915].append(prix)
            elif prix < 1834 :
                tab[916].append(prix)
            elif prix < 1836 :
                tab[917].append(prix)
            elif prix < 1838 :
                tab[918].append(prix)
            elif prix < 1840 :
                tab[919].append(prix)
            elif prix < 1842 :
                tab[920].append(prix)
            elif prix < 1844 :
                tab[921].append(prix)
            elif prix < 1846 :
                tab[922].append(prix)
            elif prix < 1848 :
                tab[923].append(prix)
            elif prix < 1850 :
                tab[924].append(prix)
            elif prix < 1852 :
                tab[925].append(prix)
            elif prix < 1854 :
                tab[926].append(prix)
            elif prix < 1856 :
                tab[927].append(prix)
            elif prix < 1858 :
                tab[928].append(prix)
            elif prix < 1860 :
                tab[929].append(prix)
            elif prix < 1862 :
                tab[930].append(prix)
            elif prix < 1864 :
                tab[931].append(prix)
            elif prix < 1866 :
                tab[932].append(prix)
            elif prix < 1868 :
                tab[933].append(prix)
            elif prix < 1870 :
                tab[934].append(prix)
            elif prix < 1872 :
                tab[935].append(prix)
            elif prix < 1874 :
                tab[936].append(prix)
            elif prix < 1876 :
                tab[937].append(prix)
            elif prix < 1878 :
                tab[938].append(prix)
            elif prix < 1880 :
                tab[939].append(prix)
            elif prix < 1882 :
                tab[940].append(prix)
            elif prix < 1884 :
                tab[941].append(prix)
            elif prix < 1886 :
                tab[942].append(prix)
            elif prix < 1888 :
                tab[943].append(prix)
            elif prix < 1890 :
                tab[944].append(prix)
            elif prix < 1892 :
                tab[945].append(prix)
            elif prix < 1894 :
                tab[946].append(prix)
            elif prix < 1896 :
                tab[947].append(prix)
            elif prix < 1898 :
                tab[948].append(prix)
            elif prix < 1900 :
                tab[949].append(prix)
            elif prix < 1902 :
                tab[950].append(prix)
            elif prix < 1904 :
                tab[951].append(prix)
            elif prix < 1906 :
                tab[952].append(prix)
            elif prix < 1908 :
                tab[953].append(prix)
            elif prix < 1910 :
                tab[954].append(prix)
            elif prix < 1912 :
                tab[955].append(prix)
            elif prix < 1914 :
                tab[956].append(prix)
            elif prix < 1916 :
                tab[957].append(prix)
            elif prix < 1918 :
                tab[958].append(prix)
            elif prix < 1920 :
                tab[959].append(prix)
            elif prix < 1922 :
                tab[960].append(prix)
            elif prix < 1924 :
                tab[961].append(prix)
            elif prix < 1926 :
                tab[962].append(prix)
            elif prix < 1928 :
                tab[963].append(prix)
            elif prix < 1930 :
                tab[964].append(prix)
            elif prix < 1932 :
                tab[965].append(prix)
            elif prix < 1934 :
                tab[966].append(prix)
            elif prix < 1936 :
                tab[967].append(prix)
            elif prix < 1938 :
                tab[968].append(prix)
            elif prix < 1940 :
                tab[969].append(prix)
            elif prix < 1942 :
                tab[970].append(prix)
            elif prix < 1944 :
                tab[971].append(prix)
            elif prix < 1946 :
                tab[972].append(prix)
            elif prix < 1948 :
                tab[973].append(prix)
            elif prix < 1950 :
                tab[974].append(prix)
            elif prix < 1952 :
                tab[975].append(prix)
            elif prix < 1954 :
                tab[976].append(prix)
            elif prix < 1956 :
                tab[977].append(prix)
            elif prix < 1958 :
                tab[978].append(prix)
            elif prix < 1960 :
                tab[979].append(prix)
            elif prix < 1962 :
                tab[980].append(prix)
            elif prix < 1964 :
                tab[981].append(prix)
            elif prix < 1966 :
                tab[982].append(prix)
            elif prix < 1968 :
                tab[983].append(prix)
            elif prix < 1970 :
                tab[984].append(prix)
            elif prix < 1972 :
                tab[985].append(prix)
            elif prix < 1974 :
                tab[986].append(prix)
            elif prix < 1976 :
                tab[987].append(prix)
            elif prix < 1978 :
                tab[988].append(prix)
            elif prix < 1980 :
                tab[989].append(prix)
            elif prix < 1982 :
                tab[990].append(prix)
            elif prix < 1984 :
                tab[991].append(prix)
            elif prix < 1986 :
                tab[992].append(prix)
            elif prix < 1988 :
                tab[993].append(prix)
            elif prix < 1990 :
                tab[994].append(prix)
            elif prix < 1992 :
                tab[995].append(prix)
            elif prix < 1994 :
                tab[996].append(prix)
            elif prix < 1996 :
                tab[997].append(prix)
            elif prix < 1998 :
                tab[998].append(prix)
            elif prix < 2000 :
                tab[999].append(prix)
            elif prix < 2002 :
                tab[1000].append(prix)
            elif prix < 2004 :
                tab[1001].append(prix)
            elif prix < 2006 :
                tab[1002].append(prix)
            elif prix < 2008 :
                tab[1003].append(prix)
            elif prix < 2010 :
                tab[1004].append(prix)
            elif prix < 2012 :
                tab[1005].append(prix)
            elif prix < 2014 :
                tab[1006].append(prix)
            elif prix < 2016 :
                tab[1007].append(prix)
            elif prix < 2018 :
                tab[1008].append(prix)
            elif prix < 2020 :
                tab[1009].append(prix)
            elif prix < 2022 :
                tab[1010].append(prix)
            elif prix < 2024 :
                tab[1011].append(prix)
            elif prix < 2026 :
                tab[1012].append(prix)
            elif prix < 2028 :
                tab[1013].append(prix)
            elif prix < 2030 :
                tab[1014].append(prix)
            elif prix < 2032 :
                tab[1015].append(prix)
            elif prix < 2034 :
                tab[1016].append(prix)
            elif prix < 2036 :
                tab[1017].append(prix)
            elif prix < 2038 :
                tab[1018].append(prix)
            elif prix < 2040 :
                tab[1019].append(prix)
            elif prix < 2042 :
                tab[1020].append(prix)
            elif prix < 2044 :
                tab[1021].append(prix)
            elif prix < 2046 :
                tab[1022].append(prix)
            elif prix < 2048 :
                tab[1023].append(prix)
            elif prix < 2050 :
                tab[1024].append(prix)
            elif prix < 2052 :
                tab[1025].append(prix)
            elif prix < 2054 :
                tab[1026].append(prix)
            elif prix < 2056 :
                tab[1027].append(prix)
            elif prix < 2058 :
                tab[1028].append(prix)
            elif prix < 2060 :
                tab[1029].append(prix)
            elif prix < 2062 :
                tab[1030].append(prix)
            elif prix < 2064 :
                tab[1031].append(prix)
            elif prix < 2066 :
                tab[1032].append(prix)
            elif prix < 2068 :
                tab[1033].append(prix)
            elif prix < 2070 :
                tab[1034].append(prix)
            elif prix < 2072 :
                tab[1035].append(prix)
            elif prix < 2074 :
                tab[1036].append(prix)
            elif prix < 2076 :
                tab[1037].append(prix)
            elif prix < 2078 :
                tab[1038].append(prix)
            elif prix < 2080 :
                tab[1039].append(prix)
            elif prix < 2082 :
                tab[1040].append(prix)
            elif prix < 2084 :
                tab[1041].append(prix)
            elif prix < 2086 :
                tab[1042].append(prix)
            elif prix < 2088 :
                tab[1043].append(prix)
            elif prix < 2090 :
                tab[1044].append(prix)
            elif prix < 2092 :
                tab[1045].append(prix)
            elif prix < 2094 :
                tab[1046].append(prix)
            elif prix < 2096 :
                tab[1047].append(prix)
            elif prix < 2098 :
                tab[1048].append(prix)
            elif prix < 2100 :
                tab[1049].append(prix)
            elif prix < 2102 :
                tab[1050].append(prix)
            elif prix < 2104 :
                tab[1051].append(prix)
            elif prix < 2106 :
                tab[1052].append(prix)
            elif prix < 2108 :
                tab[1053].append(prix)
            elif prix < 2110 :
                tab[1054].append(prix)
            elif prix < 2112 :
                tab[1055].append(prix)
            elif prix < 2114 :
                tab[1056].append(prix)
            elif prix < 2116 :
                tab[1057].append(prix)
            elif prix < 2118 :
                tab[1058].append(prix)
            elif prix < 2120 :
                tab[1059].append(prix)
            elif prix < 2122 :
                tab[1060].append(prix)
            elif prix < 2124 :
                tab[1061].append(prix)
            elif prix < 2126 :
                tab[1062].append(prix)
            elif prix < 2128 :
                tab[1063].append(prix)
            elif prix < 2130 :
                tab[1064].append(prix)
            elif prix < 2132 :
                tab[1065].append(prix)
            elif prix < 2134 :
                tab[1066].append(prix)
            elif prix < 2136 :
                tab[1067].append(prix)
            elif prix < 2138 :
                tab[1068].append(prix)
            elif prix < 2140 :
                tab[1069].append(prix)
            elif prix < 2142 :
                tab[1070].append(prix)
            elif prix < 2144 :
                tab[1071].append(prix)
            elif prix < 2146 :
                tab[1072].append(prix)
            elif prix < 2148 :
                tab[1073].append(prix)
            elif prix < 2150 :
                tab[1074].append(prix)
            elif prix < 2152 :
                tab[1075].append(prix)
            elif prix < 2154 :
                tab[1076].append(prix)
            elif prix < 2156 :
                tab[1077].append(prix)
            elif prix < 2158 :
                tab[1078].append(prix)
            elif prix < 2160 :
                tab[1079].append(prix)
            elif prix < 2162 :
                tab[1080].append(prix)
            elif prix < 2164 :
                tab[1081].append(prix)
            elif prix < 2166 :
                tab[1082].append(prix)
            elif prix < 2168 :
                tab[1083].append(prix)
            elif prix < 2170 :
                tab[1084].append(prix)
            elif prix < 2172 :
                tab[1085].append(prix)
            elif prix < 2174 :
                tab[1086].append(prix)
            elif prix < 2176 :
                tab[1087].append(prix)
            elif prix < 2178 :
                tab[1088].append(prix)
            elif prix < 2180 :
                tab[1089].append(prix)
            elif prix < 2182 :
                tab[1090].append(prix)
            elif prix < 2184 :
                tab[1091].append(prix)
            elif prix < 2186 :
                tab[1092].append(prix)
            elif prix < 2188 :
                tab[1093].append(prix)
            elif prix < 2190 :
                tab[1094].append(prix)
            elif prix < 2192 :
                tab[1095].append(prix)
            elif prix < 2194 :
                tab[1096].append(prix)
            elif prix < 2196 :
                tab[1097].append(prix)
            elif prix < 2198 :
                tab[1098].append(prix)
            elif prix < 2200 :
                tab[1099].append(prix)
            elif prix < 2202 :
                tab[1100].append(prix)
            elif prix < 2204 :
                tab[1101].append(prix)
            elif prix < 2206 :
                tab[1102].append(prix)
            elif prix < 2208 :
                tab[1103].append(prix)
            elif prix < 2210 :
                tab[1104].append(prix)
            elif prix < 2212 :
                tab[1105].append(prix)
            elif prix < 2214 :
                tab[1106].append(prix)
            elif prix < 2216 :
                tab[1107].append(prix)
            elif prix < 2218 :
                tab[1108].append(prix)
            elif prix < 2220 :
                tab[1109].append(prix)
            elif prix < 2222 :
                tab[1110].append(prix)
            elif prix < 2224 :
                tab[1111].append(prix)
            elif prix < 2226 :
                tab[1112].append(prix)
            elif prix < 2228 :
                tab[1113].append(prix)
            elif prix < 2230 :
                tab[1114].append(prix)
            elif prix < 2232 :
                tab[1115].append(prix)
            elif prix < 2234 :
                tab[1116].append(prix)
            elif prix < 2236 :
                tab[1117].append(prix)
            elif prix < 2238 :
                tab[1118].append(prix)
            elif prix < 2240 :
                tab[1119].append(prix)
            elif prix < 2242 :
                tab[1120].append(prix)
            elif prix < 2244 :
                tab[1121].append(prix)
            elif prix < 2246 :
                tab[1122].append(prix)
            elif prix < 2248 :
                tab[1123].append(prix)
            elif prix < 2250 :
                tab[1124].append(prix)
            elif prix < 2252 :
                tab[1125].append(prix)
            elif prix < 2254 :
                tab[1126].append(prix)
            elif prix < 2256 :
                tab[1127].append(prix)
            elif prix < 2258 :
                tab[1128].append(prix)
            elif prix < 2260 :
                tab[1129].append(prix)
            elif prix < 2262 :
                tab[1130].append(prix)
            elif prix < 2264 :
                tab[1131].append(prix)
            elif prix < 2266 :
                tab[1132].append(prix)
            elif prix < 2268 :
                tab[1133].append(prix)
            elif prix < 2270 :
                tab[1134].append(prix)
            elif prix < 2272 :
                tab[1135].append(prix)
            elif prix < 2274 :
                tab[1136].append(prix)
            elif prix < 2276 :
                tab[1137].append(prix)
            elif prix < 2278 :
                tab[1138].append(prix)
            elif prix < 2280 :
                tab[1139].append(prix)
            elif prix < 2282 :
                tab[1140].append(prix)
            elif prix < 2284 :
                tab[1141].append(prix)
            elif prix < 2286 :
                tab[1142].append(prix)
            elif prix < 2288 :
                tab[1143].append(prix)
            elif prix < 2290 :
                tab[1144].append(prix)
            elif prix < 2292 :
                tab[1145].append(prix)
            elif prix < 2294 :
                tab[1146].append(prix)
            elif prix < 2296 :
                tab[1147].append(prix)
            elif prix < 2298 :
                tab[1148].append(prix)
            elif prix < 2300 :
                tab[1149].append(prix)
            elif prix < 2302 :
                tab[1150].append(prix)
            elif prix < 2304 :
                tab[1151].append(prix)
            elif prix < 2306 :
                tab[1152].append(prix)
            elif prix < 2308 :
                tab[1153].append(prix)
            elif prix < 2310 :
                tab[1154].append(prix)
            elif prix < 2312 :
                tab[1155].append(prix)
            elif prix < 2314 :
                tab[1156].append(prix)
            elif prix < 2316 :
                tab[1157].append(prix)
            elif prix < 2318 :
                tab[1158].append(prix)
            elif prix < 2320 :
                tab[1159].append(prix)
            elif prix < 2322 :
                tab[1160].append(prix)
            elif prix < 2324 :
                tab[1161].append(prix)
            elif prix < 2326 :
                tab[1162].append(prix)
            elif prix < 2328 :
                tab[1163].append(prix)
            elif prix < 2330 :
                tab[1164].append(prix)
            elif prix < 2332 :
                tab[1165].append(prix)
            elif prix < 2334 :
                tab[1166].append(prix)
            elif prix < 2336 :
                tab[1167].append(prix)
            elif prix < 2338 :
                tab[1168].append(prix)
            elif prix < 2340 :
                tab[1169].append(prix)
            elif prix < 2342 :
                tab[1170].append(prix)
            elif prix < 2344 :
                tab[1171].append(prix)
            elif prix < 2346 :
                tab[1172].append(prix)
            elif prix < 2348 :
                tab[1173].append(prix)
            elif prix < 2350 :
                tab[1174].append(prix)
            elif prix < 2352 :
                tab[1175].append(prix)
            elif prix < 2354 :
                tab[1176].append(prix)
            elif prix < 2356 :
                tab[1177].append(prix)
            elif prix < 2358 :
                tab[1178].append(prix)
            elif prix < 2360 :
                tab[1179].append(prix)
            elif prix < 2362 :
                tab[1180].append(prix)
            elif prix < 2364 :
                tab[1181].append(prix)
            elif prix < 2366 :
                tab[1182].append(prix)
            elif prix < 2368 :
                tab[1183].append(prix)
            elif prix < 2370 :
                tab[1184].append(prix)
            elif prix < 2372 :
                tab[1185].append(prix)
            elif prix < 2374 :
                tab[1186].append(prix)
            elif prix < 2376 :
                tab[1187].append(prix)
            elif prix < 2378 :
                tab[1188].append(prix)
            elif prix < 2380 :
                tab[1189].append(prix)
            elif prix < 2382 :
                tab[1190].append(prix)
            elif prix < 2384 :
                tab[1191].append(prix)
            elif prix < 2386 :
                tab[1192].append(prix)
            elif prix < 2388 :
                tab[1193].append(prix)
            elif prix < 2390 :
                tab[1194].append(prix)
            elif prix < 2392 :
                tab[1195].append(prix)
            elif prix < 2394 :
                tab[1196].append(prix)
            elif prix < 2396 :
                tab[1197].append(prix)
            elif prix < 2398 :
                tab[1198].append(prix)
            elif prix < 2400 :
                tab[1199].append(prix)
            elif prix < 2402 :
                tab[1200].append(prix)
            elif prix < 2404 :
                tab[1201].append(prix)
            elif prix < 2406 :
                tab[1202].append(prix)
            elif prix < 2408 :
                tab[1203].append(prix)
            elif prix < 2410 :
                tab[1204].append(prix)
            elif prix < 2412 :
                tab[1205].append(prix)
            elif prix < 2414 :
                tab[1206].append(prix)
            elif prix < 2416 :
                tab[1207].append(prix)
            elif prix < 2418 :
                tab[1208].append(prix)
            elif prix < 2420 :
                tab[1209].append(prix)
            elif prix < 2422 :
                tab[1210].append(prix)
            elif prix < 2424 :
                tab[1211].append(prix)
            elif prix < 2426 :
                tab[1212].append(prix)
            elif prix < 2428 :
                tab[1213].append(prix)
            elif prix < 2430 :
                tab[1214].append(prix)
            elif prix < 2432 :
                tab[1215].append(prix)
            elif prix < 2434 :
                tab[1216].append(prix)
            elif prix < 2436 :
                tab[1217].append(prix)
            elif prix < 2438 :
                tab[1218].append(prix)
            elif prix < 2440 :
                tab[1219].append(prix)
            elif prix < 2442 :
                tab[1220].append(prix)
            elif prix < 2444 :
                tab[1221].append(prix)
            elif prix < 2446 :
                tab[1222].append(prix)
            elif prix < 2448 :
                tab[1223].append(prix)
            elif prix < 2450 :
                tab[1224].append(prix)
            elif prix < 2452 :
                tab[1225].append(prix)
            elif prix < 2454 :
                tab[1226].append(prix)
            elif prix < 2456 :
                tab[1227].append(prix)
            elif prix < 2458 :
                tab[1228].append(prix)
            elif prix < 2460 :
                tab[1229].append(prix)
            elif prix < 2462 :
                tab[1230].append(prix)
            elif prix < 2464 :
                tab[1231].append(prix)
            elif prix < 2466 :
                tab[1232].append(prix)
            elif prix < 2468 :
                tab[1233].append(prix)
            elif prix < 2470 :
                tab[1234].append(prix)
            elif prix < 2472 :
                tab[1235].append(prix)
            elif prix < 2474 :
                tab[1236].append(prix)
            elif prix < 2476 :
                tab[1237].append(prix)
            elif prix < 2478 :
                tab[1238].append(prix)
            elif prix < 2480 :
                tab[1239].append(prix)
            elif prix < 2482 :
                tab[1240].append(prix)
            elif prix < 2484 :
                tab[1241].append(prix)
            elif prix < 2486 :
                tab[1242].append(prix)
            elif prix < 2488 :
                tab[1243].append(prix)
            elif prix < 2490 :
                tab[1244].append(prix)
            elif prix < 2492 :
                tab[1245].append(prix)
            elif prix < 2494 :
                tab[1246].append(prix)
            elif prix < 2496 :
                tab[1247].append(prix)
            elif prix < 2498 :
                tab[1248].append(prix)
            elif prix < 2500 :
                tab[1249].append(prix)
            elif prix < 2502 :
                tab[1250].append(prix)
            elif prix < 2504 :
                tab[1251].append(prix)
            elif prix < 2506 :
                tab[1252].append(prix)
            elif prix < 2508 :
                tab[1253].append(prix)
            elif prix < 2510 :
                tab[1254].append(prix)
            elif prix < 2512 :
                tab[1255].append(prix)
            elif prix < 2514 :
                tab[1256].append(prix)
            elif prix < 2516 :
                tab[1257].append(prix)
            elif prix < 2518 :
                tab[1258].append(prix)
            elif prix < 2520 :
                tab[1259].append(prix)
            elif prix < 2522 :
                tab[1260].append(prix)
            elif prix < 2524 :
                tab[1261].append(prix)
            elif prix < 2526 :
                tab[1262].append(prix)
            elif prix < 2528 :
                tab[1263].append(prix)
            elif prix < 2530 :
                tab[1264].append(prix)
            elif prix < 2532 :
                tab[1265].append(prix)
            elif prix < 2534 :
                tab[1266].append(prix)
            elif prix < 2536 :
                tab[1267].append(prix)
            elif prix < 2538 :
                tab[1268].append(prix)
            elif prix < 2540 :
                tab[1269].append(prix)
            elif prix < 2542 :
                tab[1270].append(prix)
            elif prix < 2544 :
                tab[1271].append(prix)
            elif prix < 2546 :
                tab[1272].append(prix)
            elif prix < 2548 :
                tab[1273].append(prix)
            elif prix < 2550 :
                tab[1274].append(prix)
            elif prix < 2552 :
                tab[1275].append(prix)
            elif prix < 2554 :
                tab[1276].append(prix)
            elif prix < 2556 :
                tab[1277].append(prix)
            elif prix < 2558 :
                tab[1278].append(prix)
            elif prix < 2560 :
                tab[1279].append(prix)
            elif prix < 2562 :
                tab[1280].append(prix)
            elif prix < 2564 :
                tab[1281].append(prix)
            elif prix < 2566 :
                tab[1282].append(prix)
            elif prix < 2568 :
                tab[1283].append(prix)
            elif prix < 2570 :
                tab[1284].append(prix)
            elif prix < 2572 :
                tab[1285].append(prix)
            elif prix < 2574 :
                tab[1286].append(prix)
            elif prix < 2576 :
                tab[1287].append(prix)
            elif prix < 2578 :
                tab[1288].append(prix)
            elif prix < 2580 :
                tab[1289].append(prix)
            elif prix < 2582 :
                tab[1290].append(prix)
            elif prix < 2584 :
                tab[1291].append(prix)
            elif prix < 2586 :
                tab[1292].append(prix)
            elif prix < 2588 :
                tab[1293].append(prix)
            elif prix < 2590 :
                tab[1294].append(prix)
            elif prix < 2592 :
                tab[1295].append(prix)
            elif prix < 2594 :
                tab[1296].append(prix)
            elif prix < 2596 :
                tab[1297].append(prix)
            elif prix < 2598 :
                tab[1298].append(prix)
            elif prix < 2600 :
                tab[1299].append(prix)
            elif prix < 2602 :
                tab[1300].append(prix)
            elif prix < 2604 :
                tab[1301].append(prix)
            elif prix < 2606 :
                tab[1302].append(prix)
            elif prix < 2608 :
                tab[1303].append(prix)
            elif prix < 2610 :
                tab[1304].append(prix)
            elif prix < 2612 :
                tab[1305].append(prix)
            elif prix < 2614 :
                tab[1306].append(prix)
            elif prix < 2616 :
                tab[1307].append(prix)
            elif prix < 2618 :
                tab[1308].append(prix)
            elif prix < 2620 :
                tab[1309].append(prix)
            elif prix < 2622 :
                tab[1310].append(prix)
            elif prix < 2624 :
                tab[1311].append(prix)
            elif prix < 2626 :
                tab[1312].append(prix)
            elif prix < 2628 :
                tab[1313].append(prix)
            elif prix < 2630 :
                tab[1314].append(prix)
            elif prix < 2632 :
                tab[1315].append(prix)
            elif prix < 2634 :
                tab[1316].append(prix)
            elif prix < 2636 :
                tab[1317].append(prix)
            elif prix < 2638 :
                tab[1318].append(prix)
            elif prix < 2640 :
                tab[1319].append(prix)
            elif prix < 2642 :
                tab[1320].append(prix)
            elif prix < 2644 :
                tab[1321].append(prix)
            elif prix < 2646 :
                tab[1322].append(prix)
            elif prix < 2648 :
                tab[1323].append(prix)
            elif prix < 2650 :
                tab[1324].append(prix)
            elif prix < 2652 :
                tab[1325].append(prix)
            elif prix < 2654 :
                tab[1326].append(prix)
            elif prix < 2656 :
                tab[1327].append(prix)
            elif prix < 2658 :
                tab[1328].append(prix)
            elif prix < 2660 :
                tab[1329].append(prix)
            elif prix < 2662 :
                tab[1330].append(prix)
            elif prix < 2664 :
                tab[1331].append(prix)
            elif prix < 2666 :
                tab[1332].append(prix)
            elif prix < 2668 :
                tab[1333].append(prix)
            elif prix < 2670 :
                tab[1334].append(prix)
            elif prix < 2672 :
                tab[1335].append(prix)
            elif prix < 2674 :
                tab[1336].append(prix)
            elif prix < 2676 :
                tab[1337].append(prix)
            elif prix < 2678 :
                tab[1338].append(prix)
            elif prix < 2680 :
                tab[1339].append(prix)
            elif prix < 2682 :
                tab[1340].append(prix)
            elif prix < 2684 :
                tab[1341].append(prix)
            elif prix < 2686 :
                tab[1342].append(prix)
            elif prix < 2688 :
                tab[1343].append(prix)
            elif prix < 2690 :
                tab[1344].append(prix)
            elif prix < 2692 :
                tab[1345].append(prix)
            elif prix < 2694 :
                tab[1346].append(prix)
            elif prix < 2696 :
                tab[1347].append(prix)
            elif prix < 2698 :
                tab[1348].append(prix)
            elif prix < 2700 :
                tab[1349].append(prix)
            elif prix < 2702 :
                tab[1350].append(prix)
            elif prix < 2704 :
                tab[1351].append(prix)
            elif prix < 2706 :
                tab[1352].append(prix)
            elif prix < 2708 :
                tab[1353].append(prix)
            elif prix < 2710 :
                tab[1354].append(prix)
            elif prix < 2712 :
                tab[1355].append(prix)
            elif prix < 2714 :
                tab[1356].append(prix)
            elif prix < 2716 :
                tab[1357].append(prix)
            elif prix < 2718 :
                tab[1358].append(prix)
            elif prix < 2720 :
                tab[1359].append(prix)
            elif prix < 2722 :
                tab[1360].append(prix)
            elif prix < 2724 :
                tab[1361].append(prix)
            elif prix < 2726 :
                tab[1362].append(prix)
            elif prix < 2728 :
                tab[1363].append(prix)
            elif prix < 2730 :
                tab[1364].append(prix)
            elif prix < 2732 :
                tab[1365].append(prix)
            elif prix < 2734 :
                tab[1366].append(prix)
            elif prix < 2736 :
                tab[1367].append(prix)
            elif prix < 2738 :
                tab[1368].append(prix)
            elif prix < 2740 :
                tab[1369].append(prix)
            elif prix < 2742 :
                tab[1370].append(prix)
            elif prix < 2744 :
                tab[1371].append(prix)
            elif prix < 2746 :
                tab[1372].append(prix)
            elif prix < 2748 :
                tab[1373].append(prix)
            elif prix < 2750 :
                tab[1374].append(prix)
            elif prix < 2752 :
                tab[1375].append(prix)
            elif prix < 2754 :
                tab[1376].append(prix)
            elif prix < 2756 :
                tab[1377].append(prix)
            elif prix < 2758 :
                tab[1378].append(prix)
            elif prix < 2760 :
                tab[1379].append(prix)
            elif prix < 2762 :
                tab[1380].append(prix)
            elif prix < 2764 :
                tab[1381].append(prix)
            elif prix < 2766 :
                tab[1382].append(prix)
            elif prix < 2768 :
                tab[1383].append(prix)
            elif prix < 2770 :
                tab[1384].append(prix)
            elif prix < 2772 :
                tab[1385].append(prix)
            elif prix < 2774 :
                tab[1386].append(prix)
            elif prix < 2776 :
                tab[1387].append(prix)
            elif prix < 2778 :
                tab[1388].append(prix)
            elif prix < 2780 :
                tab[1389].append(prix)
            elif prix < 2782 :
                tab[1390].append(prix)
            elif prix < 2784 :
                tab[1391].append(prix)
            elif prix < 2786 :
                tab[1392].append(prix)
            elif prix < 2788 :
                tab[1393].append(prix)
            elif prix < 2790 :
                tab[1394].append(prix)
            elif prix < 2792 :
                tab[1395].append(prix)
            elif prix < 2794 :
                tab[1396].append(prix)
            elif prix < 2796 :
                tab[1397].append(prix)
            elif prix < 2798 :
                tab[1398].append(prix)
            elif prix < 2800 :
                tab[1399].append(prix)
            elif prix < 2802 :
                tab[1400].append(prix)
            elif prix < 2804 :
                tab[1401].append(prix)
            elif prix < 2806 :
                tab[1402].append(prix)
            elif prix < 2808 :
                tab[1403].append(prix)
            elif prix < 2810 :
                tab[1404].append(prix)
            elif prix < 2812 :
                tab[1405].append(prix)
            elif prix < 2814 :
                tab[1406].append(prix)
            elif prix < 2816 :
                tab[1407].append(prix)
            elif prix < 2818 :
                tab[1408].append(prix)
            elif prix < 2820 :
                tab[1409].append(prix)
            elif prix < 2822 :
                tab[1410].append(prix)
            elif prix < 2824 :
                tab[1411].append(prix)
            elif prix < 2826 :
                tab[1412].append(prix)
            elif prix < 2828 :
                tab[1413].append(prix)
            elif prix < 2830 :
                tab[1414].append(prix)
            elif prix < 2832 :
                tab[1415].append(prix)
            elif prix < 2834 :
                tab[1416].append(prix)
            elif prix < 2836 :
                tab[1417].append(prix)
            elif prix < 2838 :
                tab[1418].append(prix)
            elif prix < 2840 :
                tab[1419].append(prix)
            elif prix < 2842 :
                tab[1420].append(prix)
            elif prix < 2844 :
                tab[1421].append(prix)
            elif prix < 2846 :
                tab[1422].append(prix)
            elif prix < 2848 :
                tab[1423].append(prix)
            elif prix < 2850 :
                tab[1424].append(prix)
            elif prix < 2852 :
                tab[1425].append(prix)
            elif prix < 2854 :
                tab[1426].append(prix)
            elif prix < 2856 :
                tab[1427].append(prix)
            elif prix < 2858 :
                tab[1428].append(prix)
            elif prix < 2860 :
                tab[1429].append(prix)
            elif prix < 2862 :
                tab[1430].append(prix)
            elif prix < 2864 :
                tab[1431].append(prix)
            elif prix < 2866 :
                tab[1432].append(prix)
            elif prix < 2868 :
                tab[1433].append(prix)
            elif prix < 2870 :
                tab[1434].append(prix)
            elif prix < 2872 :
                tab[1435].append(prix)
            elif prix < 2874 :
                tab[1436].append(prix)
            elif prix < 2876 :
                tab[1437].append(prix)
            elif prix < 2878 :
                tab[1438].append(prix)
            elif prix < 2880 :
                tab[1439].append(prix)
            elif prix < 2882 :
                tab[1440].append(prix)
            elif prix < 2884 :
                tab[1441].append(prix)
            elif prix < 2886 :
                tab[1442].append(prix)
            elif prix < 2888 :
                tab[1443].append(prix)
            elif prix < 2890 :
                tab[1444].append(prix)
            elif prix < 2892 :
                tab[1445].append(prix)
            elif prix < 2894 :
                tab[1446].append(prix)
            elif prix < 2896 :
                tab[1447].append(prix)
            elif prix < 2898 :
                tab[1448].append(prix)
            elif prix < 2900 :
                tab[1449].append(prix)
            elif prix < 2902 :
                tab[1450].append(prix)
            elif prix < 2904 :
                tab[1451].append(prix)
            elif prix < 2906 :
                tab[1452].append(prix)
            elif prix < 2908 :
                tab[1453].append(prix)
            elif prix < 2910 :
                tab[1454].append(prix)
            elif prix < 2912 :
                tab[1455].append(prix)
            elif prix < 2914 :
                tab[1456].append(prix)
            elif prix < 2916 :
                tab[1457].append(prix)
            elif prix < 2918 :
                tab[1458].append(prix)
            elif prix < 2920 :
                tab[1459].append(prix)
            elif prix < 2922 :
                tab[1460].append(prix)
            elif prix < 2924 :
                tab[1461].append(prix)
            elif prix < 2926 :
                tab[1462].append(prix)
            elif prix < 2928 :
                tab[1463].append(prix)
            elif prix < 2930 :
                tab[1464].append(prix)
            elif prix < 2932 :
                tab[1465].append(prix)
            elif prix < 2934 :
                tab[1466].append(prix)
            elif prix < 2936 :
                tab[1467].append(prix)
            elif prix < 2938 :
                tab[1468].append(prix)
            elif prix < 2940 :
                tab[1469].append(prix)
            elif prix < 2942 :
                tab[1470].append(prix)
            elif prix < 2944 :
                tab[1471].append(prix)
            elif prix < 2946 :
                tab[1472].append(prix)
            elif prix < 2948 :
                tab[1473].append(prix)
            elif prix < 2950 :
                tab[1474].append(prix)
            elif prix < 2952 :
                tab[1475].append(prix)
            elif prix < 2954 :
                tab[1476].append(prix)
            elif prix < 2956 :
                tab[1477].append(prix)
            elif prix < 2958 :
                tab[1478].append(prix)
            elif prix < 2960 :
                tab[1479].append(prix)
            elif prix < 2962 :
                tab[1480].append(prix)
            elif prix < 2964 :
                tab[1481].append(prix)
            elif prix < 2966 :
                tab[1482].append(prix)
            elif prix < 2968 :
                tab[1483].append(prix)
            elif prix < 2970 :
                tab[1484].append(prix)
            elif prix < 2972 :
                tab[1485].append(prix)
            elif prix < 2974 :
                tab[1486].append(prix)
            elif prix < 2976 :
                tab[1487].append(prix)
            elif prix < 2978 :
                tab[1488].append(prix)
            elif prix < 2980 :
                tab[1489].append(prix)
            elif prix < 2982 :
                tab[1490].append(prix)
            elif prix < 2984 :
                tab[1491].append(prix)
            elif prix < 2986 :
                tab[1492].append(prix)
            elif prix < 2988 :
                tab[1493].append(prix)
            elif prix < 2990 :
                tab[1494].append(prix)
            elif prix < 2992 :
                tab[1495].append(prix)
            elif prix < 2994 :
                tab[1496].append(prix)
            elif prix < 2996 :
                tab[1497].append(prix)
            elif prix < 2998 :
                tab[1498].append(prix)
            elif prix < 3000 :
                tab[1499].append(prix)
            elif prix < 3002 :
                tab[1500].append(prix)
            elif prix < 3004 :
                tab[1501].append(prix)
            elif prix < 3006 :
                tab[1502].append(prix)
            elif prix < 3008 :
                tab[1503].append(prix)
            elif prix < 3010 :
                tab[1504].append(prix)
            elif prix < 3012 :
                tab[1505].append(prix)
            elif prix < 3014 :
                tab[1506].append(prix)
            elif prix < 3016 :
                tab[1507].append(prix)
            elif prix < 3018 :
                tab[1508].append(prix)
            elif prix < 3020 :
                tab[1509].append(prix)
            elif prix < 3022 :
                tab[1510].append(prix)
            elif prix < 3024 :
                tab[1511].append(prix)
            elif prix < 3026 :
                tab[1512].append(prix)
            elif prix < 3028 :
                tab[1513].append(prix)
            elif prix < 3030 :
                tab[1514].append(prix)
            elif prix < 3032 :
                tab[1515].append(prix)
            elif prix < 3034 :
                tab[1516].append(prix)
            elif prix < 3036 :
                tab[1517].append(prix)
            elif prix < 3038 :
                tab[1518].append(prix)
            elif prix < 3040 :
                tab[1519].append(prix)
            elif prix < 3042 :
                tab[1520].append(prix)
            elif prix < 3044 :
                tab[1521].append(prix)
            elif prix < 3046 :
                tab[1522].append(prix)
            elif prix < 3048 :
                tab[1523].append(prix)
            elif prix < 3050 :
                tab[1524].append(prix)
            elif prix < 3052 :
                tab[1525].append(prix)
            elif prix < 3054 :
                tab[1526].append(prix)
            elif prix < 3056 :
                tab[1527].append(prix)
            elif prix < 3058 :
                tab[1528].append(prix)
            elif prix < 3060 :
                tab[1529].append(prix)
            elif prix < 3062 :
                tab[1530].append(prix)
            elif prix < 3064 :
                tab[1531].append(prix)
            elif prix < 3066 :
                tab[1532].append(prix)
            elif prix < 3068 :
                tab[1533].append(prix)
            elif prix < 3070 :
                tab[1534].append(prix)
            elif prix < 3072 :
                tab[1535].append(prix)
            elif prix < 3074 :
                tab[1536].append(prix)
            elif prix < 3076 :
                tab[1537].append(prix)
            elif prix < 3078 :
                tab[1538].append(prix)
            elif prix < 3080 :
                tab[1539].append(prix)
            elif prix < 3082 :
                tab[1540].append(prix)
            elif prix < 3084 :
                tab[1541].append(prix)
            elif prix < 3086 :
                tab[1542].append(prix)
            elif prix < 3088 :
                tab[1543].append(prix)
            elif prix < 3090 :
                tab[1544].append(prix)
            elif prix < 3092 :
                tab[1545].append(prix)
            elif prix < 3094 :
                tab[1546].append(prix)
            elif prix < 3096 :
                tab[1547].append(prix)
            elif prix < 3098 :
                tab[1548].append(prix)
            elif prix < 3100 :
                tab[1549].append(prix)
            elif prix < 3102 :
                tab[1550].append(prix)
            elif prix < 3104 :
                tab[1551].append(prix)
            elif prix < 3106 :
                tab[1552].append(prix)
            elif prix < 3108 :
                tab[1553].append(prix)
            elif prix < 3110 :
                tab[1554].append(prix)
            elif prix < 3112 :
                tab[1555].append(prix)
            elif prix < 3114 :
                tab[1556].append(prix)
            elif prix < 3116 :
                tab[1557].append(prix)
            elif prix < 3118 :
                tab[1558].append(prix)
            elif prix < 3120 :
                tab[1559].append(prix)
            elif prix < 3122 :
                tab[1560].append(prix)
            elif prix < 3124 :
                tab[1561].append(prix)
            elif prix < 3126 :
                tab[1562].append(prix)
            elif prix < 3128 :
                tab[1563].append(prix)
            elif prix < 3130 :
                tab[1564].append(prix)
            elif prix < 3132 :
                tab[1565].append(prix)
            elif prix < 3134 :
                tab[1566].append(prix)
            elif prix < 3136 :
                tab[1567].append(prix)
            elif prix < 3138 :
                tab[1568].append(prix)
            elif prix < 3140 :
                tab[1569].append(prix)
            elif prix < 3142 :
                tab[1570].append(prix)
            elif prix < 3144 :
                tab[1571].append(prix)
            elif prix < 3146 :
                tab[1572].append(prix)
            elif prix < 3148 :
                tab[1573].append(prix)
            elif prix < 3150 :
                tab[1574].append(prix)
            elif prix < 3152 :
                tab[1575].append(prix)
            elif prix < 3154 :
                tab[1576].append(prix)
            elif prix < 3156 :
                tab[1577].append(prix)
            elif prix < 3158 :
                tab[1578].append(prix)
            elif prix < 3160 :
                tab[1579].append(prix)
            elif prix < 3162 :
                tab[1580].append(prix)
            elif prix < 3164 :
                tab[1581].append(prix)
            elif prix < 3166 :
                tab[1582].append(prix)
            elif prix < 3168 :
                tab[1583].append(prix)
            elif prix < 3170 :
                tab[1584].append(prix)
            elif prix < 3172 :
                tab[1585].append(prix)
            elif prix < 3174 :
                tab[1586].append(prix)
            elif prix < 3176 :
                tab[1587].append(prix)
            elif prix < 3178 :
                tab[1588].append(prix)
            elif prix < 3180 :
                tab[1589].append(prix)
            elif prix < 3182 :
                tab[1590].append(prix)
            elif prix < 3184 :
                tab[1591].append(prix)
            elif prix < 3186 :
                tab[1592].append(prix)
            elif prix < 3188 :
                tab[1593].append(prix)
            elif prix < 3190 :
                tab[1594].append(prix)
            elif prix < 3192 :
                tab[1595].append(prix)
            elif prix < 3194 :
                tab[1596].append(prix)
            elif prix < 3196 :
                tab[1597].append(prix)
            elif prix < 3198 :
                tab[1598].append(prix)
            elif prix < 3200 :
                tab[1599].append(prix)
            elif prix < 3202 :
                tab[1600].append(prix)
            elif prix < 3204 :
                tab[1601].append(prix)
            elif prix < 3206 :
                tab[1602].append(prix)
            elif prix < 3208 :
                tab[1603].append(prix)
            elif prix < 3210 :
                tab[1604].append(prix)
            elif prix < 3212 :
                tab[1605].append(prix)
            elif prix < 3214 :
                tab[1606].append(prix)
            elif prix < 3216 :
                tab[1607].append(prix)
            elif prix < 3218 :
                tab[1608].append(prix)
            elif prix < 3220 :
                tab[1609].append(prix)
            elif prix < 3222 :
                tab[1610].append(prix)
            elif prix < 3224 :
                tab[1611].append(prix)
            elif prix < 3226 :
                tab[1612].append(prix)
            elif prix < 3228 :
                tab[1613].append(prix)
            elif prix < 3230 :
                tab[1614].append(prix)
            elif prix < 3232 :
                tab[1615].append(prix)
            elif prix < 3234 :
                tab[1616].append(prix)
            elif prix < 3236 :
                tab[1617].append(prix)
            elif prix < 3238 :
                tab[1618].append(prix)
            elif prix < 3240 :
                tab[1619].append(prix)
            elif prix < 3242 :
                tab[1620].append(prix)
            elif prix < 3244 :
                tab[1621].append(prix)
            elif prix < 3246 :
                tab[1622].append(prix)
            elif prix < 3248 :
                tab[1623].append(prix)
            elif prix < 3250 :
                tab[1624].append(prix)
            elif prix < 3252 :
                tab[1625].append(prix)
            elif prix < 3254 :
                tab[1626].append(prix)
            elif prix < 3256 :
                tab[1627].append(prix)
            elif prix < 3258 :
                tab[1628].append(prix)
            elif prix < 3260 :
                tab[1629].append(prix)
            elif prix < 3262 :
                tab[1630].append(prix)
            elif prix < 3264 :
                tab[1631].append(prix)
            elif prix < 3266 :
                tab[1632].append(prix)
            elif prix < 3268 :
                tab[1633].append(prix)
            elif prix < 3270 :
                tab[1634].append(prix)
            elif prix < 3272 :
                tab[1635].append(prix)
            elif prix < 3274 :
                tab[1636].append(prix)
            elif prix < 3276 :
                tab[1637].append(prix)
            elif prix < 3278 :
                tab[1638].append(prix)
            elif prix < 3280 :
                tab[1639].append(prix)
            elif prix < 3282 :
                tab[1640].append(prix)
            elif prix < 3284 :
                tab[1641].append(prix)
            elif prix < 3286 :
                tab[1642].append(prix)
            elif prix < 3288 :
                tab[1643].append(prix)
            elif prix < 3290 :
                tab[1644].append(prix)
            elif prix < 3292 :
                tab[1645].append(prix)
            elif prix < 3294 :
                tab[1646].append(prix)
            elif prix < 3296 :
                tab[1647].append(prix)
            elif prix < 3298 :
                tab[1648].append(prix)
            elif prix < 3300 :
                tab[1649].append(prix)
            elif prix < 3302 :
                tab[1650].append(prix)
            elif prix < 3304 :
                tab[1651].append(prix)
            elif prix < 3306 :
                tab[1652].append(prix)
            elif prix < 3308 :
                tab[1653].append(prix)
            elif prix < 3310 :
                tab[1654].append(prix)
            elif prix < 3312 :
                tab[1655].append(prix)
            elif prix < 3314 :
                tab[1656].append(prix)
            elif prix < 3316 :
                tab[1657].append(prix)
            elif prix < 3318 :
                tab[1658].append(prix)
            elif prix < 3320 :
                tab[1659].append(prix)
            elif prix < 3322 :
                tab[1660].append(prix)
            elif prix < 3324 :
                tab[1661].append(prix)
            elif prix < 3326 :
                tab[1662].append(prix)
            elif prix < 3328 :
                tab[1663].append(prix)
            elif prix < 3330 :
                tab[1664].append(prix)
            elif prix < 3332 :
                tab[1665].append(prix)
            elif prix < 3334 :
                tab[1666].append(prix)
            elif prix < 3336 :
                tab[1667].append(prix)
            elif prix < 3338 :
                tab[1668].append(prix)
            elif prix < 3340 :
                tab[1669].append(prix)
            elif prix < 3342 :
                tab[1670].append(prix)
            elif prix < 3344 :
                tab[1671].append(prix)
            elif prix < 3346 :
                tab[1672].append(prix)
            elif prix < 3348 :
                tab[1673].append(prix)
            elif prix < 3350 :
                tab[1674].append(prix)
            elif prix < 3352 :
                tab[1675].append(prix)
            elif prix < 3354 :
                tab[1676].append(prix)
            elif prix < 3356 :
                tab[1677].append(prix)
            elif prix < 3358 :
                tab[1678].append(prix)
            elif prix < 3360 :
                tab[1679].append(prix)
            elif prix < 3362 :
                tab[1680].append(prix)
            elif prix < 3364 :
                tab[1681].append(prix)
            elif prix < 3366 :
                tab[1682].append(prix)
            elif prix < 3368 :
                tab[1683].append(prix)
            elif prix < 3370 :
                tab[1684].append(prix)
            elif prix < 3372 :
                tab[1685].append(prix)
            elif prix < 3374 :
                tab[1686].append(prix)
            elif prix < 3376 :
                tab[1687].append(prix)
            elif prix < 3378 :
                tab[1688].append(prix)
            elif prix < 3380 :
                tab[1689].append(prix)
            elif prix < 3382 :
                tab[1690].append(prix)
            elif prix < 3384 :
                tab[1691].append(prix)
            elif prix < 3386 :
                tab[1692].append(prix)
            elif prix < 3388 :
                tab[1693].append(prix)
            elif prix < 3390 :
                tab[1694].append(prix)
            elif prix < 3392 :
                tab[1695].append(prix)
            elif prix < 3394 :
                tab[1696].append(prix)
            elif prix < 3396 :
                tab[1697].append(prix)
            elif prix < 3398 :
                tab[1698].append(prix)
            elif prix < 3400 :
                tab[1699].append(prix)
            elif prix < 3402 :
                tab[1700].append(prix)
            elif prix < 3404 :
                tab[1701].append(prix)
            elif prix < 3406 :
                tab[1702].append(prix)
            elif prix < 3408 :
                tab[1703].append(prix)
            elif prix < 3410 :
                tab[1704].append(prix)
            elif prix < 3412 :
                tab[1705].append(prix)
            elif prix < 3414 :
                tab[1706].append(prix)
            elif prix < 3416 :
                tab[1707].append(prix)
            elif prix < 3418 :
                tab[1708].append(prix)
            elif prix < 3420 :
                tab[1709].append(prix)
            elif prix < 3422 :
                tab[1710].append(prix)
            elif prix < 3424 :
                tab[1711].append(prix)
            elif prix < 3426 :
                tab[1712].append(prix)
            elif prix < 3428 :
                tab[1713].append(prix)
            elif prix < 3430 :
                tab[1714].append(prix)
            elif prix < 3432 :
                tab[1715].append(prix)
            elif prix < 3434 :
                tab[1716].append(prix)
            elif prix < 3436 :
                tab[1717].append(prix)
            elif prix < 3438 :
                tab[1718].append(prix)
            elif prix < 3440 :
                tab[1719].append(prix)
            elif prix < 3442 :
                tab[1720].append(prix)
            elif prix < 3444 :
                tab[1721].append(prix)
            elif prix < 3446 :
                tab[1722].append(prix)
            elif prix < 3448 :
                tab[1723].append(prix)
            elif prix < 3450 :
                tab[1724].append(prix)
            elif prix < 3452 :
                tab[1725].append(prix)
            elif prix < 3454 :
                tab[1726].append(prix)
            elif prix < 3456 :
                tab[1727].append(prix)
            elif prix < 3458 :
                tab[1728].append(prix)
            elif prix < 3460 :
                tab[1729].append(prix)
            elif prix < 3462 :
                tab[1730].append(prix)
            elif prix < 3464 :
                tab[1731].append(prix)
            elif prix < 3466 :
                tab[1732].append(prix)
            elif prix < 3468 :
                tab[1733].append(prix)
            elif prix < 3470 :
                tab[1734].append(prix)
            elif prix < 3472 :
                tab[1735].append(prix)
            elif prix < 3474 :
                tab[1736].append(prix)
            elif prix < 3476 :
                tab[1737].append(prix)
            elif prix < 3478 :
                tab[1738].append(prix)
            elif prix < 3480 :
                tab[1739].append(prix)
            elif prix < 3482 :
                tab[1740].append(prix)
            elif prix < 3484 :
                tab[1741].append(prix)
            elif prix < 3486 :
                tab[1742].append(prix)
            elif prix < 3488 :
                tab[1743].append(prix)
            elif prix < 3490 :
                tab[1744].append(prix)
            elif prix < 3492 :
                tab[1745].append(prix)
            elif prix < 3494 :
                tab[1746].append(prix)
            elif prix < 3496 :
                tab[1747].append(prix)
            elif prix < 3498 :
                tab[1748].append(prix)
            elif prix < 3500 :
                tab[1749].append(prix)
            elif prix < 3502 :
                tab[1750].append(prix)
            elif prix < 3504 :
                tab[1751].append(prix)
            elif prix < 3506 :
                tab[1752].append(prix)
            elif prix < 3508 :
                tab[1753].append(prix)
            elif prix < 3510 :
                tab[1754].append(prix)
            elif prix < 3512 :
                tab[1755].append(prix)
            elif prix < 3514 :
                tab[1756].append(prix)
            elif prix < 3516 :
                tab[1757].append(prix)
            elif prix < 3518 :
                tab[1758].append(prix)
            elif prix < 3520 :
                tab[1759].append(prix)
            elif prix < 3522 :
                tab[1760].append(prix)
            elif prix < 3524 :
                tab[1761].append(prix)
            elif prix < 3526 :
                tab[1762].append(prix)
            elif prix < 3528 :
                tab[1763].append(prix)
            elif prix < 3530 :
                tab[1764].append(prix)
            elif prix < 3532 :
                tab[1765].append(prix)
            elif prix < 3534 :
                tab[1766].append(prix)
            elif prix < 3536 :
                tab[1767].append(prix)
            elif prix < 3538 :
                tab[1768].append(prix)
            elif prix < 3540 :
                tab[1769].append(prix)
            elif prix < 3542 :
                tab[1770].append(prix)
            elif prix < 3544 :
                tab[1771].append(prix)
            elif prix < 3546 :
                tab[1772].append(prix)
            elif prix < 3548 :
                tab[1773].append(prix)
            elif prix < 3550 :
                tab[1774].append(prix)
            elif prix < 3552 :
                tab[1775].append(prix)
            elif prix < 3554 :
                tab[1776].append(prix)
            elif prix < 3556 :
                tab[1777].append(prix)
            elif prix < 3558 :
                tab[1778].append(prix)
            elif prix < 3560 :
                tab[1779].append(prix)
            elif prix < 3562 :
                tab[1780].append(prix)
            elif prix < 3564 :
                tab[1781].append(prix)
            elif prix < 3566 :
                tab[1782].append(prix)
            elif prix < 3568 :
                tab[1783].append(prix)
            elif prix < 3570 :
                tab[1784].append(prix)
            elif prix < 3572 :
                tab[1785].append(prix)
            elif prix < 3574 :
                tab[1786].append(prix)
            elif prix < 3576 :
                tab[1787].append(prix)
            elif prix < 3578 :
                tab[1788].append(prix)
            elif prix < 3580 :
                tab[1789].append(prix)
            elif prix < 3582 :
                tab[1790].append(prix)
            elif prix < 3584 :
                tab[1791].append(prix)
            elif prix < 3586 :
                tab[1792].append(prix)
            elif prix < 3588 :
                tab[1793].append(prix)
            elif prix < 3590 :
                tab[1794].append(prix)
            elif prix < 3592 :
                tab[1795].append(prix)
            elif prix < 3594 :
                tab[1796].append(prix)
            elif prix < 3596 :
                tab[1797].append(prix)
            elif prix < 3598 :
                tab[1798].append(prix)
            elif prix < 3600 :
                tab[1799].append(prix)
            elif prix < 3602 :
                tab[1800].append(prix)
            elif prix < 3604 :
                tab[1801].append(prix)
            elif prix < 3606 :
                tab[1802].append(prix)
            elif prix < 3608 :
                tab[1803].append(prix)
            elif prix < 3610 :
                tab[1804].append(prix)
            elif prix < 3612 :
                tab[1805].append(prix)
            elif prix < 3614 :
                tab[1806].append(prix)
            elif prix < 3616 :
                tab[1807].append(prix)
            elif prix < 3618 :
                tab[1808].append(prix)
            elif prix < 3620 :
                tab[1809].append(prix)
            elif prix < 3622 :
                tab[1810].append(prix)
            elif prix < 3624 :
                tab[1811].append(prix)
            elif prix < 3626 :
                tab[1812].append(prix)
            elif prix < 3628 :
                tab[1813].append(prix)
            elif prix < 3630 :
                tab[1814].append(prix)
            elif prix < 3632 :
                tab[1815].append(prix)
            elif prix < 3634 :
                tab[1816].append(prix)
            elif prix < 3636 :
                tab[1817].append(prix)
            elif prix < 3638 :
                tab[1818].append(prix)
            elif prix < 3640 :
                tab[1819].append(prix)
            elif prix < 3642 :
                tab[1820].append(prix)
            elif prix < 3644 :
                tab[1821].append(prix)
            elif prix < 3646 :
                tab[1822].append(prix)
            elif prix < 3648 :
                tab[1823].append(prix)
            elif prix < 3650 :
                tab[1824].append(prix)
            elif prix < 3652 :
                tab[1825].append(prix)
            elif prix < 3654 :
                tab[1826].append(prix)
            elif prix < 3656 :
                tab[1827].append(prix)
            elif prix < 3658 :
                tab[1828].append(prix)
            elif prix < 3660 :
                tab[1829].append(prix)
            elif prix < 3662 :
                tab[1830].append(prix)
            elif prix < 3664 :
                tab[1831].append(prix)
            elif prix < 3666 :
                tab[1832].append(prix)
            elif prix < 3668 :
                tab[1833].append(prix)
            elif prix < 3670 :
                tab[1834].append(prix)
            elif prix < 3672 :
                tab[1835].append(prix)
            elif prix < 3674 :
                tab[1836].append(prix)
            elif prix < 3676 :
                tab[1837].append(prix)
            elif prix < 3678 :
                tab[1838].append(prix)
            elif prix < 3680 :
                tab[1839].append(prix)
            elif prix < 3682 :
                tab[1840].append(prix)
            elif prix < 3684 :
                tab[1841].append(prix)
            elif prix < 3686 :
                tab[1842].append(prix)
            elif prix < 3688 :
                tab[1843].append(prix)
            elif prix < 3690 :
                tab[1844].append(prix)
            elif prix < 3692 :
                tab[1845].append(prix)
            elif prix < 3694 :
                tab[1846].append(prix)
            elif prix < 3696 :
                tab[1847].append(prix)
            elif prix < 3698 :
                tab[1848].append(prix)
            elif prix < 3700 :
                tab[1849].append(prix)
            elif prix < 3702 :
                tab[1850].append(prix)
            elif prix < 3704 :
                tab[1851].append(prix)
            elif prix < 3706 :
                tab[1852].append(prix)
            elif prix < 3708 :
                tab[1853].append(prix)
            elif prix < 3710 :
                tab[1854].append(prix)
            elif prix < 3712 :
                tab[1855].append(prix)
            elif prix < 3714 :
                tab[1856].append(prix)
            elif prix < 3716 :
                tab[1857].append(prix)
            elif prix < 3718 :
                tab[1858].append(prix)
            elif prix < 3720 :
                tab[1859].append(prix)
            elif prix < 3722 :
                tab[1860].append(prix)
            elif prix < 3724 :
                tab[1861].append(prix)
            elif prix < 3726 :
                tab[1862].append(prix)
            elif prix < 3728 :
                tab[1863].append(prix)
            elif prix < 3730 :
                tab[1864].append(prix)
            elif prix < 3732 :
                tab[1865].append(prix)
            elif prix < 3734 :
                tab[1866].append(prix)
            elif prix < 3736 :
                tab[1867].append(prix)
            elif prix < 3738 :
                tab[1868].append(prix)
            elif prix < 3740 :
                tab[1869].append(prix)
            elif prix < 3742 :
                tab[1870].append(prix)
            elif prix < 3744 :
                tab[1871].append(prix)
            elif prix < 3746 :
                tab[1872].append(prix)
            elif prix < 3748 :
                tab[1873].append(prix)
            elif prix < 3750 :
                tab[1874].append(prix)
            elif prix < 3752 :
                tab[1875].append(prix)
            elif prix < 3754 :
                tab[1876].append(prix)
            elif prix < 3756 :
                tab[1877].append(prix)
            elif prix < 3758 :
                tab[1878].append(prix)
            elif prix < 3760 :
                tab[1879].append(prix)
            elif prix < 3762 :
                tab[1880].append(prix)
            elif prix < 3764 :
                tab[1881].append(prix)
            elif prix < 3766 :
                tab[1882].append(prix)
            elif prix < 3768 :
                tab[1883].append(prix)
            elif prix < 3770 :
                tab[1884].append(prix)
            elif prix < 3772 :
                tab[1885].append(prix)
            elif prix < 3774 :
                tab[1886].append(prix)
            elif prix < 3776 :
                tab[1887].append(prix)
            elif prix < 3778 :
                tab[1888].append(prix)
            elif prix < 3780 :
                tab[1889].append(prix)
            elif prix < 3782 :
                tab[1890].append(prix)
            elif prix < 3784 :
                tab[1891].append(prix)
            elif prix < 3786 :
                tab[1892].append(prix)
            elif prix < 3788 :
                tab[1893].append(prix)
            elif prix < 3790 :
                tab[1894].append(prix)
            elif prix < 3792 :
                tab[1895].append(prix)
            elif prix < 3794 :
                tab[1896].append(prix)
            elif prix < 3796 :
                tab[1897].append(prix)
            elif prix < 3798 :
                tab[1898].append(prix)
            elif prix < 3800 :
                tab[1899].append(prix)
            elif prix < 3802 :
                tab[1900].append(prix)
            elif prix < 3804 :
                tab[1901].append(prix)
            elif prix < 3806 :
                tab[1902].append(prix)
            elif prix < 3808 :
                tab[1903].append(prix)
            elif prix < 3810 :
                tab[1904].append(prix)
            elif prix < 3812 :
                tab[1905].append(prix)
            elif prix < 3814 :
                tab[1906].append(prix)
            elif prix < 3816 :
                tab[1907].append(prix)
            elif prix < 3818 :
                tab[1908].append(prix)
            elif prix < 3820 :
                tab[1909].append(prix)
            elif prix < 3822 :
                tab[1910].append(prix)
            elif prix < 3824 :
                tab[1911].append(prix)
            elif prix < 3826 :
                tab[1912].append(prix)
            elif prix < 3828 :
                tab[1913].append(prix)
            elif prix < 3830 :
                tab[1914].append(prix)
            elif prix < 3832 :
                tab[1915].append(prix)
            elif prix < 3834 :
                tab[1916].append(prix)
            elif prix < 3836 :
                tab[1917].append(prix)
            elif prix < 3838 :
                tab[1918].append(prix)
            elif prix < 3840 :
                tab[1919].append(prix)
            elif prix < 3842 :
                tab[1920].append(prix)
            elif prix < 3844 :
                tab[1921].append(prix)
            elif prix < 3846 :
                tab[1922].append(prix)
            elif prix < 3848 :
                tab[1923].append(prix)
            elif prix < 3850 :
                tab[1924].append(prix)
            elif prix < 3852 :
                tab[1925].append(prix)
            elif prix < 3854 :
                tab[1926].append(prix)
            elif prix < 3856 :
                tab[1927].append(prix)
            elif prix < 3858 :
                tab[1928].append(prix)
            elif prix < 3860 :
                tab[1929].append(prix)
            elif prix < 3862 :
                tab[1930].append(prix)
            elif prix < 3864 :
                tab[1931].append(prix)
            elif prix < 3866 :
                tab[1932].append(prix)
            elif prix < 3868 :
                tab[1933].append(prix)
            elif prix < 3870 :
                tab[1934].append(prix)
            elif prix < 3872 :
                tab[1935].append(prix)
            elif prix < 3874 :
                tab[1936].append(prix)
            elif prix < 3876 :
                tab[1937].append(prix)
            elif prix < 3878 :
                tab[1938].append(prix)
            elif prix < 3880 :
                tab[1939].append(prix)
            elif prix < 3882 :
                tab[1940].append(prix)
            elif prix < 3884 :
                tab[1941].append(prix)
            elif prix < 3886 :
                tab[1942].append(prix)
            elif prix < 3888 :
                tab[1943].append(prix)
            elif prix < 3890 :
                tab[1944].append(prix)
            elif prix < 3892 :
                tab[1945].append(prix)
            elif prix < 3894 :
                tab[1946].append(prix)
            elif prix < 3896 :
                tab[1947].append(prix)
            elif prix < 3898 :
                tab[1948].append(prix)
            elif prix < 3900 :
                tab[1949].append(prix)
            elif prix < 3902 :
                tab[1950].append(prix)
            elif prix < 3904 :
                tab[1951].append(prix)
            elif prix < 3906 :
                tab[1952].append(prix)
            elif prix < 3908 :
                tab[1953].append(prix)
            elif prix < 3910 :
                tab[1954].append(prix)
            elif prix < 3912 :
                tab[1955].append(prix)
            elif prix < 3914 :
                tab[1956].append(prix)
            elif prix < 3916 :
                tab[1957].append(prix)
            elif prix < 3918 :
                tab[1958].append(prix)
            elif prix < 3920 :
                tab[1959].append(prix)
            elif prix < 3922 :
                tab[1960].append(prix)
            elif prix < 3924 :
                tab[1961].append(prix)
            elif prix < 3926 :
                tab[1962].append(prix)
            elif prix < 3928 :
                tab[1963].append(prix)
            elif prix < 3930 :
                tab[1964].append(prix)
            elif prix < 3932 :
                tab[1965].append(prix)
            elif prix < 3934 :
                tab[1966].append(prix)
            elif prix < 3936 :
                tab[1967].append(prix)
            elif prix < 3938 :
                tab[1968].append(prix)
            elif prix < 3940 :
                tab[1969].append(prix)
            elif prix < 3942 :
                tab[1970].append(prix)
            elif prix < 3944 :
                tab[1971].append(prix)
            elif prix < 3946 :
                tab[1972].append(prix)
            elif prix < 3948 :
                tab[1973].append(prix)
            elif prix < 3950 :
                tab[1974].append(prix)
            elif prix < 3952 :
                tab[1975].append(prix)
            elif prix < 3954 :
                tab[1976].append(prix)
            elif prix < 3956 :
                tab[1977].append(prix)
            elif prix < 3958 :
                tab[1978].append(prix)
            elif prix < 3960 :
                tab[1979].append(prix)
            elif prix < 3962 :
                tab[1980].append(prix)
            elif prix < 3964 :
                tab[1981].append(prix)
            elif prix < 3966 :
                tab[1982].append(prix)
            elif prix < 3968 :
                tab[1983].append(prix)
            elif prix < 3970 :
                tab[1984].append(prix)
            elif prix < 3972 :
                tab[1985].append(prix)
            elif prix < 3974 :
                tab[1986].append(prix)
            elif prix < 3976 :
                tab[1987].append(prix)
            elif prix < 3978 :
                tab[1988].append(prix)
            elif prix < 3980 :
                tab[1989].append(prix)
            elif prix < 3982 :
                tab[1990].append(prix)
            elif prix < 3984 :
                tab[1991].append(prix)
            elif prix < 3986 :
                tab[1992].append(prix)
            elif prix < 3988 :
                tab[1993].append(prix)
            elif prix < 3990 :
                tab[1994].append(prix)
            elif prix < 3992 :
                tab[1995].append(prix)
            elif prix < 3994 :
                tab[1996].append(prix)
            elif prix < 3996 :
                tab[1997].append(prix)
            elif prix < 3998 :
                tab[1998].append(prix)
            elif prix < 4000 :
                tab[1999].append(prix)
            elif prix < 4002 :
                tab[2000].append(prix)
            elif prix < 4004 :
                tab[2001].append(prix)
            elif prix < 4006 :
                tab[2002].append(prix)
            elif prix < 4008 :
                tab[2003].append(prix)
            elif prix < 4010 :
                tab[2004].append(prix)
            elif prix < 4012 :
                tab[2005].append(prix)
            elif prix < 4014 :
                tab[2006].append(prix)
            elif prix < 4016 :
                tab[2007].append(prix)
            elif prix < 4018 :
                tab[2008].append(prix)
            elif prix < 4020 :
                tab[2009].append(prix)
            elif prix < 4022 :
                tab[2010].append(prix)
            elif prix < 4024 :
                tab[2011].append(prix)
            elif prix < 4026 :
                tab[2012].append(prix)
            elif prix < 4028 :
                tab[2013].append(prix)
            elif prix < 4030 :
                tab[2014].append(prix)
            elif prix < 4032 :
                tab[2015].append(prix)
            elif prix < 4034 :
                tab[2016].append(prix)
            elif prix < 4036 :
                tab[2017].append(prix)
            elif prix < 4038 :
                tab[2018].append(prix)
            elif prix < 4040 :
                tab[2019].append(prix)
            elif prix < 4042 :
                tab[2020].append(prix)
            elif prix < 4044 :
                tab[2021].append(prix)
            elif prix < 4046 :
                tab[2022].append(prix)
            elif prix < 4048 :
                tab[2023].append(prix)
            elif prix < 4050 :
                tab[2024].append(prix)
            elif prix < 4052 :
                tab[2025].append(prix)
            elif prix < 4054 :
                tab[2026].append(prix)
            elif prix < 4056 :
                tab[2027].append(prix)
            elif prix < 4058 :
                tab[2028].append(prix)
            elif prix < 4060 :
                tab[2029].append(prix)
            elif prix < 4062 :
                tab[2030].append(prix)
            elif prix < 4064 :
                tab[2031].append(prix)
            elif prix < 4066 :
                tab[2032].append(prix)
            elif prix < 4068 :
                tab[2033].append(prix)
            elif prix < 4070 :
                tab[2034].append(prix)
            elif prix < 4072 :
                tab[2035].append(prix)
            elif prix < 4074 :
                tab[2036].append(prix)
            elif prix < 4076 :
                tab[2037].append(prix)
            elif prix < 4078 :
                tab[2038].append(prix)
            elif prix < 4080 :
                tab[2039].append(prix)
            elif prix < 4082 :
                tab[2040].append(prix)
            elif prix < 4084 :
                tab[2041].append(prix)
            elif prix < 4086 :
                tab[2042].append(prix)
            elif prix < 4088 :
                tab[2043].append(prix)
            elif prix < 4090 :
                tab[2044].append(prix)
            elif prix < 4092 :
                tab[2045].append(prix)
            elif prix < 4094 :
                tab[2046].append(prix)
            elif prix < 4096 :
                tab[2047].append(prix)
            elif prix < 4098 :
                tab[2048].append(prix)
            elif prix < 4100 :
                tab[2049].append(prix)
            elif prix < 4102 :
                tab[2050].append(prix)
            elif prix < 4104 :
                tab[2051].append(prix)
            elif prix < 4106 :
                tab[2052].append(prix)
            elif prix < 4108 :
                tab[2053].append(prix)
            elif prix < 4110 :
                tab[2054].append(prix)
            elif prix < 4112 :
                tab[2055].append(prix)
            elif prix < 4114 :
                tab[2056].append(prix)
            elif prix < 4116 :
                tab[2057].append(prix)
            elif prix < 4118 :
                tab[2058].append(prix)
            elif prix < 4120 :
                tab[2059].append(prix)
            elif prix < 4122 :
                tab[2060].append(prix)
            elif prix < 4124 :
                tab[2061].append(prix)
            elif prix < 4126 :
                tab[2062].append(prix)
            elif prix < 4128 :
                tab[2063].append(prix)
            elif prix < 4130 :
                tab[2064].append(prix)
            elif prix < 4132 :
                tab[2065].append(prix)
            elif prix < 4134 :
                tab[2066].append(prix)
            elif prix < 4136 :
                tab[2067].append(prix)
            elif prix < 4138 :
                tab[2068].append(prix)
            elif prix < 4140 :
                tab[2069].append(prix)
            elif prix < 4142 :
                tab[2070].append(prix)
            elif prix < 4144 :
                tab[2071].append(prix)
            elif prix < 4146 :
                tab[2072].append(prix)
            elif prix < 4148 :
                tab[2073].append(prix)
            elif prix < 4150 :
                tab[2074].append(prix)
            elif prix < 4152 :
                tab[2075].append(prix)
            elif prix < 4154 :
                tab[2076].append(prix)
            elif prix < 4156 :
                tab[2077].append(prix)
            elif prix < 4158 :
                tab[2078].append(prix)
            elif prix < 4160 :
                tab[2079].append(prix)
            elif prix < 4162 :
                tab[2080].append(prix)
            elif prix < 4164 :
                tab[2081].append(prix)
            elif prix < 4166 :
                tab[2082].append(prix)
            elif prix < 4168 :
                tab[2083].append(prix)
            elif prix < 4170 :
                tab[2084].append(prix)
            elif prix < 4172 :
                tab[2085].append(prix)
            elif prix < 4174 :
                tab[2086].append(prix)
            elif prix < 4176 :
                tab[2087].append(prix)
            elif prix < 4178 :
                tab[2088].append(prix)
            elif prix < 4180 :
                tab[2089].append(prix)
            elif prix < 4182 :
                tab[2090].append(prix)
            elif prix < 4184 :
                tab[2091].append(prix)
            elif prix < 4186 :
                tab[2092].append(prix)
            elif prix < 4188 :
                tab[2093].append(prix)
            elif prix < 4190 :
                tab[2094].append(prix)
            elif prix < 4192 :
                tab[2095].append(prix)
            elif prix < 4194 :
                tab[2096].append(prix)
            elif prix < 4196 :
                tab[2097].append(prix)
            elif prix < 4198 :
                tab[2098].append(prix)
            elif prix < 4200 :
                tab[2099].append(prix)
            elif prix < 4202 :
                tab[2100].append(prix)
            elif prix < 4204 :
                tab[2101].append(prix)
            elif prix < 4206 :
                tab[2102].append(prix)
            elif prix < 4208 :
                tab[2103].append(prix)
            elif prix < 4210 :
                tab[2104].append(prix)
            elif prix < 4212 :
                tab[2105].append(prix)
            elif prix < 4214 :
                tab[2106].append(prix)
            elif prix < 4216 :
                tab[2107].append(prix)
            elif prix < 4218 :
                tab[2108].append(prix)
            elif prix < 4220 :
                tab[2109].append(prix)
            elif prix < 4222 :
                tab[2110].append(prix)
            elif prix < 4224 :
                tab[2111].append(prix)
            elif prix < 4226 :
                tab[2112].append(prix)
            elif prix < 4228 :
                tab[2113].append(prix)
            elif prix < 4230 :
                tab[2114].append(prix)
            elif prix < 4232 :
                tab[2115].append(prix)
            elif prix < 4234 :
                tab[2116].append(prix)
            elif prix < 4236 :
                tab[2117].append(prix)
            elif prix < 4238 :
                tab[2118].append(prix)
            elif prix < 4240 :
                tab[2119].append(prix)
            elif prix < 4242 :
                tab[2120].append(prix)
            elif prix < 4244 :
                tab[2121].append(prix)
            elif prix < 4246 :
                tab[2122].append(prix)
            elif prix < 4248 :
                tab[2123].append(prix)
            elif prix < 4250 :
                tab[2124].append(prix)
            elif prix < 4252 :
                tab[2125].append(prix)
            elif prix < 4254 :
                tab[2126].append(prix)
            elif prix < 4256 :
                tab[2127].append(prix)
            elif prix < 4258 :
                tab[2128].append(prix)
            elif prix < 4260 :
                tab[2129].append(prix)
            elif prix < 4262 :
                tab[2130].append(prix)
            elif prix < 4264 :
                tab[2131].append(prix)
            elif prix < 4266 :
                tab[2132].append(prix)
            elif prix < 4268 :
                tab[2133].append(prix)
            elif prix < 4270 :
                tab[2134].append(prix)
            elif prix < 4272 :
                tab[2135].append(prix)
            elif prix < 4274 :
                tab[2136].append(prix)
            elif prix < 4276 :
                tab[2137].append(prix)
            elif prix < 4278 :
                tab[2138].append(prix)
            elif prix < 4280 :
                tab[2139].append(prix)
            elif prix < 4282 :
                tab[2140].append(prix)
            elif prix < 4284 :
                tab[2141].append(prix)
            elif prix < 4286 :
                tab[2142].append(prix)
            elif prix < 4288 :
                tab[2143].append(prix)
            elif prix < 4290 :
                tab[2144].append(prix)
            elif prix < 4292 :
                tab[2145].append(prix)
            elif prix < 4294 :
                tab[2146].append(prix)
            elif prix < 4296 :
                tab[2147].append(prix)
            elif prix < 4298 :
                tab[2148].append(prix)
            elif prix < 4300 :
                tab[2149].append(prix)
            elif prix < 4302 :
                tab[2150].append(prix)
            elif prix < 4304 :
                tab[2151].append(prix)
            elif prix < 4306 :
                tab[2152].append(prix)
            elif prix < 4308 :
                tab[2153].append(prix)
            elif prix < 4310 :
                tab[2154].append(prix)
            elif prix < 4312 :
                tab[2155].append(prix)
            elif prix < 4314 :
                tab[2156].append(prix)
            elif prix < 4316 :
                tab[2157].append(prix)
            elif prix < 4318 :
                tab[2158].append(prix)
            elif prix < 4320 :
                tab[2159].append(prix)
            elif prix < 4322 :
                tab[2160].append(prix)
            elif prix < 4324 :
                tab[2161].append(prix)
            elif prix < 4326 :
                tab[2162].append(prix)
            elif prix < 4328 :
                tab[2163].append(prix)
            elif prix < 4330 :
                tab[2164].append(prix)
            elif prix < 4332 :
                tab[2165].append(prix)
            elif prix < 4334 :
                tab[2166].append(prix)
            elif prix < 4336 :
                tab[2167].append(prix)
            elif prix < 4338 :
                tab[2168].append(prix)
            elif prix < 4340 :
                tab[2169].append(prix)
            elif prix < 4342 :
                tab[2170].append(prix)
            elif prix < 4344 :
                tab[2171].append(prix)
            elif prix < 4346 :
                tab[2172].append(prix)
            elif prix < 4348 :
                tab[2173].append(prix)
            elif prix < 4350 :
                tab[2174].append(prix)
            elif prix < 4352 :
                tab[2175].append(prix)
            elif prix < 4354 :
                tab[2176].append(prix)
            elif prix < 4356 :
                tab[2177].append(prix)
            elif prix < 4358 :
                tab[2178].append(prix)
            elif prix < 4360 :
                tab[2179].append(prix)
            elif prix < 4362 :
                tab[2180].append(prix)
            elif prix < 4364 :
                tab[2181].append(prix)
            elif prix < 4366 :
                tab[2182].append(prix)
            elif prix < 4368 :
                tab[2183].append(prix)
            elif prix < 4370 :
                tab[2184].append(prix)
            elif prix < 4372 :
                tab[2185].append(prix)
            elif prix < 4374 :
                tab[2186].append(prix)
            elif prix < 4376 :
                tab[2187].append(prix)
            elif prix < 4378 :
                tab[2188].append(prix)
            elif prix < 4380 :
                tab[2189].append(prix)
            elif prix < 4382 :
                tab[2190].append(prix)
            elif prix < 4384 :
                tab[2191].append(prix)
            elif prix < 4386 :
                tab[2192].append(prix)
            elif prix < 4388 :
                tab[2193].append(prix)
            elif prix < 4390 :
                tab[2194].append(prix)
            elif prix < 4392 :
                tab[2195].append(prix)
            elif prix < 4394 :
                tab[2196].append(prix)
            elif prix < 4396 :
                tab[2197].append(prix)
            elif prix < 4398 :
                tab[2198].append(prix)
            elif prix < 4400 :
                tab[2199].append(prix)
            elif prix < 4402 :
                tab[2200].append(prix)
            elif prix < 4404 :
                tab[2201].append(prix)
            elif prix < 4406 :
                tab[2202].append(prix)
            elif prix < 4408 :
                tab[2203].append(prix)
            elif prix < 4410 :
                tab[2204].append(prix)
            elif prix < 4412 :
                tab[2205].append(prix)
            elif prix < 4414 :
                tab[2206].append(prix)
            elif prix < 4416 :
                tab[2207].append(prix)
            elif prix < 4418 :
                tab[2208].append(prix)
            elif prix < 4420 :
                tab[2209].append(prix)
            elif prix < 4422 :
                tab[2210].append(prix)
            elif prix < 4424 :
                tab[2211].append(prix)
            elif prix < 4426 :
                tab[2212].append(prix)
            elif prix < 4428 :
                tab[2213].append(prix)
            elif prix < 4430 :
                tab[2214].append(prix)
            elif prix < 4432 :
                tab[2215].append(prix)
            elif prix < 4434 :
                tab[2216].append(prix)
            elif prix < 4436 :
                tab[2217].append(prix)
            elif prix < 4438 :
                tab[2218].append(prix)
            elif prix < 4440 :
                tab[2219].append(prix)
            elif prix < 4442 :
                tab[2220].append(prix)
            elif prix < 4444 :
                tab[2221].append(prix)
            elif prix < 4446 :
                tab[2222].append(prix)
            elif prix < 4448 :
                tab[2223].append(prix)
            elif prix < 4450 :
                tab[2224].append(prix)
            elif prix < 4452 :
                tab[2225].append(prix)
            elif prix < 4454 :
                tab[2226].append(prix)
            elif prix < 4456 :
                tab[2227].append(prix)
            elif prix < 4458 :
                tab[2228].append(prix)
            elif prix < 4460 :
                tab[2229].append(prix)
            elif prix < 4462 :
                tab[2230].append(prix)
            elif prix < 4464 :
                tab[2231].append(prix)
            elif prix < 4466 :
                tab[2232].append(prix)
            elif prix < 4468 :
                tab[2233].append(prix)
            elif prix < 4470 :
                tab[2234].append(prix)
            elif prix < 4472 :
                tab[2235].append(prix)
            elif prix < 4474 :
                tab[2236].append(prix)
            elif prix < 4476 :
                tab[2237].append(prix)
            elif prix < 4478 :
                tab[2238].append(prix)
            elif prix < 4480 :
                tab[2239].append(prix)
            elif prix < 4482 :
                tab[2240].append(prix)
            elif prix < 4484 :
                tab[2241].append(prix)
            elif prix < 4486 :
                tab[2242].append(prix)
            elif prix < 4488 :
                tab[2243].append(prix)
            elif prix < 4490 :
                tab[2244].append(prix)
            elif prix < 4492 :
                tab[2245].append(prix)
            elif prix < 4494 :
                tab[2246].append(prix)
            elif prix < 4496 :
                tab[2247].append(prix)
            elif prix < 4498 :
                tab[2248].append(prix)
            elif prix < 4500 :
                tab[2249].append(prix)
            elif prix < 4502 :
                tab[2250].append(prix)
            elif prix < 4504 :
                tab[2251].append(prix)
            elif prix < 4506 :
                tab[2252].append(prix)
            elif prix < 4508 :
                tab[2253].append(prix)
            elif prix < 4510 :
                tab[2254].append(prix)
            elif prix < 4512 :
                tab[2255].append(prix)
            elif prix < 4514 :
                tab[2256].append(prix)
            elif prix < 4516 :
                tab[2257].append(prix)
            elif prix < 4518 :
                tab[2258].append(prix)
            elif prix < 4520 :
                tab[2259].append(prix)
            elif prix < 4522 :
                tab[2260].append(prix)
            elif prix < 4524 :
                tab[2261].append(prix)
            elif prix < 4526 :
                tab[2262].append(prix)
            elif prix < 4528 :
                tab[2263].append(prix)
            elif prix < 4530 :
                tab[2264].append(prix)
            elif prix < 4532 :
                tab[2265].append(prix)
            elif prix < 4534 :
                tab[2266].append(prix)
            elif prix < 4536 :
                tab[2267].append(prix)
            elif prix < 4538 :
                tab[2268].append(prix)
            elif prix < 4540 :
                tab[2269].append(prix)
            elif prix < 4542 :
                tab[2270].append(prix)
            elif prix < 4544 :
                tab[2271].append(prix)
            elif prix < 4546 :
                tab[2272].append(prix)
            elif prix < 4548 :
                tab[2273].append(prix)
            elif prix < 4550 :
                tab[2274].append(prix)
            elif prix < 4552 :
                tab[2275].append(prix)
            elif prix < 4554 :
                tab[2276].append(prix)
            elif prix < 4556 :
                tab[2277].append(prix)
            elif prix < 4558 :
                tab[2278].append(prix)
            elif prix < 4560 :
                tab[2279].append(prix)
            elif prix < 4562 :
                tab[2280].append(prix)
            elif prix < 4564 :
                tab[2281].append(prix)
            elif prix < 4566 :
                tab[2282].append(prix)
            elif prix < 4568 :
                tab[2283].append(prix)
            elif prix < 4570 :
                tab[2284].append(prix)
            elif prix < 4572 :
                tab[2285].append(prix)
            elif prix < 4574 :
                tab[2286].append(prix)
            elif prix < 4576 :
                tab[2287].append(prix)
            elif prix < 4578 :
                tab[2288].append(prix)
            elif prix < 4580 :
                tab[2289].append(prix)
            elif prix < 4582 :
                tab[2290].append(prix)
            elif prix < 4584 :
                tab[2291].append(prix)
            elif prix < 4586 :
                tab[2292].append(prix)
            elif prix < 4588 :
                tab[2293].append(prix)
            elif prix < 4590 :
                tab[2294].append(prix)
            elif prix < 4592 :
                tab[2295].append(prix)
            elif prix < 4594 :
                tab[2296].append(prix)
            elif prix < 4596 :
                tab[2297].append(prix)
            elif prix < 4598 :
                tab[2298].append(prix)
            elif prix < 4600 :
                tab[2299].append(prix)
            elif prix < 4602 :
                tab[2300].append(prix)
            elif prix < 4604 :
                tab[2301].append(prix)
            elif prix < 4606 :
                tab[2302].append(prix)
            elif prix < 4608 :
                tab[2303].append(prix)
            elif prix < 4610 :
                tab[2304].append(prix)
            elif prix < 4612 :
                tab[2305].append(prix)
            elif prix < 4614 :
                tab[2306].append(prix)
            elif prix < 4616 :
                tab[2307].append(prix)
            elif prix < 4618 :
                tab[2308].append(prix)
            elif prix < 4620 :
                tab[2309].append(prix)
            elif prix < 4622 :
                tab[2310].append(prix)
            elif prix < 4624 :
                tab[2311].append(prix)
            elif prix < 4626 :
                tab[2312].append(prix)
            elif prix < 4628 :
                tab[2313].append(prix)
            elif prix < 4630 :
                tab[2314].append(prix)
            elif prix < 4632 :
                tab[2315].append(prix)
            elif prix < 4634 :
                tab[2316].append(prix)
            elif prix < 4636 :
                tab[2317].append(prix)
            elif prix < 4638 :
                tab[2318].append(prix)
            elif prix < 4640 :
                tab[2319].append(prix)
            elif prix < 4642 :
                tab[2320].append(prix)
            elif prix < 4644 :
                tab[2321].append(prix)
            elif prix < 4646 :
                tab[2322].append(prix)
            elif prix < 4648 :
                tab[2323].append(prix)
            elif prix < 4650 :
                tab[2324].append(prix)
            elif prix < 4652 :
                tab[2325].append(prix)
            elif prix < 4654 :
                tab[2326].append(prix)
            elif prix < 4656 :
                tab[2327].append(prix)
            elif prix < 4658 :
                tab[2328].append(prix)
            elif prix < 4660 :
                tab[2329].append(prix)
            elif prix < 4662 :
                tab[2330].append(prix)
            elif prix < 4664 :
                tab[2331].append(prix)
            elif prix < 4666 :
                tab[2332].append(prix)
            elif prix < 4668 :
                tab[2333].append(prix)
            elif prix < 4670 :
                tab[2334].append(prix)
            elif prix < 4672 :
                tab[2335].append(prix)
            elif prix < 4674 :
                tab[2336].append(prix)
            elif prix < 4676 :
                tab[2337].append(prix)
            elif prix < 4678 :
                tab[2338].append(prix)
            elif prix < 4680 :
                tab[2339].append(prix)
            elif prix < 4682 :
                tab[2340].append(prix)
            elif prix < 4684 :
                tab[2341].append(prix)
            elif prix < 4686 :
                tab[2342].append(prix)
            elif prix < 4688 :
                tab[2343].append(prix)
            elif prix < 4690 :
                tab[2344].append(prix)
            elif prix < 4692 :
                tab[2345].append(prix)
            elif prix < 4694 :
                tab[2346].append(prix)
            elif prix < 4696 :
                tab[2347].append(prix)
            elif prix < 4698 :
                tab[2348].append(prix)
            elif prix < 4700 :
                tab[2349].append(prix)
            elif prix < 4702 :
                tab[2350].append(prix)
            elif prix < 4704 :
                tab[2351].append(prix)
            elif prix < 4706 :
                tab[2352].append(prix)
            elif prix < 4708 :
                tab[2353].append(prix)
            elif prix < 4710 :
                tab[2354].append(prix)
            elif prix < 4712 :
                tab[2355].append(prix)
            elif prix < 4714 :
                tab[2356].append(prix)
            elif prix < 4716 :
                tab[2357].append(prix)
            elif prix < 4718 :
                tab[2358].append(prix)
            elif prix < 4720 :
                tab[2359].append(prix)
            elif prix < 4722 :
                tab[2360].append(prix)
            elif prix < 4724 :
                tab[2361].append(prix)
            elif prix < 4726 :
                tab[2362].append(prix)
            elif prix < 4728 :
                tab[2363].append(prix)
            elif prix < 4730 :
                tab[2364].append(prix)
            elif prix < 4732 :
                tab[2365].append(prix)
            elif prix < 4734 :
                tab[2366].append(prix)
            elif prix < 4736 :
                tab[2367].append(prix)
            elif prix < 4738 :
                tab[2368].append(prix)
            elif prix < 4740 :
                tab[2369].append(prix)
            elif prix < 4742 :
                tab[2370].append(prix)
            elif prix < 4744 :
                tab[2371].append(prix)
            elif prix < 4746 :
                tab[2372].append(prix)
            elif prix < 4748 :
                tab[2373].append(prix)
            elif prix < 4750 :
                tab[2374].append(prix)
            elif prix < 4752 :
                tab[2375].append(prix)
            elif prix < 4754 :
                tab[2376].append(prix)
            elif prix < 4756 :
                tab[2377].append(prix)
            elif prix < 4758 :
                tab[2378].append(prix)
            elif prix < 4760 :
                tab[2379].append(prix)
            elif prix < 4762 :
                tab[2380].append(prix)
            elif prix < 4764 :
                tab[2381].append(prix)
            elif prix < 4766 :
                tab[2382].append(prix)
            elif prix < 4768 :
                tab[2383].append(prix)
            elif prix < 4770 :
                tab[2384].append(prix)
            elif prix < 4772 :
                tab[2385].append(prix)
            elif prix < 4774 :
                tab[2386].append(prix)
            elif prix < 4776 :
                tab[2387].append(prix)
            elif prix < 4778 :
                tab[2388].append(prix)
            elif prix < 4780 :
                tab[2389].append(prix)
            elif prix < 4782 :
                tab[2390].append(prix)
            elif prix < 4784 :
                tab[2391].append(prix)
            elif prix < 4786 :
                tab[2392].append(prix)
            elif prix < 4788 :
                tab[2393].append(prix)
            elif prix < 4790 :
                tab[2394].append(prix)
            elif prix < 4792 :
                tab[2395].append(prix)
            elif prix < 4794 :
                tab[2396].append(prix)
            elif prix < 4796 :
                tab[2397].append(prix)
            elif prix < 4798 :
                tab[2398].append(prix)
            elif prix < 4800 :
                tab[2399].append(prix)
            elif prix < 4802 :
                tab[2400].append(prix)
            elif prix < 4804 :
                tab[2401].append(prix)
            elif prix < 4806 :
                tab[2402].append(prix)
            elif prix < 4808 :
                tab[2403].append(prix)
            elif prix < 4810 :
                tab[2404].append(prix)
            elif prix < 4812 :
                tab[2405].append(prix)
            elif prix < 4814 :
                tab[2406].append(prix)
            elif prix < 4816 :
                tab[2407].append(prix)
            elif prix < 4818 :
                tab[2408].append(prix)
            elif prix < 4820 :
                tab[2409].append(prix)
            elif prix < 4822 :
                tab[2410].append(prix)
            elif prix < 4824 :
                tab[2411].append(prix)
            elif prix < 4826 :
                tab[2412].append(prix)
            elif prix < 4828 :
                tab[2413].append(prix)
            elif prix < 4830 :
                tab[2414].append(prix)
            elif prix < 4832 :
                tab[2415].append(prix)
            elif prix < 4834 :
                tab[2416].append(prix)
            elif prix < 4836 :
                tab[2417].append(prix)
            elif prix < 4838 :
                tab[2418].append(prix)
            elif prix < 4840 :
                tab[2419].append(prix)
            elif prix < 4842 :
                tab[2420].append(prix)
            elif prix < 4844 :
                tab[2421].append(prix)
            elif prix < 4846 :
                tab[2422].append(prix)
            elif prix < 4848 :
                tab[2423].append(prix)
            elif prix < 4850 :
                tab[2424].append(prix)
            elif prix < 4852 :
                tab[2425].append(prix)
            elif prix < 4854 :
                tab[2426].append(prix)
            elif prix < 4856 :
                tab[2427].append(prix)
            elif prix < 4858 :
                tab[2428].append(prix)
            elif prix < 4860 :
                tab[2429].append(prix)
            elif prix < 4862 :
                tab[2430].append(prix)
            elif prix < 4864 :
                tab[2431].append(prix)
            elif prix < 4866 :
                tab[2432].append(prix)
            elif prix < 4868 :
                tab[2433].append(prix)
            elif prix < 4870 :
                tab[2434].append(prix)
            elif prix < 4872 :
                tab[2435].append(prix)
            elif prix < 4874 :
                tab[2436].append(prix)
            elif prix < 4876 :
                tab[2437].append(prix)
            elif prix < 4878 :
                tab[2438].append(prix)
            elif prix < 4880 :
                tab[2439].append(prix)
            elif prix < 4882 :
                tab[2440].append(prix)
            elif prix < 4884 :
                tab[2441].append(prix)
            elif prix < 4886 :
                tab[2442].append(prix)
            elif prix < 4888 :
                tab[2443].append(prix)
            elif prix < 4890 :
                tab[2444].append(prix)
            elif prix < 4892 :
                tab[2445].append(prix)
            elif prix < 4894 :
                tab[2446].append(prix)
            elif prix < 4896 :
                tab[2447].append(prix)
            elif prix < 4898 :
                tab[2448].append(prix)
            elif prix < 4900 :
                tab[2449].append(prix)
            elif prix < 4902 :
                tab[2450].append(prix)
            elif prix < 4904 :
                tab[2451].append(prix)
            elif prix < 4906 :
                tab[2452].append(prix)
            elif prix < 4908 :
                tab[2453].append(prix)
            elif prix < 4910 :
                tab[2454].append(prix)
            elif prix < 4912 :
                tab[2455].append(prix)
            elif prix < 4914 :
                tab[2456].append(prix)
            elif prix < 4916 :
                tab[2457].append(prix)
            elif prix < 4918 :
                tab[2458].append(prix)
            elif prix < 4920 :
                tab[2459].append(prix)
            elif prix < 4922 :
                tab[2460].append(prix)
            elif prix < 4924 :
                tab[2461].append(prix)
            elif prix < 4926 :
                tab[2462].append(prix)
            elif prix < 4928 :
                tab[2463].append(prix)
            elif prix < 4930 :
                tab[2464].append(prix)
            elif prix < 4932 :
                tab[2465].append(prix)
            elif prix < 4934 :
                tab[2466].append(prix)
            elif prix < 4936 :
                tab[2467].append(prix)
            elif prix < 4938 :
                tab[2468].append(prix)
            elif prix < 4940 :
                tab[2469].append(prix)
            elif prix < 4942 :
                tab[2470].append(prix)
            elif prix < 4944 :
                tab[2471].append(prix)
            elif prix < 4946 :
                tab[2472].append(prix)
            elif prix < 4948 :
                tab[2473].append(prix)
            elif prix < 4950 :
                tab[2474].append(prix)
            elif prix < 4952 :
                tab[2475].append(prix)
            elif prix < 4954 :
                tab[2476].append(prix)
            elif prix < 4956 :
                tab[2477].append(prix)
            elif prix < 4958 :
                tab[2478].append(prix)
            elif prix < 4960 :
                tab[2479].append(prix)
            elif prix < 4962 :
                tab[2480].append(prix)
            elif prix < 4964 :
                tab[2481].append(prix)
            elif prix < 4966 :
                tab[2482].append(prix)
            elif prix < 4968 :
                tab[2483].append(prix)
            elif prix < 4970 :
                tab[2484].append(prix)
            elif prix < 4972 :
                tab[2485].append(prix)
            elif prix < 4974 :
                tab[2486].append(prix)
            elif prix < 4976 :
                tab[2487].append(prix)
            elif prix < 4978 :
                tab[2488].append(prix)
            elif prix < 4980 :
                tab[2489].append(prix)
            elif prix < 4982 :
                tab[2490].append(prix)
            elif prix < 4984 :
                tab[2491].append(prix)
            elif prix < 4986 :
                tab[2492].append(prix)
            elif prix < 4988 :
                tab[2493].append(prix)
            elif prix < 4990 :
                tab[2494].append(prix)
            elif prix < 4992 :
                tab[2495].append(prix)
            elif prix < 4994 :
                tab[2496].append(prix)
            elif prix < 4996 :
                tab[2497].append(prix)
            elif prix < 4998 :
                tab[2498].append(prix)
            elif prix < 5000 :
                tab[2499].append(prix)
            elif prix < 5002 :
                tab[2500].append(prix)
            elif prix < 5004 :
                tab[2501].append(prix)
            elif prix < 5006 :
                tab[2502].append(prix)
            elif prix < 5008 :
                tab[2503].append(prix)
            elif prix < 5010 :
                tab[2504].append(prix)
            elif prix < 5012 :
                tab[2505].append(prix)
            elif prix < 5014 :
                tab[2506].append(prix)
            elif prix < 5016 :
                tab[2507].append(prix)
            elif prix < 5018 :
                tab[2508].append(prix)
            elif prix < 5020 :
                tab[2509].append(prix)
            elif prix < 5022 :
                tab[2510].append(prix)
            elif prix < 5024 :
                tab[2511].append(prix)
            elif prix < 5026 :
                tab[2512].append(prix)
            elif prix < 5028 :
                tab[2513].append(prix)
            elif prix < 5030 :
                tab[2514].append(prix)
            elif prix < 5032 :
                tab[2515].append(prix)
            elif prix < 5034 :
                tab[2516].append(prix)
            elif prix < 5036 :
                tab[2517].append(prix)
            elif prix < 5038 :
                tab[2518].append(prix)
            elif prix < 5040 :
                tab[2519].append(prix)
            elif prix < 5042 :
                tab[2520].append(prix)
            elif prix < 5044 :
                tab[2521].append(prix)
            elif prix < 5046 :
                tab[2522].append(prix)
            elif prix < 5048 :
                tab[2523].append(prix)
            elif prix < 5050 :
                tab[2524].append(prix)
            elif prix < 5052 :
                tab[2525].append(prix)
            elif prix < 5054 :
                tab[2526].append(prix)
            elif prix < 5056 :
                tab[2527].append(prix)
            elif prix < 5058 :
                tab[2528].append(prix)
            elif prix < 5060 :
                tab[2529].append(prix)
            elif prix < 5062 :
                tab[2530].append(prix)
            elif prix < 5064 :
                tab[2531].append(prix)
            elif prix < 5066 :
                tab[2532].append(prix)
            elif prix < 5068 :
                tab[2533].append(prix)
            elif prix < 5070 :
                tab[2534].append(prix)
            elif prix < 5072 :
                tab[2535].append(prix)
            elif prix < 5074 :
                tab[2536].append(prix)
            elif prix < 5076 :
                tab[2537].append(prix)
            elif prix < 5078 :
                tab[2538].append(prix)
            elif prix < 5080 :
                tab[2539].append(prix)
            elif prix < 5082 :
                tab[2540].append(prix)
            elif prix < 5084 :
                tab[2541].append(prix)
            elif prix < 5086 :
                tab[2542].append(prix)
            elif prix < 5088 :
                tab[2543].append(prix)
            elif prix < 5090 :
                tab[2544].append(prix)
            elif prix < 5092 :
                tab[2545].append(prix)
            elif prix < 5094 :
                tab[2546].append(prix)
            elif prix < 5096 :
                tab[2547].append(prix)
            elif prix < 5098 :
                tab[2548].append(prix)
            elif prix < 5100 :
                tab[2549].append(prix)
            elif prix < 5102 :
                tab[2550].append(prix)
            elif prix < 5104 :
                tab[2551].append(prix)
            elif prix < 5106 :
                tab[2552].append(prix)
            elif prix < 5108 :
                tab[2553].append(prix)
            elif prix < 5110 :
                tab[2554].append(prix)
            elif prix < 5112 :
                tab[2555].append(prix)
            elif prix < 5114 :
                tab[2556].append(prix)
            elif prix < 5116 :
                tab[2557].append(prix)
            elif prix < 5118 :
                tab[2558].append(prix)
            elif prix < 5120 :
                tab[2559].append(prix)
            elif prix < 5122 :
                tab[2560].append(prix)
            elif prix < 5124 :
                tab[2561].append(prix)
            elif prix < 5126 :
                tab[2562].append(prix)
            elif prix < 5128 :
                tab[2563].append(prix)
            elif prix < 5130 :
                tab[2564].append(prix)
            elif prix < 5132 :
                tab[2565].append(prix)
            elif prix < 5134 :
                tab[2566].append(prix)
            elif prix < 5136 :
                tab[2567].append(prix)
            elif prix < 5138 :
                tab[2568].append(prix)
            elif prix < 5140 :
                tab[2569].append(prix)
            elif prix < 5142 :
                tab[2570].append(prix)
            elif prix < 5144 :
                tab[2571].append(prix)
            elif prix < 5146 :
                tab[2572].append(prix)
            elif prix < 5148 :
                tab[2573].append(prix)
            elif prix < 5150 :
                tab[2574].append(prix)
            elif prix < 5152 :
                tab[2575].append(prix)
            elif prix < 5154 :
                tab[2576].append(prix)
            elif prix < 5156 :
                tab[2577].append(prix)
            elif prix < 5158 :
                tab[2578].append(prix)
            elif prix < 5160 :
                tab[2579].append(prix)
            elif prix < 5162 :
                tab[2580].append(prix)
            elif prix < 5164 :
                tab[2581].append(prix)
            elif prix < 5166 :
                tab[2582].append(prix)
            elif prix < 5168 :
                tab[2583].append(prix)
            elif prix < 5170 :
                tab[2584].append(prix)
            elif prix < 5172 :
                tab[2585].append(prix)
            elif prix < 5174 :
                tab[2586].append(prix)
            elif prix < 5176 :
                tab[2587].append(prix)
            elif prix < 5178 :
                tab[2588].append(prix)
            elif prix < 5180 :
                tab[2589].append(prix)
            elif prix < 5182 :
                tab[2590].append(prix)
            elif prix < 5184 :
                tab[2591].append(prix)
            elif prix < 5186 :
                tab[2592].append(prix)
            elif prix < 5188 :
                tab[2593].append(prix)
            elif prix < 5190 :
                tab[2594].append(prix)
            elif prix < 5192 :
                tab[2595].append(prix)
            elif prix < 5194 :
                tab[2596].append(prix)
            elif prix < 5196 :
                tab[2597].append(prix)
            elif prix < 5198 :
                tab[2598].append(prix)
            elif prix < 5200 :
                tab[2599].append(prix)
            elif prix < 5202 :
                tab[2600].append(prix)
            elif prix < 5204 :
                tab[2601].append(prix)
            elif prix < 5206 :
                tab[2602].append(prix)
            elif prix < 5208 :
                tab[2603].append(prix)
            elif prix < 5210 :
                tab[2604].append(prix)
            elif prix < 5212 :
                tab[2605].append(prix)
            elif prix < 5214 :
                tab[2606].append(prix)
            elif prix < 5216 :
                tab[2607].append(prix)
            elif prix < 5218 :
                tab[2608].append(prix)
            elif prix < 5220 :
                tab[2609].append(prix)
            elif prix < 5222 :
                tab[2610].append(prix)
            elif prix < 5224 :
                tab[2611].append(prix)
            elif prix < 5226 :
                tab[2612].append(prix)
            elif prix < 5228 :
                tab[2613].append(prix)
            elif prix < 5230 :
                tab[2614].append(prix)
            elif prix < 5232 :
                tab[2615].append(prix)
            elif prix < 5234 :
                tab[2616].append(prix)
            elif prix < 5236 :
                tab[2617].append(prix)
            elif prix < 5238 :
                tab[2618].append(prix)
            elif prix < 5240 :
                tab[2619].append(prix)
            elif prix < 5242 :
                tab[2620].append(prix)
            elif prix < 5244 :
                tab[2621].append(prix)
            elif prix < 5246 :
                tab[2622].append(prix)
            elif prix < 5248 :
                tab[2623].append(prix)
            elif prix < 5250 :
                tab[2624].append(prix)
            elif prix < 5252 :
                tab[2625].append(prix)
            elif prix < 5254 :
                tab[2626].append(prix)
            elif prix < 5256 :
                tab[2627].append(prix)
            elif prix < 5258 :
                tab[2628].append(prix)
            elif prix < 5260 :
                tab[2629].append(prix)
            elif prix < 5262 :
                tab[2630].append(prix)
            elif prix < 5264 :
                tab[2631].append(prix)
            elif prix < 5266 :
                tab[2632].append(prix)
            elif prix < 5268 :
                tab[2633].append(prix)
            elif prix < 5270 :
                tab[2634].append(prix)
            elif prix < 5272 :
                tab[2635].append(prix)
            elif prix < 5274 :
                tab[2636].append(prix)
            elif prix < 5276 :
                tab[2637].append(prix)
            elif prix < 5278 :
                tab[2638].append(prix)
            elif prix < 5280 :
                tab[2639].append(prix)
            elif prix < 5282 :
                tab[2640].append(prix)
            elif prix < 5284 :
                tab[2641].append(prix)
            elif prix < 5286 :
                tab[2642].append(prix)
            elif prix < 5288 :
                tab[2643].append(prix)
            elif prix < 5290 :
                tab[2644].append(prix)
            elif prix < 5292 :
                tab[2645].append(prix)
            elif prix < 5294 :
                tab[2646].append(prix)
            elif prix < 5296 :
                tab[2647].append(prix)
            elif prix < 5298 :
                tab[2648].append(prix)
            elif prix < 5300 :
                tab[2649].append(prix)
            elif prix < 5302 :
                tab[2650].append(prix)
            elif prix < 5304 :
                tab[2651].append(prix)
            elif prix < 5306 :
                tab[2652].append(prix)
            elif prix < 5308 :
                tab[2653].append(prix)
            elif prix < 5310 :
                tab[2654].append(prix)
            elif prix < 5312 :
                tab[2655].append(prix)
            elif prix < 5314 :
                tab[2656].append(prix)
            elif prix < 5316 :
                tab[2657].append(prix)
            elif prix < 5318 :
                tab[2658].append(prix)
            elif prix < 5320 :
                tab[2659].append(prix)
            elif prix < 5322 :
                tab[2660].append(prix)
            elif prix < 5324 :
                tab[2661].append(prix)
            elif prix < 5326 :
                tab[2662].append(prix)
            elif prix < 5328 :
                tab[2663].append(prix)
            elif prix < 5330 :
                tab[2664].append(prix)
            elif prix < 5332 :
                tab[2665].append(prix)
            elif prix < 5334 :
                tab[2666].append(prix)
            elif prix < 5336 :
                tab[2667].append(prix)
            elif prix < 5338 :
                tab[2668].append(prix)
            elif prix < 5340 :
                tab[2669].append(prix)
            elif prix < 5342 :
                tab[2670].append(prix)
            elif prix < 5344 :
                tab[2671].append(prix)
            elif prix < 5346 :
                tab[2672].append(prix)
            elif prix < 5348 :
                tab[2673].append(prix)
            elif prix < 5350 :
                tab[2674].append(prix)
            elif prix < 5352 :
                tab[2675].append(prix)
            elif prix < 5354 :
                tab[2676].append(prix)
            elif prix < 5356 :
                tab[2677].append(prix)
            elif prix < 5358 :
                tab[2678].append(prix)
            elif prix < 5360 :
                tab[2679].append(prix)
            elif prix < 5362 :
                tab[2680].append(prix)
            elif prix < 5364 :
                tab[2681].append(prix)
            elif prix < 5366 :
                tab[2682].append(prix)
            elif prix < 5368 :
                tab[2683].append(prix)
            elif prix < 5370 :
                tab[2684].append(prix)
            elif prix < 5372 :
                tab[2685].append(prix)
            elif prix < 5374 :
                tab[2686].append(prix)
            elif prix < 5376 :
                tab[2687].append(prix)
            elif prix < 5378 :
                tab[2688].append(prix)
            elif prix < 5380 :
                tab[2689].append(prix)
            elif prix < 5382 :
                tab[2690].append(prix)
            elif prix < 5384 :
                tab[2691].append(prix)
            elif prix < 5386 :
                tab[2692].append(prix)
            elif prix < 5388 :
                tab[2693].append(prix)
            elif prix < 5390 :
                tab[2694].append(prix)
            elif prix < 5392 :
                tab[2695].append(prix)
            elif prix < 5394 :
                tab[2696].append(prix)
            elif prix < 5396 :
                tab[2697].append(prix)
            elif prix < 5398 :
                tab[2698].append(prix)
            elif prix < 5400 :
                tab[2699].append(prix)
            elif prix < 5402 :
                tab[2700].append(prix)
            elif prix < 5404 :
                tab[2701].append(prix)
            elif prix < 5406 :
                tab[2702].append(prix)
            elif prix < 5408 :
                tab[2703].append(prix)
            elif prix < 5410 :
                tab[2704].append(prix)
            elif prix < 5412 :
                tab[2705].append(prix)
            elif prix < 5414 :
                tab[2706].append(prix)
            elif prix < 5416 :
                tab[2707].append(prix)
            elif prix < 5418 :
                tab[2708].append(prix)
            elif prix < 5420 :
                tab[2709].append(prix)
            elif prix < 5422 :
                tab[2710].append(prix)
            elif prix < 5424 :
                tab[2711].append(prix)
            elif prix < 5426 :
                tab[2712].append(prix)
            elif prix < 5428 :
                tab[2713].append(prix)
            elif prix < 5430 :
                tab[2714].append(prix)
            elif prix < 5432 :
                tab[2715].append(prix)
            elif prix < 5434 :
                tab[2716].append(prix)
            elif prix < 5436 :
                tab[2717].append(prix)
            elif prix < 5438 :
                tab[2718].append(prix)
            elif prix < 5440 :
                tab[2719].append(prix)
            elif prix < 5442 :
                tab[2720].append(prix)
            elif prix < 5444 :
                tab[2721].append(prix)
            elif prix < 5446 :
                tab[2722].append(prix)
            elif prix < 5448 :
                tab[2723].append(prix)
            elif prix < 5450 :
                tab[2724].append(prix)
            elif prix < 5452 :
                tab[2725].append(prix)
            elif prix < 5454 :
                tab[2726].append(prix)
            elif prix < 5456 :
                tab[2727].append(prix)
            elif prix < 5458 :
                tab[2728].append(prix)
            elif prix < 5460 :
                tab[2729].append(prix)
            elif prix < 5462 :
                tab[2730].append(prix)
            elif prix < 5464 :
                tab[2731].append(prix)
            elif prix < 5466 :
                tab[2732].append(prix)
            elif prix < 5468 :
                tab[2733].append(prix)
            elif prix < 5470 :
                tab[2734].append(prix)
            elif prix < 5472 :
                tab[2735].append(prix)
            elif prix < 5474 :
                tab[2736].append(prix)
            elif prix < 5476 :
                tab[2737].append(prix)
            elif prix < 5478 :
                tab[2738].append(prix)
            elif prix < 5480 :
                tab[2739].append(prix)
            elif prix < 5482 :
                tab[2740].append(prix)
            elif prix < 5484 :
                tab[2741].append(prix)
            elif prix < 5486 :
                tab[2742].append(prix)
            elif prix < 5488 :
                tab[2743].append(prix)
            elif prix < 5490 :
                tab[2744].append(prix)
            elif prix < 5492 :
                tab[2745].append(prix)
            elif prix < 5494 :
                tab[2746].append(prix)
            elif prix < 5496 :
                tab[2747].append(prix)
            elif prix < 5498 :
                tab[2748].append(prix)
            elif prix < 5500 :
                tab[2749].append(prix)
            elif prix < 5502 :
                tab[2750].append(prix)
            elif prix < 5504 :
                tab[2751].append(prix)
            elif prix < 5506 :
                tab[2752].append(prix)
            elif prix < 5508 :
                tab[2753].append(prix)
            elif prix < 5510 :
                tab[2754].append(prix)
            elif prix < 5512 :
                tab[2755].append(prix)
            elif prix < 5514 :
                tab[2756].append(prix)
            elif prix < 5516 :
                tab[2757].append(prix)
            elif prix < 5518 :
                tab[2758].append(prix)
            elif prix < 5520 :
                tab[2759].append(prix)
            elif prix < 5522 :
                tab[2760].append(prix)
            elif prix < 5524 :
                tab[2761].append(prix)
            elif prix < 5526 :
                tab[2762].append(prix)
            elif prix < 5528 :
                tab[2763].append(prix)
            elif prix < 5530 :
                tab[2764].append(prix)
            elif prix < 5532 :
                tab[2765].append(prix)
            elif prix < 5534 :
                tab[2766].append(prix)
            elif prix < 5536 :
                tab[2767].append(prix)
            elif prix < 5538 :
                tab[2768].append(prix)
            elif prix < 5540 :
                tab[2769].append(prix)
            elif prix < 5542 :
                tab[2770].append(prix)
            elif prix < 5544 :
                tab[2771].append(prix)
            elif prix < 5546 :
                tab[2772].append(prix)
            elif prix < 5548 :
                tab[2773].append(prix)
            elif prix < 5550 :
                tab[2774].append(prix)
            elif prix < 5552 :
                tab[2775].append(prix)
            elif prix < 5554 :
                tab[2776].append(prix)
            elif prix < 5556 :
                tab[2777].append(prix)
            elif prix < 5558 :
                tab[2778].append(prix)
            elif prix < 5560 :
                tab[2779].append(prix)
            elif prix < 5562 :
                tab[2780].append(prix)
            elif prix < 5564 :
                tab[2781].append(prix)
            elif prix < 5566 :
                tab[2782].append(prix)
            elif prix < 5568 :
                tab[2783].append(prix)
            elif prix < 5570 :
                tab[2784].append(prix)
            elif prix < 5572 :
                tab[2785].append(prix)
            elif prix < 5574 :
                tab[2786].append(prix)
            elif prix < 5576 :
                tab[2787].append(prix)
            elif prix < 5578 :
                tab[2788].append(prix)
            elif prix < 5580 :
                tab[2789].append(prix)
            elif prix < 5582 :
                tab[2790].append(prix)
            elif prix < 5584 :
                tab[2791].append(prix)
            elif prix < 5586 :
                tab[2792].append(prix)
            elif prix < 5588 :
                tab[2793].append(prix)
            elif prix < 5590 :
                tab[2794].append(prix)
            elif prix < 5592 :
                tab[2795].append(prix)
            elif prix < 5594 :
                tab[2796].append(prix)
            elif prix < 5596 :
                tab[2797].append(prix)
            elif prix < 5598 :
                tab[2798].append(prix)
            elif prix < 5600 :
                tab[2799].append(prix)
            elif prix < 5602 :
                tab[2800].append(prix)
            elif prix < 5604 :
                tab[2801].append(prix)
            elif prix < 5606 :
                tab[2802].append(prix)
            elif prix < 5608 :
                tab[2803].append(prix)
            elif prix < 5610 :
                tab[2804].append(prix)
            elif prix < 5612 :
                tab[2805].append(prix)
            elif prix < 5614 :
                tab[2806].append(prix)
            elif prix < 5616 :
                tab[2807].append(prix)
            elif prix < 5618 :
                tab[2808].append(prix)
            elif prix < 5620 :
                tab[2809].append(prix)
            elif prix < 5622 :
                tab[2810].append(prix)
            elif prix < 5624 :
                tab[2811].append(prix)
            elif prix < 5626 :
                tab[2812].append(prix)
            elif prix < 5628 :
                tab[2813].append(prix)
            elif prix < 5630 :
                tab[2814].append(prix)
            elif prix < 5632 :
                tab[2815].append(prix)
            elif prix < 5634 :
                tab[2816].append(prix)
            elif prix < 5636 :
                tab[2817].append(prix)
            elif prix < 5638 :
                tab[2818].append(prix)
            elif prix < 5640 :
                tab[2819].append(prix)
            elif prix < 5642 :
                tab[2820].append(prix)
            elif prix < 5644 :
                tab[2821].append(prix)
            elif prix < 5646 :
                tab[2822].append(prix)
            elif prix < 5648 :
                tab[2823].append(prix)
            elif prix < 5650 :
                tab[2824].append(prix)
            elif prix < 5652 :
                tab[2825].append(prix)
            elif prix < 5654 :
                tab[2826].append(prix)
            elif prix < 5656 :
                tab[2827].append(prix)
            elif prix < 5658 :
                tab[2828].append(prix)
            elif prix < 5660 :
                tab[2829].append(prix)
            elif prix < 5662 :
                tab[2830].append(prix)
            elif prix < 5664 :
                tab[2831].append(prix)
            elif prix < 5666 :
                tab[2832].append(prix)
            elif prix < 5668 :
                tab[2833].append(prix)
            elif prix < 5670 :
                tab[2834].append(prix)
            elif prix < 5672 :
                tab[2835].append(prix)
            elif prix < 5674 :
                tab[2836].append(prix)
            elif prix < 5676 :
                tab[2837].append(prix)
            elif prix < 5678 :
                tab[2838].append(prix)
            elif prix < 5680 :
                tab[2839].append(prix)
            elif prix < 5682 :
                tab[2840].append(prix)
            elif prix < 5684 :
                tab[2841].append(prix)
            elif prix < 5686 :
                tab[2842].append(prix)
            elif prix < 5688 :
                tab[2843].append(prix)
            elif prix < 5690 :
                tab[2844].append(prix)
            elif prix < 5692 :
                tab[2845].append(prix)
            elif prix < 5694 :
                tab[2846].append(prix)
            elif prix < 5696 :
                tab[2847].append(prix)
            elif prix < 5698 :
                tab[2848].append(prix)
            elif prix < 5700 :
                tab[2849].append(prix)
            elif prix < 5702 :
                tab[2850].append(prix)
            elif prix < 5704 :
                tab[2851].append(prix)
            elif prix < 5706 :
                tab[2852].append(prix)
            elif prix < 5708 :
                tab[2853].append(prix)
            elif prix < 5710 :
                tab[2854].append(prix)
            elif prix < 5712 :
                tab[2855].append(prix)
            elif prix < 5714 :
                tab[2856].append(prix)
            elif prix < 5716 :
                tab[2857].append(prix)
            elif prix < 5718 :
                tab[2858].append(prix)
            elif prix < 5720 :
                tab[2859].append(prix)
            elif prix < 5722 :
                tab[2860].append(prix)
            elif prix < 5724 :
                tab[2861].append(prix)
            elif prix < 5726 :
                tab[2862].append(prix)
            elif prix < 5728 :
                tab[2863].append(prix)
            elif prix < 5730 :
                tab[2864].append(prix)
            elif prix < 5732 :
                tab[2865].append(prix)
            elif prix < 5734 :
                tab[2866].append(prix)
            elif prix < 5736 :
                tab[2867].append(prix)
            elif prix < 5738 :
                tab[2868].append(prix)
            elif prix < 5740 :
                tab[2869].append(prix)
            elif prix < 5742 :
                tab[2870].append(prix)
            elif prix < 5744 :
                tab[2871].append(prix)
            elif prix < 5746 :
                tab[2872].append(prix)
            elif prix < 5748 :
                tab[2873].append(prix)
            elif prix < 5750 :
                tab[2874].append(prix)
            elif prix < 5752 :
                tab[2875].append(prix)
            elif prix < 5754 :
                tab[2876].append(prix)
            elif prix < 5756 :
                tab[2877].append(prix)
            elif prix < 5758 :
                tab[2878].append(prix)
            elif prix < 5760 :
                tab[2879].append(prix)
            elif prix < 5762 :
                tab[2880].append(prix)
            elif prix < 5764 :
                tab[2881].append(prix)
            elif prix < 5766 :
                tab[2882].append(prix)
            elif prix < 5768 :
                tab[2883].append(prix)
            elif prix < 5770 :
                tab[2884].append(prix)
            elif prix < 5772 :
                tab[2885].append(prix)
            elif prix < 5774 :
                tab[2886].append(prix)
            elif prix < 5776 :
                tab[2887].append(prix)
            elif prix < 5778 :
                tab[2888].append(prix)
            elif prix < 5780 :
                tab[2889].append(prix)
            elif prix < 5782 :
                tab[2890].append(prix)
            elif prix < 5784 :
                tab[2891].append(prix)
            elif prix < 5786 :
                tab[2892].append(prix)
            elif prix < 5788 :
                tab[2893].append(prix)
            elif prix < 5790 :
                tab[2894].append(prix)
            elif prix < 5792 :
                tab[2895].append(prix)
            elif prix < 5794 :
                tab[2896].append(prix)
            elif prix < 5796 :
                tab[2897].append(prix)
            elif prix < 5798 :
                tab[2898].append(prix)
            elif prix < 5800 :
                tab[2899].append(prix)
            elif prix < 5802 :
                tab[2900].append(prix)
            elif prix < 5804 :
                tab[2901].append(prix)
            elif prix < 5806 :
                tab[2902].append(prix)
            elif prix < 5808 :
                tab[2903].append(prix)
            elif prix < 5810 :
                tab[2904].append(prix)
            elif prix < 5812 :
                tab[2905].append(prix)
            elif prix < 5814 :
                tab[2906].append(prix)
            elif prix < 5816 :
                tab[2907].append(prix)
            elif prix < 5818 :
                tab[2908].append(prix)
            elif prix < 5820 :
                tab[2909].append(prix)
            elif prix < 5822 :
                tab[2910].append(prix)
            elif prix < 5824 :
                tab[2911].append(prix)
            elif prix < 5826 :
                tab[2912].append(prix)
            elif prix < 5828 :
                tab[2913].append(prix)
            elif prix < 5830 :
                tab[2914].append(prix)
            elif prix < 5832 :
                tab[2915].append(prix)
            elif prix < 5834 :
                tab[2916].append(prix)
            elif prix < 5836 :
                tab[2917].append(prix)
            elif prix < 5838 :
                tab[2918].append(prix)
            elif prix < 5840 :
                tab[2919].append(prix)
            elif prix < 5842 :
                tab[2920].append(prix)
            elif prix < 5844 :
                tab[2921].append(prix)
            elif prix < 5846 :
                tab[2922].append(prix)
            elif prix < 5848 :
                tab[2923].append(prix)
            elif prix < 5850 :
                tab[2924].append(prix)
            elif prix < 5852 :
                tab[2925].append(prix)
            elif prix < 5854 :
                tab[2926].append(prix)
            elif prix < 5856 :
                tab[2927].append(prix)
            elif prix < 5858 :
                tab[2928].append(prix)
            elif prix < 5860 :
                tab[2929].append(prix)
            elif prix < 5862 :
                tab[2930].append(prix)
            elif prix < 5864 :
                tab[2931].append(prix)
            elif prix < 5866 :
                tab[2932].append(prix)
            elif prix < 5868 :
                tab[2933].append(prix)
            elif prix < 5870 :
                tab[2934].append(prix)
            elif prix < 5872 :
                tab[2935].append(prix)
            elif prix < 5874 :
                tab[2936].append(prix)
            elif prix < 5876 :
                tab[2937].append(prix)
            elif prix < 5878 :
                tab[2938].append(prix)
            elif prix < 5880 :
                tab[2939].append(prix)
            elif prix < 5882 :
                tab[2940].append(prix)
            elif prix < 5884 :
                tab[2941].append(prix)
            elif prix < 5886 :
                tab[2942].append(prix)
            elif prix < 5888 :
                tab[2943].append(prix)
            elif prix < 5890 :
                tab[2944].append(prix)
            elif prix < 5892 :
                tab[2945].append(prix)
            elif prix < 5894 :
                tab[2946].append(prix)
            elif prix < 5896 :
                tab[2947].append(prix)
            elif prix < 5898 :
                tab[2948].append(prix)
            elif prix < 5900 :
                tab[2949].append(prix)
            elif prix < 5902 :
                tab[2950].append(prix)
            elif prix < 5904 :
                tab[2951].append(prix)
            elif prix < 5906 :
                tab[2952].append(prix)
            elif prix < 5908 :
                tab[2953].append(prix)
            elif prix < 5910 :
                tab[2954].append(prix)
            elif prix < 5912 :
                tab[2955].append(prix)
            elif prix < 5914 :
                tab[2956].append(prix)
            elif prix < 5916 :
                tab[2957].append(prix)
            elif prix < 5918 :
                tab[2958].append(prix)
            elif prix < 5920 :
                tab[2959].append(prix)
            elif prix < 5922 :
                tab[2960].append(prix)
            elif prix < 5924 :
                tab[2961].append(prix)
            elif prix < 5926 :
                tab[2962].append(prix)
            elif prix < 5928 :
                tab[2963].append(prix)
            elif prix < 5930 :
                tab[2964].append(prix)
            elif prix < 5932 :
                tab[2965].append(prix)
            elif prix < 5934 :
                tab[2966].append(prix)
            elif prix < 5936 :
                tab[2967].append(prix)
            elif prix < 5938 :
                tab[2968].append(prix)
            elif prix < 5940 :
                tab[2969].append(prix)
            elif prix < 5942 :
                tab[2970].append(prix)
            elif prix < 5944 :
                tab[2971].append(prix)
            elif prix < 5946 :
                tab[2972].append(prix)
            elif prix < 5948 :
                tab[2973].append(prix)
            elif prix < 5950 :
                tab[2974].append(prix)
            elif prix < 5952 :
                tab[2975].append(prix)
            elif prix < 5954 :
                tab[2976].append(prix)
            elif prix < 5956 :
                tab[2977].append(prix)
            elif prix < 5958 :
                tab[2978].append(prix)
            elif prix < 5960 :
                tab[2979].append(prix)
            elif prix < 5962 :
                tab[2980].append(prix)
            elif prix < 5964 :
                tab[2981].append(prix)
            elif prix < 5966 :
                tab[2982].append(prix)
            elif prix < 5968 :
                tab[2983].append(prix)
            elif prix < 5970 :
                tab[2984].append(prix)
            elif prix < 5972 :
                tab[2985].append(prix)
            elif prix < 5974 :
                tab[2986].append(prix)
            elif prix < 5976 :
                tab[2987].append(prix)
            elif prix < 5978 :
                tab[2988].append(prix)
            elif prix < 5980 :
                tab[2989].append(prix)
            elif prix < 5982 :
                tab[2990].append(prix)
            elif prix < 5984 :
                tab[2991].append(prix)
            elif prix < 5986 :
                tab[2992].append(prix)
            elif prix < 5988 :
                tab[2993].append(prix)
            elif prix < 5990 :
                tab[2994].append(prix)
            elif prix < 5992 :
                tab[2995].append(prix)
            elif prix < 5994 :
                tab[2996].append(prix)
            elif prix < 5996 :
                tab[2997].append(prix)
            elif prix < 5998 :
                tab[2998].append(prix)
            elif prix < 6000 :
                tab[2999].append(prix)
            elif prix < 6002 :
                tab[3000].append(prix)
            elif prix < 6004 :
                tab[3001].append(prix)
            elif prix < 6006 :
                tab[3002].append(prix)
            elif prix < 6008 :
                tab[3003].append(prix)
            elif prix < 6010 :
                tab[3004].append(prix)
            elif prix < 6012 :
                tab[3005].append(prix)
            elif prix < 6014 :
                tab[3006].append(prix)
            elif prix < 6016 :
                tab[3007].append(prix)
            elif prix < 6018 :
                tab[3008].append(prix)
            elif prix < 6020 :
                tab[3009].append(prix)
            elif prix < 6022 :
                tab[3010].append(prix)
            elif prix < 6024 :
                tab[3011].append(prix)
            elif prix < 6026 :
                tab[3012].append(prix)
            elif prix < 6028 :
                tab[3013].append(prix)
            elif prix < 6030 :
                tab[3014].append(prix)
            elif prix < 6032 :
                tab[3015].append(prix)
            elif prix < 6034 :
                tab[3016].append(prix)
            elif prix < 6036 :
                tab[3017].append(prix)
            elif prix < 6038 :
                tab[3018].append(prix)
            elif prix < 6040 :
                tab[3019].append(prix)
            elif prix < 6042 :
                tab[3020].append(prix)
            elif prix < 6044 :
                tab[3021].append(prix)
            elif prix < 6046 :
                tab[3022].append(prix)
            elif prix < 6048 :
                tab[3023].append(prix)
            elif prix < 6050 :
                tab[3024].append(prix)
            elif prix < 6052 :
                tab[3025].append(prix)
            elif prix < 6054 :
                tab[3026].append(prix)
            elif prix < 6056 :
                tab[3027].append(prix)
            elif prix < 6058 :
                tab[3028].append(prix)
            elif prix < 6060 :
                tab[3029].append(prix)
            elif prix < 6062 :
                tab[3030].append(prix)
            elif prix < 6064 :
                tab[3031].append(prix)
            elif prix < 6066 :
                tab[3032].append(prix)
            elif prix < 6068 :
                tab[3033].append(prix)
            elif prix < 6070 :
                tab[3034].append(prix)
            elif prix < 6072 :
                tab[3035].append(prix)
            elif prix < 6074 :
                tab[3036].append(prix)
            elif prix < 6076 :
                tab[3037].append(prix)
            elif prix < 6078 :
                tab[3038].append(prix)
            elif prix < 6080 :
                tab[3039].append(prix)
            elif prix < 6082 :
                tab[3040].append(prix)
            elif prix < 6084 :
                tab[3041].append(prix)
            elif prix < 6086 :
                tab[3042].append(prix)
            elif prix < 6088 :
                tab[3043].append(prix)
            elif prix < 6090 :
                tab[3044].append(prix)
            elif prix < 6092 :
                tab[3045].append(prix)
            elif prix < 6094 :
                tab[3046].append(prix)
            elif prix < 6096 :
                tab[3047].append(prix)
            elif prix < 6098 :
                tab[3048].append(prix)
            elif prix < 6100 :
                tab[3049].append(prix)
            elif prix < 6102 :
                tab[3050].append(prix)
            elif prix < 6104 :
                tab[3051].append(prix)
            elif prix < 6106 :
                tab[3052].append(prix)
            elif prix < 6108 :
                tab[3053].append(prix)
            elif prix < 6110 :
                tab[3054].append(prix)
            elif prix < 6112 :
                tab[3055].append(prix)
            elif prix < 6114 :
                tab[3056].append(prix)
            elif prix < 6116 :
                tab[3057].append(prix)
            elif prix < 6118 :
                tab[3058].append(prix)
            elif prix < 6120 :
                tab[3059].append(prix)
            elif prix < 6122 :
                tab[3060].append(prix)
            elif prix < 6124 :
                tab[3061].append(prix)
            elif prix < 6126 :
                tab[3062].append(prix)
            elif prix < 6128 :
                tab[3063].append(prix)
            elif prix < 6130 :
                tab[3064].append(prix)
            elif prix < 6132 :
                tab[3065].append(prix)
            elif prix < 6134 :
                tab[3066].append(prix)
            elif prix < 6136 :
                tab[3067].append(prix)
            elif prix < 6138 :
                tab[3068].append(prix)
            elif prix < 6140 :
                tab[3069].append(prix)
            elif prix < 6142 :
                tab[3070].append(prix)
            elif prix < 6144 :
                tab[3071].append(prix)
            elif prix < 6146 :
                tab[3072].append(prix)
            elif prix < 6148 :
                tab[3073].append(prix)
            elif prix < 6150 :
                tab[3074].append(prix)
            elif prix < 6152 :
                tab[3075].append(prix)
            elif prix < 6154 :
                tab[3076].append(prix)
            elif prix < 6156 :
                tab[3077].append(prix)
            elif prix < 6158 :
                tab[3078].append(prix)
            elif prix < 6160 :
                tab[3079].append(prix)
            elif prix < 6162 :
                tab[3080].append(prix)
            elif prix < 6164 :
                tab[3081].append(prix)
            elif prix < 6166 :
                tab[3082].append(prix)
            elif prix < 6168 :
                tab[3083].append(prix)
            elif prix < 6170 :
                tab[3084].append(prix)
            elif prix < 6172 :
                tab[3085].append(prix)
            elif prix < 6174 :
                tab[3086].append(prix)
            elif prix < 6176 :
                tab[3087].append(prix)
            elif prix < 6178 :
                tab[3088].append(prix)
            elif prix < 6180 :
                tab[3089].append(prix)
            elif prix < 6182 :
                tab[3090].append(prix)
            elif prix < 6184 :
                tab[3091].append(prix)
            elif prix < 6186 :
                tab[3092].append(prix)
            elif prix < 6188 :
                tab[3093].append(prix)
            elif prix < 6190 :
                tab[3094].append(prix)
            elif prix < 6192 :
                tab[3095].append(prix)
            elif prix < 6194 :
                tab[3096].append(prix)
            elif prix < 6196 :
                tab[3097].append(prix)
            elif prix < 6198 :
                tab[3098].append(prix)
            elif prix < 6200 :
                tab[3099].append(prix)
            elif prix < 6202 :
                tab[3100].append(prix)
            elif prix < 6204 :
                tab[3101].append(prix)
            elif prix < 6206 :
                tab[3102].append(prix)
            elif prix < 6208 :
                tab[3103].append(prix)
            elif prix < 6210 :
                tab[3104].append(prix)
            elif prix < 6212 :
                tab[3105].append(prix)
            elif prix < 6214 :
                tab[3106].append(prix)
            elif prix < 6216 :
                tab[3107].append(prix)
            elif prix < 6218 :
                tab[3108].append(prix)
            elif prix < 6220 :
                tab[3109].append(prix)
            elif prix < 6222 :
                tab[3110].append(prix)
            elif prix < 6224 :
                tab[3111].append(prix)
            elif prix < 6226 :
                tab[3112].append(prix)
            elif prix < 6228 :
                tab[3113].append(prix)
            elif prix < 6230 :
                tab[3114].append(prix)
            elif prix < 6232 :
                tab[3115].append(prix)
            elif prix < 6234 :
                tab[3116].append(prix)
            elif prix < 6236 :
                tab[3117].append(prix)
            elif prix < 6238 :
                tab[3118].append(prix)
            elif prix < 6240 :
                tab[3119].append(prix)
            elif prix < 6242 :
                tab[3120].append(prix)
            elif prix < 6244 :
                tab[3121].append(prix)
            elif prix < 6246 :
                tab[3122].append(prix)
            elif prix < 6248 :
                tab[3123].append(prix)
            elif prix < 6250 :
                tab[3124].append(prix)
            elif prix < 6252 :
                tab[3125].append(prix)
            elif prix < 6254 :
                tab[3126].append(prix)
            elif prix < 6256 :
                tab[3127].append(prix)
            elif prix < 6258 :
                tab[3128].append(prix)
            elif prix < 6260 :
                tab[3129].append(prix)
            elif prix < 6262 :
                tab[3130].append(prix)
            elif prix < 6264 :
                tab[3131].append(prix)
            elif prix < 6266 :
                tab[3132].append(prix)
            elif prix < 6268 :
                tab[3133].append(prix)
            elif prix < 6270 :
                tab[3134].append(prix)
            elif prix < 6272 :
                tab[3135].append(prix)
            elif prix < 6274 :
                tab[3136].append(prix)
            elif prix < 6276 :
                tab[3137].append(prix)
            elif prix < 6278 :
                tab[3138].append(prix)
            elif prix < 6280 :
                tab[3139].append(prix)
            elif prix < 6282 :
                tab[3140].append(prix)
            elif prix < 6284 :
                tab[3141].append(prix)
            elif prix < 6286 :
                tab[3142].append(prix)
            elif prix < 6288 :
                tab[3143].append(prix)
            elif prix < 6290 :
                tab[3144].append(prix)
            elif prix < 6292 :
                tab[3145].append(prix)
            elif prix < 6294 :
                tab[3146].append(prix)
            elif prix < 6296 :
                tab[3147].append(prix)
            elif prix < 6298 :
                tab[3148].append(prix)
            elif prix < 6300 :
                tab[3149].append(prix)
            elif prix < 6302 :
                tab[3150].append(prix)
            elif prix < 6304 :
                tab[3151].append(prix)
            elif prix < 6306 :
                tab[3152].append(prix)
            elif prix < 6308 :
                tab[3153].append(prix)
            elif prix < 6310 :
                tab[3154].append(prix)
            elif prix < 6312 :
                tab[3155].append(prix)
            elif prix < 6314 :
                tab[3156].append(prix)
            elif prix < 6316 :
                tab[3157].append(prix)
            elif prix < 6318 :
                tab[3158].append(prix)
            elif prix < 6320 :
                tab[3159].append(prix)
            elif prix < 6322 :
                tab[3160].append(prix)
            elif prix < 6324 :
                tab[3161].append(prix)
            elif prix < 6326 :
                tab[3162].append(prix)
            elif prix < 6328 :
                tab[3163].append(prix)
            elif prix < 6330 :
                tab[3164].append(prix)
            elif prix < 6332 :
                tab[3165].append(prix)
            elif prix < 6334 :
                tab[3166].append(prix)
            elif prix < 6336 :
                tab[3167].append(prix)
            elif prix < 6338 :
                tab[3168].append(prix)
            elif prix < 6340 :
                tab[3169].append(prix)
            elif prix < 6342 :
                tab[3170].append(prix)
            elif prix < 6344 :
                tab[3171].append(prix)
            elif prix < 6346 :
                tab[3172].append(prix)
            elif prix < 6348 :
                tab[3173].append(prix)
            elif prix < 6350 :
                tab[3174].append(prix)
            elif prix < 6352 :
                tab[3175].append(prix)
            elif prix < 6354 :
                tab[3176].append(prix)
            elif prix < 6356 :
                tab[3177].append(prix)
            elif prix < 6358 :
                tab[3178].append(prix)
            elif prix < 6360 :
                tab[3179].append(prix)
            elif prix < 6362 :
                tab[3180].append(prix)
            elif prix < 6364 :
                tab[3181].append(prix)
            elif prix < 6366 :
                tab[3182].append(prix)
            elif prix < 6368 :
                tab[3183].append(prix)
            elif prix < 6370 :
                tab[3184].append(prix)
            elif prix < 6372 :
                tab[3185].append(prix)
            elif prix < 6374 :
                tab[3186].append(prix)
            elif prix < 6376 :
                tab[3187].append(prix)
            elif prix < 6378 :
                tab[3188].append(prix)
            elif prix < 6380 :
                tab[3189].append(prix)
            elif prix < 6382 :
                tab[3190].append(prix)
            elif prix < 6384 :
                tab[3191].append(prix)
            elif prix < 6386 :
                tab[3192].append(prix)
            elif prix < 6388 :
                tab[3193].append(prix)
            elif prix < 6390 :
                tab[3194].append(prix)
            elif prix < 6392 :
                tab[3195].append(prix)
            elif prix < 6394 :
                tab[3196].append(prix)
            elif prix < 6396 :
                tab[3197].append(prix)
            elif prix < 6398 :
                tab[3198].append(prix)
            elif prix < 6400 :
                tab[3199].append(prix)
            elif prix < 6402 :
                tab[3200].append(prix)
            elif prix < 6404 :
                tab[3201].append(prix)
            elif prix < 6406 :
                tab[3202].append(prix)
            elif prix < 6408 :
                tab[3203].append(prix)
            elif prix < 6410 :
                tab[3204].append(prix)
            elif prix < 6412 :
                tab[3205].append(prix)
            elif prix < 6414 :
                tab[3206].append(prix)
            elif prix < 6416 :
                tab[3207].append(prix)
            elif prix < 6418 :
                tab[3208].append(prix)
            elif prix < 6420 :
                tab[3209].append(prix)
            elif prix < 6422 :
                tab[3210].append(prix)
            elif prix < 6424 :
                tab[3211].append(prix)
            elif prix < 6426 :
                tab[3212].append(prix)
            elif prix < 6428 :
                tab[3213].append(prix)
            elif prix < 6430 :
                tab[3214].append(prix)
            elif prix < 6432 :
                tab[3215].append(prix)
            elif prix < 6434 :
                tab[3216].append(prix)
            elif prix < 6436 :
                tab[3217].append(prix)
            elif prix < 6438 :
                tab[3218].append(prix)
            elif prix < 6440 :
                tab[3219].append(prix)
            elif prix < 6442 :
                tab[3220].append(prix)
            elif prix < 6444 :
                tab[3221].append(prix)
            elif prix < 6446 :
                tab[3222].append(prix)
            elif prix < 6448 :
                tab[3223].append(prix)
            elif prix < 6450 :
                tab[3224].append(prix)
            elif prix < 6452 :
                tab[3225].append(prix)
            elif prix < 6454 :
                tab[3226].append(prix)
            elif prix < 6456 :
                tab[3227].append(prix)
            elif prix < 6458 :
                tab[3228].append(prix)
            elif prix < 6460 :
                tab[3229].append(prix)
            elif prix < 6462 :
                tab[3230].append(prix)
            elif prix < 6464 :
                tab[3231].append(prix)
            elif prix < 6466 :
                tab[3232].append(prix)
            elif prix < 6468 :
                tab[3233].append(prix)
            elif prix < 6470 :
                tab[3234].append(prix)
            elif prix < 6472 :
                tab[3235].append(prix)
            elif prix < 6474 :
                tab[3236].append(prix)
            elif prix < 6476 :
                tab[3237].append(prix)
            elif prix < 6478 :
                tab[3238].append(prix)
            elif prix < 6480 :
                tab[3239].append(prix)
            elif prix < 6482 :
                tab[3240].append(prix)
            elif prix < 6484 :
                tab[3241].append(prix)
            elif prix < 6486 :
                tab[3242].append(prix)
            elif prix < 6488 :
                tab[3243].append(prix)
            elif prix < 6490 :
                tab[3244].append(prix)
            elif prix < 6492 :
                tab[3245].append(prix)
            elif prix < 6494 :
                tab[3246].append(prix)
            elif prix < 6496 :
                tab[3247].append(prix)
            elif prix < 6498 :
                tab[3248].append(prix)
            elif prix < 6500 :
                tab[3249].append(prix)
            elif prix < 6502 :
                tab[3250].append(prix)
            elif prix < 6504 :
                tab[3251].append(prix)
            elif prix < 6506 :
                tab[3252].append(prix)
            elif prix < 6508 :
                tab[3253].append(prix)
            elif prix < 6510 :
                tab[3254].append(prix)
            elif prix < 6512 :
                tab[3255].append(prix)
            elif prix < 6514 :
                tab[3256].append(prix)
            elif prix < 6516 :
                tab[3257].append(prix)
            elif prix < 6518 :
                tab[3258].append(prix)
            elif prix < 6520 :
                tab[3259].append(prix)
            elif prix < 6522 :
                tab[3260].append(prix)
            elif prix < 6524 :
                tab[3261].append(prix)
            elif prix < 6526 :
                tab[3262].append(prix)
            elif prix < 6528 :
                tab[3263].append(prix)
            elif prix < 6530 :
                tab[3264].append(prix)
            elif prix < 6532 :
                tab[3265].append(prix)
            elif prix < 6534 :
                tab[3266].append(prix)
            elif prix < 6536 :
                tab[3267].append(prix)
            elif prix < 6538 :
                tab[3268].append(prix)
            elif prix < 6540 :
                tab[3269].append(prix)
            elif prix < 6542 :
                tab[3270].append(prix)
            elif prix < 6544 :
                tab[3271].append(prix)
            elif prix < 6546 :
                tab[3272].append(prix)
            elif prix < 6548 :
                tab[3273].append(prix)
            elif prix < 6550 :
                tab[3274].append(prix)
            elif prix < 6552 :
                tab[3275].append(prix)
            elif prix < 6554 :
                tab[3276].append(prix)
            elif prix < 6556 :
                tab[3277].append(prix)
            elif prix < 6558 :
                tab[3278].append(prix)
            elif prix < 6560 :
                tab[3279].append(prix)
            elif prix < 6562 :
                tab[3280].append(prix)
            elif prix < 6564 :
                tab[3281].append(prix)
            elif prix < 6566 :
                tab[3282].append(prix)
            elif prix < 6568 :
                tab[3283].append(prix)
            elif prix < 6570 :
                tab[3284].append(prix)
            elif prix < 6572 :
                tab[3285].append(prix)
            elif prix < 6574 :
                tab[3286].append(prix)
            elif prix < 6576 :
                tab[3287].append(prix)
            elif prix < 6578 :
                tab[3288].append(prix)
            elif prix < 6580 :
                tab[3289].append(prix)
            elif prix < 6582 :
                tab[3290].append(prix)
            elif prix < 6584 :
                tab[3291].append(prix)
            elif prix < 6586 :
                tab[3292].append(prix)
            elif prix < 6588 :
                tab[3293].append(prix)
            elif prix < 6590 :
                tab[3294].append(prix)
            elif prix < 6592 :
                tab[3295].append(prix)
            elif prix < 6594 :
                tab[3296].append(prix)
            elif prix < 6596 :
                tab[3297].append(prix)
            elif prix < 6598 :
                tab[3298].append(prix)
            elif prix < 6600 :
                tab[3299].append(prix)
            elif prix < 6602 :
                tab[3300].append(prix)
            elif prix < 6604 :
                tab[3301].append(prix)
            elif prix < 6606 :
                tab[3302].append(prix)
            elif prix < 6608 :
                tab[3303].append(prix)
            elif prix < 6610 :
                tab[3304].append(prix)
            elif prix < 6612 :
                tab[3305].append(prix)
            elif prix < 6614 :
                tab[3306].append(prix)
            elif prix < 6616 :
                tab[3307].append(prix)
            elif prix < 6618 :
                tab[3308].append(prix)
            elif prix < 6620 :
                tab[3309].append(prix)
            elif prix < 6622 :
                tab[3310].append(prix)
            elif prix < 6624 :
                tab[3311].append(prix)
            elif prix < 6626 :
                tab[3312].append(prix)
            elif prix < 6628 :
                tab[3313].append(prix)
            elif prix < 6630 :
                tab[3314].append(prix)
            elif prix < 6632 :
                tab[3315].append(prix)
            elif prix < 6634 :
                tab[3316].append(prix)
            elif prix < 6636 :
                tab[3317].append(prix)
            elif prix < 6638 :
                tab[3318].append(prix)
            elif prix < 6640 :
                tab[3319].append(prix)
            elif prix < 6642 :
                tab[3320].append(prix)
            elif prix < 6644 :
                tab[3321].append(prix)
            elif prix < 6646 :
                tab[3322].append(prix)
            elif prix < 6648 :
                tab[3323].append(prix)
            elif prix < 6650 :
                tab[3324].append(prix)
            elif prix < 6652 :
                tab[3325].append(prix)
            elif prix < 6654 :
                tab[3326].append(prix)
            elif prix < 6656 :
                tab[3327].append(prix)
            elif prix < 6658 :
                tab[3328].append(prix)
            elif prix < 6660 :
                tab[3329].append(prix)
            elif prix < 6662 :
                tab[3330].append(prix)
            elif prix < 6664 :
                tab[3331].append(prix)
            elif prix < 6666 :
                tab[3332].append(prix)
            elif prix < 6668 :
                tab[3333].append(prix)
            elif prix < 6670 :
                tab[3334].append(prix)
            elif prix < 6672 :
                tab[3335].append(prix)
            elif prix < 6674 :
                tab[3336].append(prix)
            elif prix < 6676 :
                tab[3337].append(prix)
            elif prix < 6678 :
                tab[3338].append(prix)
            elif prix < 6680 :
                tab[3339].append(prix)
            elif prix < 6682 :
                tab[3340].append(prix)
            elif prix < 6684 :
                tab[3341].append(prix)
            elif prix < 6686 :
                tab[3342].append(prix)
            elif prix < 6688 :
                tab[3343].append(prix)
            elif prix < 6690 :
                tab[3344].append(prix)
            elif prix < 6692 :
                tab[3345].append(prix)
            elif prix < 6694 :
                tab[3346].append(prix)
            elif prix < 6696 :
                tab[3347].append(prix)
            elif prix < 6698 :
                tab[3348].append(prix)
            elif prix < 6700 :
                tab[3349].append(prix)
            elif prix < 6702 :
                tab[3350].append(prix)
            elif prix < 6704 :
                tab[3351].append(prix)
            elif prix < 6706 :
                tab[3352].append(prix)
            elif prix < 6708 :
                tab[3353].append(prix)
            elif prix < 6710 :
                tab[3354].append(prix)
            elif prix < 6712 :
                tab[3355].append(prix)
            elif prix < 6714 :
                tab[3356].append(prix)
            elif prix < 6716 :
                tab[3357].append(prix)
            elif prix < 6718 :
                tab[3358].append(prix)
            elif prix < 6720 :
                tab[3359].append(prix)
            elif prix < 6722 :
                tab[3360].append(prix)
            elif prix < 6724 :
                tab[3361].append(prix)
            elif prix < 6726 :
                tab[3362].append(prix)
            elif prix < 6728 :
                tab[3363].append(prix)
            elif prix < 6730 :
                tab[3364].append(prix)
            elif prix < 6732 :
                tab[3365].append(prix)
            elif prix < 6734 :
                tab[3366].append(prix)
            elif prix < 6736 :
                tab[3367].append(prix)
            elif prix < 6738 :
                tab[3368].append(prix)
            elif prix < 6740 :
                tab[3369].append(prix)
            elif prix < 6742 :
                tab[3370].append(prix)
            elif prix < 6744 :
                tab[3371].append(prix)
            elif prix < 6746 :
                tab[3372].append(prix)
            elif prix < 6748 :
                tab[3373].append(prix)
            elif prix < 6750 :
                tab[3374].append(prix)
            elif prix < 6752 :
                tab[3375].append(prix)
            elif prix < 6754 :
                tab[3376].append(prix)
            elif prix < 6756 :
                tab[3377].append(prix)
            elif prix < 6758 :
                tab[3378].append(prix)
            elif prix < 6760 :
                tab[3379].append(prix)
            elif prix < 6762 :
                tab[3380].append(prix)
            elif prix < 6764 :
                tab[3381].append(prix)
            elif prix < 6766 :
                tab[3382].append(prix)
            elif prix < 6768 :
                tab[3383].append(prix)
            elif prix < 6770 :
                tab[3384].append(prix)
            elif prix < 6772 :
                tab[3385].append(prix)
            elif prix < 6774 :
                tab[3386].append(prix)
            elif prix < 6776 :
                tab[3387].append(prix)
            elif prix < 6778 :
                tab[3388].append(prix)
            elif prix < 6780 :
                tab[3389].append(prix)
            elif prix < 6782 :
                tab[3390].append(prix)
            elif prix < 6784 :
                tab[3391].append(prix)
            elif prix < 6786 :
                tab[3392].append(prix)
            elif prix < 6788 :
                tab[3393].append(prix)
            elif prix < 6790 :
                tab[3394].append(prix)
            elif prix < 6792 :
                tab[3395].append(prix)
            elif prix < 6794 :
                tab[3396].append(prix)
            elif prix < 6796 :
                tab[3397].append(prix)
            elif prix < 6798 :
                tab[3398].append(prix)
            elif prix < 6800 :
                tab[3399].append(prix)
            elif prix < 6802 :
                tab[3400].append(prix)
            elif prix < 6804 :
                tab[3401].append(prix)
            elif prix < 6806 :
                tab[3402].append(prix)
            elif prix < 6808 :
                tab[3403].append(prix)
            elif prix < 6810 :
                tab[3404].append(prix)
            elif prix < 6812 :
                tab[3405].append(prix)
            elif prix < 6814 :
                tab[3406].append(prix)
            elif prix < 6816 :
                tab[3407].append(prix)
            elif prix < 6818 :
                tab[3408].append(prix)
            elif prix < 6820 :
                tab[3409].append(prix)
            elif prix < 6822 :
                tab[3410].append(prix)
            elif prix < 6824 :
                tab[3411].append(prix)
            elif prix < 6826 :
                tab[3412].append(prix)
            elif prix < 6828 :
                tab[3413].append(prix)
            elif prix < 6830 :
                tab[3414].append(prix)
            elif prix < 6832 :
                tab[3415].append(prix)
            elif prix < 6834 :
                tab[3416].append(prix)
            elif prix < 6836 :
                tab[3417].append(prix)
            elif prix < 6838 :
                tab[3418].append(prix)
            elif prix < 6840 :
                tab[3419].append(prix)
            elif prix < 6842 :
                tab[3420].append(prix)
            elif prix < 6844 :
                tab[3421].append(prix)
            elif prix < 6846 :
                tab[3422].append(prix)
            elif prix < 6848 :
                tab[3423].append(prix)
            elif prix < 6850 :
                tab[3424].append(prix)
            elif prix < 6852 :
                tab[3425].append(prix)
            elif prix < 6854 :
                tab[3426].append(prix)
            elif prix < 6856 :
                tab[3427].append(prix)
            elif prix < 6858 :
                tab[3428].append(prix)
            elif prix < 6860 :
                tab[3429].append(prix)
            elif prix < 6862 :
                tab[3430].append(prix)
            elif prix < 6864 :
                tab[3431].append(prix)
            elif prix < 6866 :
                tab[3432].append(prix)
            elif prix < 6868 :
                tab[3433].append(prix)
            elif prix < 6870 :
                tab[3434].append(prix)
            elif prix < 6872 :
                tab[3435].append(prix)
            elif prix < 6874 :
                tab[3436].append(prix)
            elif prix < 6876 :
                tab[3437].append(prix)
            elif prix < 6878 :
                tab[3438].append(prix)
            elif prix < 6880 :
                tab[3439].append(prix)
            elif prix < 6882 :
                tab[3440].append(prix)
            elif prix < 6884 :
                tab[3441].append(prix)
            elif prix < 6886 :
                tab[3442].append(prix)
            elif prix < 6888 :
                tab[3443].append(prix)
            elif prix < 6890 :
                tab[3444].append(prix)
            elif prix < 6892 :
                tab[3445].append(prix)
            elif prix < 6894 :
                tab[3446].append(prix)
            elif prix < 6896 :
                tab[3447].append(prix)
            elif prix < 6898 :
                tab[3448].append(prix)
            elif prix < 6900 :
                tab[3449].append(prix)
            elif prix < 6902 :
                tab[3450].append(prix)
            elif prix < 6904 :
                tab[3451].append(prix)
            elif prix < 6906 :
                tab[3452].append(prix)
            elif prix < 6908 :
                tab[3453].append(prix)
            elif prix < 6910 :
                tab[3454].append(prix)
            elif prix < 6912 :
                tab[3455].append(prix)
            elif prix < 6914 :
                tab[3456].append(prix)
            elif prix < 6916 :
                tab[3457].append(prix)
            elif prix < 6918 :
                tab[3458].append(prix)
            elif prix < 6920 :
                tab[3459].append(prix)
            elif prix < 6922 :
                tab[3460].append(prix)
            elif prix < 6924 :
                tab[3461].append(prix)
            elif prix < 6926 :
                tab[3462].append(prix)
            elif prix < 6928 :
                tab[3463].append(prix)
            elif prix < 6930 :
                tab[3464].append(prix)
            elif prix < 6932 :
                tab[3465].append(prix)
            elif prix < 6934 :
                tab[3466].append(prix)
            elif prix < 6936 :
                tab[3467].append(prix)
            elif prix < 6938 :
                tab[3468].append(prix)
            elif prix < 6940 :
                tab[3469].append(prix)
            elif prix < 6942 :
                tab[3470].append(prix)
            elif prix < 6944 :
                tab[3471].append(prix)
            elif prix < 6946 :
                tab[3472].append(prix)
            elif prix < 6948 :
                tab[3473].append(prix)
            elif prix < 6950 :
                tab[3474].append(prix)
            elif prix < 6952 :
                tab[3475].append(prix)
            elif prix < 6954 :
                tab[3476].append(prix)
            elif prix < 6956 :
                tab[3477].append(prix)
            elif prix < 6958 :
                tab[3478].append(prix)
            elif prix < 6960 :
                tab[3479].append(prix)
            elif prix < 6962 :
                tab[3480].append(prix)
            elif prix < 6964 :
                tab[3481].append(prix)
            elif prix < 6966 :
                tab[3482].append(prix)
            elif prix < 6968 :
                tab[3483].append(prix)
            elif prix < 6970 :
                tab[3484].append(prix)
            elif prix < 6972 :
                tab[3485].append(prix)
            elif prix < 6974 :
                tab[3486].append(prix)
            elif prix < 6976 :
                tab[3487].append(prix)
            elif prix < 6978 :
                tab[3488].append(prix)
            elif prix < 6980 :
                tab[3489].append(prix)
            elif prix < 6982 :
                tab[3490].append(prix)
            elif prix < 6984 :
                tab[3491].append(prix)
            elif prix < 6986 :
                tab[3492].append(prix)
            elif prix < 6988 :
                tab[3493].append(prix)
            elif prix < 6990 :
                tab[3494].append(prix)
            elif prix < 6992 :
                tab[3495].append(prix)
            elif prix < 6994 :
                tab[3496].append(prix)
            elif prix < 6996 :
                tab[3497].append(prix)
            elif prix < 6998 :
                tab[3498].append(prix)
            elif prix < 7000 :
                tab[3499].append(prix)
            elif prix < 7002 :
                tab[3500].append(prix)
            elif prix < 7004 :
                tab[3501].append(prix)
            elif prix < 7006 :
                tab[3502].append(prix)
            elif prix < 7008 :
                tab[3503].append(prix)
            elif prix < 7010 :
                tab[3504].append(prix)
            elif prix < 7012 :
                tab[3505].append(prix)
            elif prix < 7014 :
                tab[3506].append(prix)
            elif prix < 7016 :
                tab[3507].append(prix)
            elif prix < 7018 :
                tab[3508].append(prix)
            elif prix < 7020 :
                tab[3509].append(prix)
            elif prix < 7022 :
                tab[3510].append(prix)
            elif prix < 7024 :
                tab[3511].append(prix)
            elif prix < 7026 :
                tab[3512].append(prix)
            elif prix < 7028 :
                tab[3513].append(prix)
            elif prix < 7030 :
                tab[3514].append(prix)
            elif prix < 7032 :
                tab[3515].append(prix)
            elif prix < 7034 :
                tab[3516].append(prix)
            elif prix < 7036 :
                tab[3517].append(prix)
            elif prix < 7038 :
                tab[3518].append(prix)
            elif prix < 7040 :
                tab[3519].append(prix)
            elif prix < 7042 :
                tab[3520].append(prix)
            elif prix < 7044 :
                tab[3521].append(prix)
            elif prix < 7046 :
                tab[3522].append(prix)
            elif prix < 7048 :
                tab[3523].append(prix)
            elif prix < 7050 :
                tab[3524].append(prix)
            elif prix < 7052 :
                tab[3525].append(prix)
            elif prix < 7054 :
                tab[3526].append(prix)
            elif prix < 7056 :
                tab[3527].append(prix)
            elif prix < 7058 :
                tab[3528].append(prix)
            elif prix < 7060 :
                tab[3529].append(prix)
            elif prix < 7062 :
                tab[3530].append(prix)
            elif prix < 7064 :
                tab[3531].append(prix)
            elif prix < 7066 :
                tab[3532].append(prix)
            elif prix < 7068 :
                tab[3533].append(prix)
            elif prix < 7070 :
                tab[3534].append(prix)
            elif prix < 7072 :
                tab[3535].append(prix)
            elif prix < 7074 :
                tab[3536].append(prix)
            elif prix < 7076 :
                tab[3537].append(prix)
            elif prix < 7078 :
                tab[3538].append(prix)
            elif prix < 7080 :
                tab[3539].append(prix)
            elif prix < 7082 :
                tab[3540].append(prix)
            elif prix < 7084 :
                tab[3541].append(prix)
            elif prix < 7086 :
                tab[3542].append(prix)
            elif prix < 7088 :
                tab[3543].append(prix)
            elif prix < 7090 :
                tab[3544].append(prix)
            elif prix < 7092 :
                tab[3545].append(prix)
            elif prix < 7094 :
                tab[3546].append(prix)
            elif prix < 7096 :
                tab[3547].append(prix)
            elif prix < 7098 :
                tab[3548].append(prix)
            elif prix < 7100 :
                tab[3549].append(prix)
            elif prix < 7102 :
                tab[3550].append(prix)
            elif prix < 7104 :
                tab[3551].append(prix)
            elif prix < 7106 :
                tab[3552].append(prix)
            elif prix < 7108 :
                tab[3553].append(prix)
            elif prix < 7110 :
                tab[3554].append(prix)
            elif prix < 7112 :
                tab[3555].append(prix)
            elif prix < 7114 :
                tab[3556].append(prix)
            elif prix < 7116 :
                tab[3557].append(prix)
            elif prix < 7118 :
                tab[3558].append(prix)
            elif prix < 7120 :
                tab[3559].append(prix)
            elif prix < 7122 :
                tab[3560].append(prix)
            elif prix < 7124 :
                tab[3561].append(prix)
            elif prix < 7126 :
                tab[3562].append(prix)
            elif prix < 7128 :
                tab[3563].append(prix)
            elif prix < 7130 :
                tab[3564].append(prix)
            elif prix < 7132 :
                tab[3565].append(prix)
            elif prix < 7134 :
                tab[3566].append(prix)
            elif prix < 7136 :
                tab[3567].append(prix)
            elif prix < 7138 :
                tab[3568].append(prix)
            elif prix < 7140 :
                tab[3569].append(prix)
            elif prix < 7142 :
                tab[3570].append(prix)
            elif prix < 7144 :
                tab[3571].append(prix)
            elif prix < 7146 :
                tab[3572].append(prix)
            elif prix < 7148 :
                tab[3573].append(prix)
            elif prix < 7150 :
                tab[3574].append(prix)
            elif prix < 7152 :
                tab[3575].append(prix)
            elif prix < 7154 :
                tab[3576].append(prix)
            elif prix < 7156 :
                tab[3577].append(prix)
            elif prix < 7158 :
                tab[3578].append(prix)
            elif prix < 7160 :
                tab[3579].append(prix)
            elif prix < 7162 :
                tab[3580].append(prix)
            elif prix < 7164 :
                tab[3581].append(prix)
            elif prix < 7166 :
                tab[3582].append(prix)
            elif prix < 7168 :
                tab[3583].append(prix)
            elif prix < 7170 :
                tab[3584].append(prix)
            elif prix < 7172 :
                tab[3585].append(prix)
            elif prix < 7174 :
                tab[3586].append(prix)
            elif prix < 7176 :
                tab[3587].append(prix)
            elif prix < 7178 :
                tab[3588].append(prix)
            elif prix < 7180 :
                tab[3589].append(prix)
            elif prix < 7182 :
                tab[3590].append(prix)
            elif prix < 7184 :
                tab[3591].append(prix)
            elif prix < 7186 :
                tab[3592].append(prix)
            elif prix < 7188 :
                tab[3593].append(prix)
            elif prix < 7190 :
                tab[3594].append(prix)
            elif prix < 7192 :
                tab[3595].append(prix)
            elif prix < 7194 :
                tab[3596].append(prix)
            elif prix < 7196 :
                tab[3597].append(prix)
            elif prix < 7198 :
                tab[3598].append(prix)
            elif prix < 7200 :
                tab[3599].append(prix)
            elif prix < 7202 :
                tab[3600].append(prix)
            elif prix < 7204 :
                tab[3601].append(prix)
            elif prix < 7206 :
                tab[3602].append(prix)
            elif prix < 7208 :
                tab[3603].append(prix)
            elif prix < 7210 :
                tab[3604].append(prix)
            elif prix < 7212 :
                tab[3605].append(prix)
            elif prix < 7214 :
                tab[3606].append(prix)
            elif prix < 7216 :
                tab[3607].append(prix)
            elif prix < 7218 :
                tab[3608].append(prix)
            elif prix < 7220 :
                tab[3609].append(prix)
            elif prix < 7222 :
                tab[3610].append(prix)
            elif prix < 7224 :
                tab[3611].append(prix)
            elif prix < 7226 :
                tab[3612].append(prix)
            elif prix < 7228 :
                tab[3613].append(prix)
            elif prix < 7230 :
                tab[3614].append(prix)
            elif prix < 7232 :
                tab[3615].append(prix)
            elif prix < 7234 :
                tab[3616].append(prix)
            elif prix < 7236 :
                tab[3617].append(prix)
            elif prix < 7238 :
                tab[3618].append(prix)
            elif prix < 7240 :
                tab[3619].append(prix)
            elif prix < 7242 :
                tab[3620].append(prix)
            elif prix < 7244 :
                tab[3621].append(prix)
            elif prix < 7246 :
                tab[3622].append(prix)
            elif prix < 7248 :
                tab[3623].append(prix)
            elif prix < 7250 :
                tab[3624].append(prix)
            elif prix < 7252 :
                tab[3625].append(prix)
            elif prix < 7254 :
                tab[3626].append(prix)
            elif prix < 7256 :
                tab[3627].append(prix)
            elif prix < 7258 :
                tab[3628].append(prix)
            elif prix < 7260 :
                tab[3629].append(prix)
            elif prix < 7262 :
                tab[3630].append(prix)
            elif prix < 7264 :
                tab[3631].append(prix)
            elif prix < 7266 :
                tab[3632].append(prix)
            elif prix < 7268 :
                tab[3633].append(prix)
            elif prix < 7270 :
                tab[3634].append(prix)
            elif prix < 7272 :
                tab[3635].append(prix)
            elif prix < 7274 :
                tab[3636].append(prix)
            elif prix < 7276 :
                tab[3637].append(prix)
            elif prix < 7278 :
                tab[3638].append(prix)
            elif prix < 7280 :
                tab[3639].append(prix)
            elif prix < 7282 :
                tab[3640].append(prix)
            elif prix < 7284 :
                tab[3641].append(prix)
            elif prix < 7286 :
                tab[3642].append(prix)
            elif prix < 7288 :
                tab[3643].append(prix)
            elif prix < 7290 :
                tab[3644].append(prix)
            elif prix < 7292 :
                tab[3645].append(prix)
            elif prix < 7294 :
                tab[3646].append(prix)
            elif prix < 7296 :
                tab[3647].append(prix)
            elif prix < 7298 :
                tab[3648].append(prix)
            elif prix < 7300 :
                tab[3649].append(prix)
            elif prix < 7302 :
                tab[3650].append(prix)
            elif prix < 7304 :
                tab[3651].append(prix)
            elif prix < 7306 :
                tab[3652].append(prix)
            elif prix < 7308 :
                tab[3653].append(prix)
            elif prix < 7310 :
                tab[3654].append(prix)
            elif prix < 7312 :
                tab[3655].append(prix)
            elif prix < 7314 :
                tab[3656].append(prix)
            elif prix < 7316 :
                tab[3657].append(prix)
            elif prix < 7318 :
                tab[3658].append(prix)
            elif prix < 7320 :
                tab[3659].append(prix)
            elif prix < 7322 :
                tab[3660].append(prix)
            elif prix < 7324 :
                tab[3661].append(prix)
            elif prix < 7326 :
                tab[3662].append(prix)
            elif prix < 7328 :
                tab[3663].append(prix)
            elif prix < 7330 :
                tab[3664].append(prix)
            elif prix < 7332 :
                tab[3665].append(prix)
            elif prix < 7334 :
                tab[3666].append(prix)
            elif prix < 7336 :
                tab[3667].append(prix)
            elif prix < 7338 :
                tab[3668].append(prix)
            elif prix < 7340 :
                tab[3669].append(prix)
            elif prix < 7342 :
                tab[3670].append(prix)
            elif prix < 7344 :
                tab[3671].append(prix)
            elif prix < 7346 :
                tab[3672].append(prix)
            elif prix < 7348 :
                tab[3673].append(prix)
            elif prix < 7350 :
                tab[3674].append(prix)
            elif prix < 7352 :
                tab[3675].append(prix)
            elif prix < 7354 :
                tab[3676].append(prix)
            elif prix < 7356 :
                tab[3677].append(prix)
            elif prix < 7358 :
                tab[3678].append(prix)
            elif prix < 7360 :
                tab[3679].append(prix)
            elif prix < 7362 :
                tab[3680].append(prix)
            elif prix < 7364 :
                tab[3681].append(prix)
            elif prix < 7366 :
                tab[3682].append(prix)
            elif prix < 7368 :
                tab[3683].append(prix)
            elif prix < 7370 :
                tab[3684].append(prix)
            elif prix < 7372 :
                tab[3685].append(prix)
            elif prix < 7374 :
                tab[3686].append(prix)
            elif prix < 7376 :
                tab[3687].append(prix)
            elif prix < 7378 :
                tab[3688].append(prix)
            elif prix < 7380 :
                tab[3689].append(prix)
            elif prix < 7382 :
                tab[3690].append(prix)
            elif prix < 7384 :
                tab[3691].append(prix)
            elif prix < 7386 :
                tab[3692].append(prix)
            elif prix < 7388 :
                tab[3693].append(prix)
            elif prix < 7390 :
                tab[3694].append(prix)
            elif prix < 7392 :
                tab[3695].append(prix)
            elif prix < 7394 :
                tab[3696].append(prix)
            elif prix < 7396 :
                tab[3697].append(prix)
            elif prix < 7398 :
                tab[3698].append(prix)
            elif prix < 7400 :
                tab[3699].append(prix)
            elif prix < 7402 :
                tab[3700].append(prix)
            elif prix < 7404 :
                tab[3701].append(prix)
            elif prix < 7406 :
                tab[3702].append(prix)
            elif prix < 7408 :
                tab[3703].append(prix)
            elif prix < 7410 :
                tab[3704].append(prix)
            elif prix < 7412 :
                tab[3705].append(prix)
            elif prix < 7414 :
                tab[3706].append(prix)
            elif prix < 7416 :
                tab[3707].append(prix)
            elif prix < 7418 :
                tab[3708].append(prix)
            elif prix < 7420 :
                tab[3709].append(prix)
            elif prix < 7422 :
                tab[3710].append(prix)
            elif prix < 7424 :
                tab[3711].append(prix)
            elif prix < 7426 :
                tab[3712].append(prix)
            elif prix < 7428 :
                tab[3713].append(prix)
            elif prix < 7430 :
                tab[3714].append(prix)
            elif prix < 7432 :
                tab[3715].append(prix)
            elif prix < 7434 :
                tab[3716].append(prix)
            elif prix < 7436 :
                tab[3717].append(prix)
            elif prix < 7438 :
                tab[3718].append(prix)
            elif prix < 7440 :
                tab[3719].append(prix)
            elif prix < 7442 :
                tab[3720].append(prix)
            elif prix < 7444 :
                tab[3721].append(prix)
            elif prix < 7446 :
                tab[3722].append(prix)
            elif prix < 7448 :
                tab[3723].append(prix)
            elif prix < 7450 :
                tab[3724].append(prix)
            elif prix < 7452 :
                tab[3725].append(prix)
            elif prix < 7454 :
                tab[3726].append(prix)
            elif prix < 7456 :
                tab[3727].append(prix)
            elif prix < 7458 :
                tab[3728].append(prix)
            elif prix < 7460 :
                tab[3729].append(prix)
            elif prix < 7462 :
                tab[3730].append(prix)
            elif prix < 7464 :
                tab[3731].append(prix)
            elif prix < 7466 :
                tab[3732].append(prix)
            elif prix < 7468 :
                tab[3733].append(prix)
            elif prix < 7470 :
                tab[3734].append(prix)
            elif prix < 7472 :
                tab[3735].append(prix)
            elif prix < 7474 :
                tab[3736].append(prix)
            elif prix < 7476 :
                tab[3737].append(prix)
            elif prix < 7478 :
                tab[3738].append(prix)
            elif prix < 7480 :
                tab[3739].append(prix)
            elif prix < 7482 :
                tab[3740].append(prix)
            elif prix < 7484 :
                tab[3741].append(prix)
            elif prix < 7486 :
                tab[3742].append(prix)
            elif prix < 7488 :
                tab[3743].append(prix)
            elif prix < 7490 :
                tab[3744].append(prix)
            elif prix < 7492 :
                tab[3745].append(prix)
            elif prix < 7494 :
                tab[3746].append(prix)
            elif prix < 7496 :
                tab[3747].append(prix)
            elif prix < 7498 :
                tab[3748].append(prix)
            elif prix < 7500 :
                tab[3749].append(prix)
            elif prix < 7502 :
                tab[3750].append(prix)
            elif prix < 7504 :
                tab[3751].append(prix)
            elif prix < 7506 :
                tab[3752].append(prix)
            elif prix < 7508 :
                tab[3753].append(prix)
            elif prix < 7510 :
                tab[3754].append(prix)
            elif prix < 7512 :
                tab[3755].append(prix)
            elif prix < 7514 :
                tab[3756].append(prix)
            elif prix < 7516 :
                tab[3757].append(prix)
            elif prix < 7518 :
                tab[3758].append(prix)
            elif prix < 7520 :
                tab[3759].append(prix)
            elif prix < 7522 :
                tab[3760].append(prix)
            elif prix < 7524 :
                tab[3761].append(prix)
            elif prix < 7526 :
                tab[3762].append(prix)
            elif prix < 7528 :
                tab[3763].append(prix)
            elif prix < 7530 :
                tab[3764].append(prix)
            elif prix < 7532 :
                tab[3765].append(prix)
            elif prix < 7534 :
                tab[3766].append(prix)
            elif prix < 7536 :
                tab[3767].append(prix)
            elif prix < 7538 :
                tab[3768].append(prix)
            elif prix < 7540 :
                tab[3769].append(prix)
            elif prix < 7542 :
                tab[3770].append(prix)
            elif prix < 7544 :
                tab[3771].append(prix)
            elif prix < 7546 :
                tab[3772].append(prix)
            elif prix < 7548 :
                tab[3773].append(prix)
            elif prix < 7550 :
                tab[3774].append(prix)
            elif prix < 7552 :
                tab[3775].append(prix)
            elif prix < 7554 :
                tab[3776].append(prix)
            elif prix < 7556 :
                tab[3777].append(prix)
            elif prix < 7558 :
                tab[3778].append(prix)
            elif prix < 7560 :
                tab[3779].append(prix)
            elif prix < 7562 :
                tab[3780].append(prix)
            elif prix < 7564 :
                tab[3781].append(prix)
            elif prix < 7566 :
                tab[3782].append(prix)
            elif prix < 7568 :
                tab[3783].append(prix)
            elif prix < 7570 :
                tab[3784].append(prix)
            elif prix < 7572 :
                tab[3785].append(prix)
            elif prix < 7574 :
                tab[3786].append(prix)
            elif prix < 7576 :
                tab[3787].append(prix)
            elif prix < 7578 :
                tab[3788].append(prix)
            elif prix < 7580 :
                tab[3789].append(prix)
            elif prix < 7582 :
                tab[3790].append(prix)
            elif prix < 7584 :
                tab[3791].append(prix)
            elif prix < 7586 :
                tab[3792].append(prix)
            elif prix < 7588 :
                tab[3793].append(prix)
            elif prix < 7590 :
                tab[3794].append(prix)
            elif prix < 7592 :
                tab[3795].append(prix)
            elif prix < 7594 :
                tab[3796].append(prix)
            elif prix < 7596 :
                tab[3797].append(prix)
            elif prix < 7598 :
                tab[3798].append(prix)
            elif prix < 7600 :
                tab[3799].append(prix)
            elif prix < 7602 :
                tab[3800].append(prix)
            elif prix < 7604 :
                tab[3801].append(prix)
            elif prix < 7606 :
                tab[3802].append(prix)
            elif prix < 7608 :
                tab[3803].append(prix)
            elif prix < 7610 :
                tab[3804].append(prix)
            elif prix < 7612 :
                tab[3805].append(prix)
            elif prix < 7614 :
                tab[3806].append(prix)
            elif prix < 7616 :
                tab[3807].append(prix)
            elif prix < 7618 :
                tab[3808].append(prix)
            elif prix < 7620 :
                tab[3809].append(prix)
            elif prix < 7622 :
                tab[3810].append(prix)
            elif prix < 7624 :
                tab[3811].append(prix)
            elif prix < 7626 :
                tab[3812].append(prix)
            elif prix < 7628 :
                tab[3813].append(prix)
            elif prix < 7630 :
                tab[3814].append(prix)
            elif prix < 7632 :
                tab[3815].append(prix)
            elif prix < 7634 :
                tab[3816].append(prix)
            elif prix < 7636 :
                tab[3817].append(prix)
            elif prix < 7638 :
                tab[3818].append(prix)
            elif prix < 7640 :
                tab[3819].append(prix)
            elif prix < 7642 :
                tab[3820].append(prix)
            elif prix < 7644 :
                tab[3821].append(prix)
            elif prix < 7646 :
                tab[3822].append(prix)
            elif prix < 7648 :
                tab[3823].append(prix)
            elif prix < 7650 :
                tab[3824].append(prix)
            elif prix < 7652 :
                tab[3825].append(prix)
            elif prix < 7654 :
                tab[3826].append(prix)
            elif prix < 7656 :
                tab[3827].append(prix)
            elif prix < 7658 :
                tab[3828].append(prix)
            elif prix < 7660 :
                tab[3829].append(prix)
            elif prix < 7662 :
                tab[3830].append(prix)
            elif prix < 7664 :
                tab[3831].append(prix)
            elif prix < 7666 :
                tab[3832].append(prix)
            elif prix < 7668 :
                tab[3833].append(prix)
            elif prix < 7670 :
                tab[3834].append(prix)
            elif prix < 7672 :
                tab[3835].append(prix)
            elif prix < 7674 :
                tab[3836].append(prix)
            elif prix < 7676 :
                tab[3837].append(prix)
            elif prix < 7678 :
                tab[3838].append(prix)
            elif prix < 7680 :
                tab[3839].append(prix)
            elif prix < 7682 :
                tab[3840].append(prix)
            elif prix < 7684 :
                tab[3841].append(prix)
            elif prix < 7686 :
                tab[3842].append(prix)
            elif prix < 7688 :
                tab[3843].append(prix)
            elif prix < 7690 :
                tab[3844].append(prix)
            elif prix < 7692 :
                tab[3845].append(prix)
            elif prix < 7694 :
                tab[3846].append(prix)
            elif prix < 7696 :
                tab[3847].append(prix)
            elif prix < 7698 :
                tab[3848].append(prix)
            elif prix < 7700 :
                tab[3849].append(prix)
            elif prix < 7702 :
                tab[3850].append(prix)
            elif prix < 7704 :
                tab[3851].append(prix)
            elif prix < 7706 :
                tab[3852].append(prix)
            elif prix < 7708 :
                tab[3853].append(prix)
            elif prix < 7710 :
                tab[3854].append(prix)
            elif prix < 7712 :
                tab[3855].append(prix)
            elif prix < 7714 :
                tab[3856].append(prix)
            elif prix < 7716 :
                tab[3857].append(prix)
            elif prix < 7718 :
                tab[3858].append(prix)
            elif prix < 7720 :
                tab[3859].append(prix)
            elif prix < 7722 :
                tab[3860].append(prix)
            elif prix < 7724 :
                tab[3861].append(prix)
            elif prix < 7726 :
                tab[3862].append(prix)
            elif prix < 7728 :
                tab[3863].append(prix)
            elif prix < 7730 :
                tab[3864].append(prix)
            elif prix < 7732 :
                tab[3865].append(prix)
            elif prix < 7734 :
                tab[3866].append(prix)
            elif prix < 7736 :
                tab[3867].append(prix)
            elif prix < 7738 :
                tab[3868].append(prix)
            elif prix < 7740 :
                tab[3869].append(prix)
            elif prix < 7742 :
                tab[3870].append(prix)
            elif prix < 7744 :
                tab[3871].append(prix)
            elif prix < 7746 :
                tab[3872].append(prix)
            elif prix < 7748 :
                tab[3873].append(prix)
            elif prix < 7750 :
                tab[3874].append(prix)
            elif prix < 7752 :
                tab[3875].append(prix)
            elif prix < 7754 :
                tab[3876].append(prix)
            elif prix < 7756 :
                tab[3877].append(prix)
            elif prix < 7758 :
                tab[3878].append(prix)
            elif prix < 7760 :
                tab[3879].append(prix)
            elif prix < 7762 :
                tab[3880].append(prix)
            elif prix < 7764 :
                tab[3881].append(prix)
            elif prix < 7766 :
                tab[3882].append(prix)
            elif prix < 7768 :
                tab[3883].append(prix)
            elif prix < 7770 :
                tab[3884].append(prix)
            elif prix < 7772 :
                tab[3885].append(prix)
            elif prix < 7774 :
                tab[3886].append(prix)
            elif prix < 7776 :
                tab[3887].append(prix)
            elif prix < 7778 :
                tab[3888].append(prix)
            elif prix < 7780 :
                tab[3889].append(prix)
            elif prix < 7782 :
                tab[3890].append(prix)
            elif prix < 7784 :
                tab[3891].append(prix)
            elif prix < 7786 :
                tab[3892].append(prix)
            elif prix < 7788 :
                tab[3893].append(prix)
            elif prix < 7790 :
                tab[3894].append(prix)
            elif prix < 7792 :
                tab[3895].append(prix)
            elif prix < 7794 :
                tab[3896].append(prix)
            elif prix < 7796 :
                tab[3897].append(prix)
            elif prix < 7798 :
                tab[3898].append(prix)
            elif prix < 7800 :
                tab[3899].append(prix)
            elif prix < 7802 :
                tab[3900].append(prix)
            elif prix < 7804 :
                tab[3901].append(prix)
            elif prix < 7806 :
                tab[3902].append(prix)
            elif prix < 7808 :
                tab[3903].append(prix)
            elif prix < 7810 :
                tab[3904].append(prix)
            elif prix < 7812 :
                tab[3905].append(prix)
            elif prix < 7814 :
                tab[3906].append(prix)
            elif prix < 7816 :
                tab[3907].append(prix)
            elif prix < 7818 :
                tab[3908].append(prix)
            elif prix < 7820 :
                tab[3909].append(prix)
            elif prix < 7822 :
                tab[3910].append(prix)
            elif prix < 7824 :
                tab[3911].append(prix)
            elif prix < 7826 :
                tab[3912].append(prix)
            elif prix < 7828 :
                tab[3913].append(prix)
            elif prix < 7830 :
                tab[3914].append(prix)
            elif prix < 7832 :
                tab[3915].append(prix)
            elif prix < 7834 :
                tab[3916].append(prix)
            elif prix < 7836 :
                tab[3917].append(prix)
            elif prix < 7838 :
                tab[3918].append(prix)
            elif prix < 7840 :
                tab[3919].append(prix)
            elif prix < 7842 :
                tab[3920].append(prix)
            elif prix < 7844 :
                tab[3921].append(prix)
            elif prix < 7846 :
                tab[3922].append(prix)
            elif prix < 7848 :
                tab[3923].append(prix)
            elif prix < 7850 :
                tab[3924].append(prix)
            elif prix < 7852 :
                tab[3925].append(prix)
            elif prix < 7854 :
                tab[3926].append(prix)
            elif prix < 7856 :
                tab[3927].append(prix)
            elif prix < 7858 :
                tab[3928].append(prix)
            elif prix < 7860 :
                tab[3929].append(prix)
            elif prix < 7862 :
                tab[3930].append(prix)
            elif prix < 7864 :
                tab[3931].append(prix)
            elif prix < 7866 :
                tab[3932].append(prix)
            elif prix < 7868 :
                tab[3933].append(prix)
            elif prix < 7870 :
                tab[3934].append(prix)
            elif prix < 7872 :
                tab[3935].append(prix)
            elif prix < 7874 :
                tab[3936].append(prix)
            elif prix < 7876 :
                tab[3937].append(prix)
            elif prix < 7878 :
                tab[3938].append(prix)
            elif prix < 7880 :
                tab[3939].append(prix)
            elif prix < 7882 :
                tab[3940].append(prix)
            elif prix < 7884 :
                tab[3941].append(prix)
            elif prix < 7886 :
                tab[3942].append(prix)
            elif prix < 7888 :
                tab[3943].append(prix)
            elif prix < 7890 :
                tab[3944].append(prix)
            elif prix < 7892 :
                tab[3945].append(prix)
            elif prix < 7894 :
                tab[3946].append(prix)
            elif prix < 7896 :
                tab[3947].append(prix)
            elif prix < 7898 :
                tab[3948].append(prix)
            elif prix < 7900 :
                tab[3949].append(prix)
            elif prix < 7902 :
                tab[3950].append(prix)
            elif prix < 7904 :
                tab[3951].append(prix)
            elif prix < 7906 :
                tab[3952].append(prix)
            elif prix < 7908 :
                tab[3953].append(prix)
            elif prix < 7910 :
                tab[3954].append(prix)
            elif prix < 7912 :
                tab[3955].append(prix)
            elif prix < 7914 :
                tab[3956].append(prix)
            elif prix < 7916 :
                tab[3957].append(prix)
            elif prix < 7918 :
                tab[3958].append(prix)
            elif prix < 7920 :
                tab[3959].append(prix)
            elif prix < 7922 :
                tab[3960].append(prix)
            elif prix < 7924 :
                tab[3961].append(prix)
            elif prix < 7926 :
                tab[3962].append(prix)
            elif prix < 7928 :
                tab[3963].append(prix)
            elif prix < 7930 :
                tab[3964].append(prix)
            elif prix < 7932 :
                tab[3965].append(prix)
            elif prix < 7934 :
                tab[3966].append(prix)
            elif prix < 7936 :
                tab[3967].append(prix)
            elif prix < 7938 :
                tab[3968].append(prix)
            elif prix < 7940 :
                tab[3969].append(prix)
            elif prix < 7942 :
                tab[3970].append(prix)
            elif prix < 7944 :
                tab[3971].append(prix)
            elif prix < 7946 :
                tab[3972].append(prix)
            elif prix < 7948 :
                tab[3973].append(prix)
            elif prix < 7950 :
                tab[3974].append(prix)
            elif prix < 7952 :
                tab[3975].append(prix)
            elif prix < 7954 :
                tab[3976].append(prix)
            elif prix < 7956 :
                tab[3977].append(prix)
            elif prix < 7958 :
                tab[3978].append(prix)
            elif prix < 7960 :
                tab[3979].append(prix)
            elif prix < 7962 :
                tab[3980].append(prix)
            elif prix < 7964 :
                tab[3981].append(prix)
            elif prix < 7966 :
                tab[3982].append(prix)
            elif prix < 7968 :
                tab[3983].append(prix)
            elif prix < 7970 :
                tab[3984].append(prix)
            elif prix < 7972 :
                tab[3985].append(prix)
            elif prix < 7974 :
                tab[3986].append(prix)
            elif prix < 7976 :
                tab[3987].append(prix)
            elif prix < 7978 :
                tab[3988].append(prix)
            elif prix < 7980 :
                tab[3989].append(prix)
            elif prix < 7982 :
                tab[3990].append(prix)
            elif prix < 7984 :
                tab[3991].append(prix)
            elif prix < 7986 :
                tab[3992].append(prix)
            elif prix < 7988 :
                tab[3993].append(prix)
            elif prix < 7990 :
                tab[3994].append(prix)
            elif prix < 7992 :
                tab[3995].append(prix)
            elif prix < 7994 :
                tab[3996].append(prix)
            elif prix < 7996 :
                tab[3997].append(prix)
            elif prix < 7998 :
                tab[3998].append(prix)
            elif prix < 8000 :
                tab[3999].append(prix)
            elif prix < 8002 :
                tab[4000].append(prix)
            elif prix < 8004 :
                tab[4001].append(prix)
            elif prix < 8006 :
                tab[4002].append(prix)
            elif prix < 8008 :
                tab[4003].append(prix)
            elif prix < 8010 :
                tab[4004].append(prix)
            elif prix < 8012 :
                tab[4005].append(prix)
            elif prix < 8014 :
                tab[4006].append(prix)
            elif prix < 8016 :
                tab[4007].append(prix)
            elif prix < 8018 :
                tab[4008].append(prix)
            elif prix < 8020 :
                tab[4009].append(prix)
            elif prix < 8022 :
                tab[4010].append(prix)
            elif prix < 8024 :
                tab[4011].append(prix)
            elif prix < 8026 :
                tab[4012].append(prix)
            elif prix < 8028 :
                tab[4013].append(prix)
            elif prix < 8030 :
                tab[4014].append(prix)
            elif prix < 8032 :
                tab[4015].append(prix)
            elif prix < 8034 :
                tab[4016].append(prix)
            elif prix < 8036 :
                tab[4017].append(prix)
            elif prix < 8038 :
                tab[4018].append(prix)
            elif prix < 8040 :
                tab[4019].append(prix)
            elif prix < 8042 :
                tab[4020].append(prix)
            elif prix < 8044 :
                tab[4021].append(prix)
            elif prix < 8046 :
                tab[4022].append(prix)
            elif prix < 8048 :
                tab[4023].append(prix)
            elif prix < 8050 :
                tab[4024].append(prix)
            elif prix < 8052 :
                tab[4025].append(prix)
            elif prix < 8054 :
                tab[4026].append(prix)
            elif prix < 8056 :
                tab[4027].append(prix)
            elif prix < 8058 :
                tab[4028].append(prix)
            elif prix < 8060 :
                tab[4029].append(prix)
            elif prix < 8062 :
                tab[4030].append(prix)
            elif prix < 8064 :
                tab[4031].append(prix)
            elif prix < 8066 :
                tab[4032].append(prix)
            elif prix < 8068 :
                tab[4033].append(prix)
            elif prix < 8070 :
                tab[4034].append(prix)
            elif prix < 8072 :
                tab[4035].append(prix)
            elif prix < 8074 :
                tab[4036].append(prix)
            elif prix < 8076 :
                tab[4037].append(prix)
            elif prix < 8078 :
                tab[4038].append(prix)
            elif prix < 8080 :
                tab[4039].append(prix)
            elif prix < 8082 :
                tab[4040].append(prix)
            elif prix < 8084 :
                tab[4041].append(prix)
            elif prix < 8086 :
                tab[4042].append(prix)
            elif prix < 8088 :
                tab[4043].append(prix)
            elif prix < 8090 :
                tab[4044].append(prix)
            elif prix < 8092 :
                tab[4045].append(prix)
            elif prix < 8094 :
                tab[4046].append(prix)
            elif prix < 8096 :
                tab[4047].append(prix)
            elif prix < 8098 :
                tab[4048].append(prix)
            elif prix < 8100 :
                tab[4049].append(prix)
            elif prix < 8102 :
                tab[4050].append(prix)
            elif prix < 8104 :
                tab[4051].append(prix)
            elif prix < 8106 :
                tab[4052].append(prix)
            elif prix < 8108 :
                tab[4053].append(prix)
            elif prix < 8110 :
                tab[4054].append(prix)
            elif prix < 8112 :
                tab[4055].append(prix)
            elif prix < 8114 :
                tab[4056].append(prix)
            elif prix < 8116 :
                tab[4057].append(prix)
            elif prix < 8118 :
                tab[4058].append(prix)
            elif prix < 8120 :
                tab[4059].append(prix)
            elif prix < 8122 :
                tab[4060].append(prix)
            elif prix < 8124 :
                tab[4061].append(prix)
            elif prix < 8126 :
                tab[4062].append(prix)
            elif prix < 8128 :
                tab[4063].append(prix)
            elif prix < 8130 :
                tab[4064].append(prix)
            elif prix < 8132 :
                tab[4065].append(prix)
            elif prix < 8134 :
                tab[4066].append(prix)
            elif prix < 8136 :
                tab[4067].append(prix)
            elif prix < 8138 :
                tab[4068].append(prix)
            elif prix < 8140 :
                tab[4069].append(prix)
            elif prix < 8142 :
                tab[4070].append(prix)
            elif prix < 8144 :
                tab[4071].append(prix)

            else :
                tab[4072].append(prix)
    f_source.close()
    return tab

def mediane(l):
    l = sorted(l)
    l_len = len(l)
    if l_len < 1:
        return None
    if l_len % 2 == 0 :
        return round(( l[(l_len-1)/2] + l[(l_len+1)/2] ) / 2.0, 2)
    else:
        return round(l[(l_len-1)/2], 2)



def main() :
    tab = calculateur()
    med_tab = [[] for i in range(4073)]
    for i in range(len(tab)) :
        med_tab[i] = mediane(tab[i])
    return med_tab
    

if __name__ == "__main__":
    main()